
Vue.prototype.$http = axios;
Newspaper.$http = axios;
// 使用一个vue实例 作为事件的载体,用于绑定事件和处理发送事件，作为调度中心
let Bus = new Vue();
// tree组件 （公共部分） @click="handleNodeClick(model,index)"  @click="getIndex(model, index)" @click="toggle(model.name)"
var myTree = {
  props:['model', 'index'],
  template:`<li @click="handleNodeClick(model,index)">
              <p @click="toggle(model, index)">
                  <span class='title text-nobr'>
                      <i v-if="isFolders" class="icon" :class="[open ? 'folder-open': 'folder']"></i>
                      <i v-if="!isFolders" class="icon file-text"></i>
                      <span class="subTitle text-nobr" v-bind:title="model.menuName + (model.count !=null ? '   ('+ model.count +')':'')">
                        {{ model.menuName }}
                        <i v-if="model.count != null">( {{ model.count }} )</i>
                      </span>
                  </span>
              </p> 
              <ul v-show="open" v-if="isFolders">
                 <tree-menu v-for="(item,index) in model.classifies" :key="item.id" :model="item"></tree-menu>
              </ul>
          </li>`,
  name: 'treeMenu',
  mounted () {
     console.log(this.model, this.index, '我想要的')
  },
  computed: {
      // isFolders() {
      //     return this.model.classifies && this.model.classifies.length
      // }
  },
  data:function () {
    return {
      isFolders: true,
      open: false,
    }
  },
  methods: {
      handleNodeClick: function (model, i) {
          if (i == 0) {
              this.$parent.curPage = 0;
          }else if (i == 1) {
            
          }else if (i == 2) { // 地名导航
          
          
          } else if (i == 3) { // 人名导航
          
          } else {
              return false;
          }
      },
      toggle:function(model, i){
          if (model.id != null) {
            Bus.$emit("childEvent", model.id)
          }
          if (this.isFolders) {
            this.open = !this.open;
          }
      },
  }
};
// 创建-个vue实力
new Vue({
    el:'#wrap',
    // 定义属性，并设置初始值
    data:function () {
      return {
        // 左侧报纸研究数据
        theModel:[],
        // 报纸研究数据
        researchData:[],
        researchPageInfo: {
          currentPage: 1, //初始页
          pagesize: 10, //    每页的数据
        },
        menuName:'',
        // 每一条数据的id
        researchId:'',
        // 详情页容器
        detail:{},
        downMenu:'全文',
        Spinner:[
          {title:'全文',val:'detail'},
          {title:'标题',val:'title'},
          {title:'作者',val:'author'},
          {title:'来源',val:'source'},
        ],
        inpVal:'',
        inpSearchVal:'',//只针对搜索框的内容
        searchVal:'',//搜索条件
        EnglishName:'', // 检索时下拉框选中的值得英文名字
      }
    },
    components:{
      'my-tree':myTree,
    },
    created () {
        sessionStorage.setItem('active',3);
        // 接受子组件传过来的值
        this.$nextTick(() => {
          Bus.$on("childEvent", ref => {
            this.inpSearchVal="";
            this.menuName = ref;
            this.getRetrieval ()
          })
        })
    },
    mounted () {
      this.getRetrieval ();
    },
    methods:{
      //字符串转为json格式
       toJson:function(str){
         _str =(new Function("","return "+str))();
         console.log(_str);
         return _str;
       },

      // 获取报纸研究数据
      getRetrieval: function () {
          this.$http.get('/api/library/subject/research/'+(this.menuName == '' ? ' ': this.menuName)+'?pageNum='+this.researchPageInfo.currentPage+'&pageSize='+this.researchPageInfo.pagesize).then(res => {
            if (res.data != null && res.data.recordCount != null) {
              this.theModel = res.data.menus;
              this.researchData = res.data.map.resultList;
              this.getPage (res.data.recordCount)
              
            } else {
              throw this.error = '抱歉、数据查询失败'
            }
          }).catch(error => {
            console.log(error, '错误信息')
            this.$message({
                showClose: true,
                message: this.error,
                type: 'warning'
            });
          })
      },
      // 获取分页数据
      getPage:function (recordCount) {
         var that = this;
         var num = recordCount/this.researchPageInfo.pagesize;
         if (Number.isInteger(num)) { // 判断num是不是整数
          var pageSize = parseInt(recordCount/this.researchPageInfo.pagesize);
         } else {
          var pageSize = parseInt(recordCount/this.researchPageInfo.pagesize) + 1;
         }
         if (pageSize == undefined) pageSize = 0;
          $("#page").paging({
              pageNum: this.researchPageInfo.currentPage, // 当前页面
              pageSize: pageSize, // 总页码
              totalList: recordCount, // 记录总数量
              callback: function (num) { //回调函数
                  that.researchPageInfo.currentPage = num;
                  if(that.inpSearchVal==""){
                    that.getRetrieval ();
                  }
                  if(that.inpSearchVal!=""){

                    that.retrieval();
                  }
                  
              }
          });     
      },
      // 点击在线阅读
      rowClick: function (item) {
        this.researchId = item.id;
        this.detail = item;
      },
      // 点击检索下拉框
      clitit: function (item) {
        this.downMenu = item.title;
      },
      // 点击检索按钮
      retrieval (){
        switch (this.downMenu) {
           case '全文':
               this.EnglishName = 'detail';
               break;
           case '标题':
               this.EnglishName = 'title';
               break;
           case '作者':
               this.EnglishName = 'author';
               break;
           case '来源':
                this.EnglishName = 'source';
                 break;
           default:
               this.EnglishName = ' ';   
        }
        if(this.inpSearchVal==""){
            this.inpSearchVal=' ';
        }
        this.$http.get('/api/library/researchChecked/'+this.EnglishName+'/'+this.inpSearchVal+'?pageNum='+this.researchPageInfo.currentPage+'&pageSize='+this.researchPageInfo.pagesize).then (res => {
            this.researchData = res.data.map.resultList;
            this.getPage(res.data.recordCount)
        }).catch(error => {
            console.log(error, '检索错误信息');
            this.$message({
                showClose: true,
                message: this.error,
                type: 'error'
            });
        })
      },
      // 检索回车事件
      searchEnterFun: function (e) {
        if (e.keyCode == 13) { // 回车事件
          this.retrieval() 
        }
      },
      }
})