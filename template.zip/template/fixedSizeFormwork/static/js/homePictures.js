﻿
Vue.prototype.$http = axios;
Newspaper.$http = axios;
// 使用一个vue实例 作为事件的载体,用于绑定事件和处理发送事件，作为调度中心
let Bus = new Vue();
// tree组件 （公共部分） @click="handleNodeClick(model,index)"  @click="getIndex(model, index)" @click="toggle(model.name)"
var myTree = {
  props:['model', 'index'],
  template:`<li @click="handleNodeClick(model,index)">
              <p @click="toggle(model, index)">
                  <span class="title text-nobr">
                      <i v-if="isFolders" class="icon" :class="[open ? 'folder-open': 'folder']"></i>
                      <i v-if="!isFolders" class="icon file-text"></i>
                      <span class="subTitle text-nobr" v-bind:title="model.menuName + (model.count != null ? '   ('+ model.count + ')' : '') ">
                          {{ model.menuName }}
                          <i v-if="model.count != null">( {{ model.count }} )</i>
                      </span>
                  </span>
              </p> 
              <ul v-show="open" v-if="isFolders">
                 <tree-menu v-for="(item,index) in model.classifies" :key="item.id" :model="item"></tree-menu>
              </ul>
          </li>`,
  name: 'treeMenu',
  mounted () {
     console.log(this.model, this.index, '需要的')
  },
  computed: {
      // isFolders() {
      //     return this.model.classifies && this.model.classifies.length
      // }
  },
  data:function () {
    return {
      isFolders: true,
      open: false,
    }
  },
  methods: {
      handleNodeClick: function (model, i) {
        // this.firstId = model.id;
      },
      toggle:function(model, i){
          // Bus.$emit("childEvent", model)
          // 判断如果有子集则走接口
          if (i == undefined) {
            Bus.$emit("childEvent", model)
          }
          if (this.isFolders) {
            this.open = !this.open;
          }
      },
  }
};
// 创建-个vue实力
new Vue({
    el:'#wrap',
    // 定义属性，并设置初始值
    data:function () {
      return {
        viewSwiper:null,
        previewSwiper:'',
        // 图库左侧数据
        pictureEnjoyModuleManagesVosData:[],
        // 轮播图片数据
        pictureEnjoyVos:[],
        picturePageInfo: {
          currentPage: 1, //初始页
          pagesize: 10, //    每页的数据
        },
        pictureInfo:{
          title:'', // 标题
          author:'', // 作者
          releaseDate:'',
        },
        num:0,
        isNone:false,
        firstId:'',
        id:'',
        error:'抱歉、数据请求失败',
      }
    },
    components:{
      'my-tree':myTree,
    },
    created () {
        sessionStorage.setItem('active',4);
        // 接受子组件传过来的方法、拿到menuName 重新请求接口
        this.$nextTick(() => {
          Bus.$on('childEvent', (ref) => {
            this.id = ref.id;            
            this.getPictures()
          })
        })
    },
    mounted () {
      this.getPictures ();
    },
    methods:{
      getPictures: function () {
          this.$http.get('/api/library/subject/picture/'+(this.id == '' ? ' ' : this.id)+'?pageNum='+this.picturePageInfo.currentPage+'&pageSize='+this.picturePageInfo.pagesize).then(res => {
            if (res.data != null && res.data.recordCount != null) {
              console.log(res.data, '获取图库数据')
              if (this.viewSwiper != null ){
                  this.viewSwiper.slideTo(0);
                this.viewSwiper.destroy();
                this.viewSwiper = null;
              }
              for( var i in res.data.menus ){
                var menu = res.data.menus[i].classifies;
                  for(var j in menu)
                    menu[j].id = res.data.menus[i].id + "," + menu[j].id;
              }
              this.num = 0;
              this.pictureEnjoyModuleManagesVosData = res.data.menus;
                  if (res.data.map.resultList.length == 0) {
                        this.pictureEnjoyVos = [];
                        this.pictureInfo.title = '暂无数据';
                        this.pictureInfo.author = '暂无';
                        this.pictureInfo.releaseDate = '暂无';
                  } else {
                    this.pictureEnjoyVos = res.data.map.resultList;
                    this.pictureInfo.title = this.pictureEnjoyVos[this.num].title;
                    this.pictureInfo.author = this.pictureEnjoyVos[this.num].author;
                    this.pictureInfo.releaseDate = getTime(this.pictureEnjoyVos[this.num].releaseDate);
                     //  在获取完数据后，将swiper放在$nextTick下一个UI帧再初始化
                    this.$nextTick(() => {
                        this.swiper ();
                    })
                  }
                 
            } else {
              throw this.error = '抱歉、图库数据查询失败'
            }
          }).catch(error => {
            console.log(error, '错误信息')
            this.$message({
                showClose: true,
                message: this.error,
                type: 'warning'
            });
          })
      },
      // 初始化轮播
      swiper:function () {
        var that = this;
        that.viewSwiper = new Swiper('.swiper-container', {
            // Enable lazy loading
            lazyLoading: true,
            lazyLoadingInPrevNext: true,
            lazyLoadingInPrevNextAmount: 2,
            nextButton: '.swiper-button-next',
            prevButton: '.swiper-button-prev',
            // Disable preloading of all images
            preloadImages: false,
            // updateOnImagesReady : true,
            // lazyLoadingInPrevNext : true,
            // lazyLoadingInPrevNextAmount : 1,
            // observer:true,//修改swiper自己或子元素时，自动初始化swiper
            // observeParents:true,//修改swiper的父元素时，自动初始化swiper
            // 点击上一个、下一个
            onSlideChangeStart: function(swiper){
              that.num = swiper.activeIndex;
              that.pictureInfo.title = that.pictureEnjoyVos[that.num].title;
              that.pictureInfo.author = that.pictureEnjoyVos[that.num].author;
              that.pictureInfo.releaseDate = getTime(that.pictureEnjoyVos[that.num].releaseDate);
              // swiper.update();
            },
            
        });

      },
      // 进入阅读页
      goReadingPage: function (item) {
       window.open('readingPage.html?articleId='+ item.paperId, 'readingPage');
      },
    }
})