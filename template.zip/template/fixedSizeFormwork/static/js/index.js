Vue.prototype.$http = axios;
Newspaper.$http = axios;
// 创建-个vue实力
vueObj = new Vue({
    el:'#wrap',
    // 定义属性，并设置初始值
    data:function () {
      return {
        inpVal:'',
        // 轮播图数据
        swiperData:[],
        // 动态资讯数据
        dynamicInfo: [],
        dynamicInfoNone:'none',
        downMenu:'全部',
        EnglishName:'', // 检索时下拉框选中的值得英文名字
        newArray:'',
        Spinner: [
            {
              title: "全部",
              value:0
            },
            {
                title: "全文",
                value:1
            },
            {
                title: "题名",
                value:2,
            },
            {
                title: "作者",
                value:3
            },
            {
                title: "主题词",
                value:4
            },
            {
                title: "关键词",
                value:5
            }
        ],
        // 历史上的今天数据容器
        historyToday:[],
        // 历史上的今天详情页容器
        historyTodayDetail:[],
        lunarCalendar:'', // 农历时间
        date:'', // 当前系统时间
        week:'',
        historyTodayNone:'none',
        // 所有报纸列表数据
        newspaperData:[],
        error:'抱歉、数据请求失败',
        libId:'',
        // 用户权限
        permission:{},
        isHistoryToday:false, // 控制历史上的今天详情模板
        navigationModule:'', // 导航是否显示
        // 历史上的今天没数据时默认图
        noHistory:'',
        pictureMore:[], // 存放图库的全部图片容器
        //图库更多判断
        navigation:'',
        // 资源库信息
        permitLibs:[],
      }
    },
    // 在模板渲染成html前调用，即通常初始化某些属性值，然后再渲染成视图。
    created () {
        sessionStorage.setItem('active',0);
       // 初始化获取一些时间
      let  weeks = '日一二三四五', 
           Year ='' ,
           Month = '',// 月
           Day = ''; // 日
      this.date = new Date().pattern('yyyy年MM月dd日');
      this.week = weeks.charAt(new Date().getDay());
      Year = new Date().getFullYear();
      Month = new Date().getMonth() + 1;
      this.Day = new Date().getDate();
      //   调用获取农历时间的方法
      this.lunarCalendar = GetCNDate(Year,Month,Day);
      this.$nextTick(() => {
        this.getInfo();
      })

    },
    // 在模板渲染成html后调用，通常是初始化页面完成后，再对html的dom节点进行一些需要的操作
    mounted () {
        this.init ();
    },
    methods:{
        // 初始数据
        init: function () {
            this.newspaperList ();
            this.getBg();
            // 获取历史上今天的默认配图
            this.getDefaultGraph ();
        },
        // 获取背景图
        getBg:function () {
          this.$http.get('/api/library/getSkin/background').then (res => {
            //   res.data.msg = './static/images/bg/press.jpg';
             if (res.data.code == 0) {
               if (res.data.msg != '' || RTCRtpSender.data.msg != null) {
                 let dom = document.getElementById('app');
                 dom.style.backgroundImage = "url("+res.data.msg+")";
               } else {
                 
               }
             }
          }).catch(error => {
              console.log(error, '错误信息')
           })
        },
        // 获取资源库基本信息
        getInfo: function () {
             Newspaper.getLibraryInfo ().then (library => {
               this.handleInfo (library);
               this.navigation = library.navigationModule
             })
        },
        // 处理资源库基础信息
        handleInfo: function (library) {
            console.log(library, '将处理的数据')
           /**
            * 图片推荐
            */
            this.navigationModule = library.navigationModule.split(",");
            if (library.pictureEnjoyVos.length > 0) {
                this.pictureMore = library.pictureEnjoyVos;
                if (library.pictureEnjoyVos.length >= 6) {
                    let arr = library.pictureEnjoyVos.slice(0, 6);
                    this.swiperData = arr;
                } else {
                    this.swiperData = library.pictureEnjoyVos;
                }
                
            }
            // 动态资讯数据
            if (library.dynamicInfos != null) {
                let arr = library.dynamicInfos;
                if (arr.length >= 6) {
                    this.dynamicInfoNone = 'block';
                  }
                  let arrs = arr.slice(0, 6);
                  this.dynamicInfo = arrs;
            }
            // 历史上的今天数据
            // library.historyToday = [
            //   {
            //     paperName:'红色中华',
            //     title:'中央文稿模流搜索是是是是是是弟弟宝石弟弟',
            //     publishedDate:'2019-12-01'
            //   },
            //   {
            //     paperName:'红色中华',
            //     title:'中央文稿模流搜索是是是是是是弟弟',
            //     publishedDate:'2019-12-01'
            //   },
            //   {
            //     paperName:'红色中华',
            //     title:'中央文稿模流搜索是是是是是是弟弟',
            //     publishedDate:'2019-12-03'
            //   },
            //   {
            //     paperName:'红色中华',
            //     title:'中央文稿模流搜索是是是是是是弟弟',
            //     publishedDate:'2019-12-03'
            //   }
            // ]
            if (library.historyToday.length >0) {
                let historyToday = library.historyToday;
                if(historyToday.length > 3) {
                   this.historyTodayNone = 'block';
                }
                let historyTodays = historyToday.slice(0,3);
                this.historyToday = historyTodays;
                this.historyTodayDetail = library.historyToday
            }
           
        },
        // 获取报刊信息
        newspaperList: function () {
          Newspaper.getPapers().then (papers => {
             if (papers.length >= 6) {
                this.newspaperData = papers.slice(0, 6);
             } else {
                this.newspaperData = papers;  
             }
          })
        },
        // 获取历史上今天没数据时的默认图
        getDefaultGraph: function () {
            this.$http.get('/api/library/getSkin/historyToday').then (res => {
                if (res.data.code == 0) {
                  if (res.data.msg != '' || RTCRtpSender.data.msg != null) {
                     this.noHistory = res.data.msg;
                  }
                }
            }).catch(error => {
                 console.log(error, '错误信息')
            })
        },
        /* ------------------ 业务操作事件 -------------------------- */
        // 下拉框选择
        clitit:function (item) {
            this.downMenu = item.title;
        },
        // 检索
        btnRoute:function () {
            window.location.href = 'newspaperSearch.html?downMenu='+this.downMenu+'&inpVal='+this.inpVal;
            sessionStorage.setItem('active', 2);
        },
        // 搜索回车事件
        searchEnterFun: function (e) {
          if (e.keyCode == 13) {
            this.btnRoute()  // 回车键触发、搜索事件 
          }
        },
        // 点击报纸列表的每一条数据
        goPeriod: function (item) {
           window.open("readingPage.html?paperId=" + item.id);
        },
        imgToRead(subItem) {
            window.open('readingPage.html?articleId='+ subItem.paperId);
        },
        // 动态资讯列表详情页
        goRead(item) {
            // 跳转到阅读页面api/module/info/
            window.location.href = 'homeInformation.html?id='+item.id;
            sessionStorage.setItem('active', 5);
        },
        // 点击历史上的今天每条数据
        goHistory: function (item) {
            window.open('readingPage.html?articleId='+ item.id, 'readingPage');
        },
        // 点击更多的历史上的今天
        clickMore:function () {
          this.isHistoryToday = true;
        },
        
    }
})