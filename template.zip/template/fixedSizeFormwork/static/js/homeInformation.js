Vue.prototype.$http = axios;
Newspaper.$http = axios;
// 创建-个vue实力
new Vue({
    el:'#wrap',
    // 定义属性，并设置初始值
    data:function () {
      return {
        // 分页信息
        pageInfo:{
          currentPage: 1, //初始页
          pagesize: 10, // 每页的数据
        },
        titFormsName: '',
        tableData: [], // 表格容器
        id:'', // 根据数据id 获取数据详情信息
        detail:{}, // 详情页容器
        error:'抱歉、数据请求失败',
      }
    },
    created () {
        sessionStorage.setItem('active',5)
        if (getUrlParam('id') && getUrlParam('id') != '') {
          this.id = getUrlParam('id')
          this.getDetail()
        }
    },
    mounted () {
       this.initilaize ();
    },
    methods:{
        // 初始化表格
        initData:function () {
           this.$http.get('/api/module/infoPage/'+this.libId+'?pageNum='+this.pageInfo.currentPage+'&pageSize='+this.pageInfo.pagesize
           ).then (res => {
               console.log(res.data, '动态资讯数据')
             this.tableData = res.data.list
             this.getPage(res.data.total)
           }).catch(error => {
              this.$message({
                 showClose:true,
                 message: '抱歉，数据请求失败',
                 type:'warning'
              })
           })
        },
        // 根据id 获取详情页数据
        getDetail:function () {
          this.$http.get('/api/module/info/'+this.id
          ).then(res => {
           console.log(res.data.data, '详情页数据')
           if (res.data.code == 0) {
              this.detail = res.data.data;
           } else {
             throw error = '抱歉、数据查询失败'
           }
          }).catch(error => {
            this.$message({
                showClose:true,
                message: this.error,
                type:'warning'
             })
          })
        },
         // 获取分页数据
        getPage:function (recordCount) {
            console.log(recordCount, '动态资讯总数')
            var that = this;
            var num = recordCount/this.pageInfo.pagesize;
            if (Number.isInteger(num)) { // 判断num是不是整数
                var pageSize = parseInt(recordCount/this.pageInfo.pagesize);
            } else {
              var pageSize = parseInt(recordCount/this.pageInfo.pagesize) + 1;
            }
            if (pageSize == undefined) pageSize = 0;
            $("#page").paging({
                pageNum: this.currentPage, // 当前页面
                pageSize: pageSize, // 总页码
                totalList: recordCount, // 记录总数量
                callback: function (num) { //回调函数
                    that.pageInfo.currentPage = num;
                    that.initData ()
                }
            });     
        },
        //获取点击当前元素内的数据拿到当前数据id 地址栏传参
        trCli(item) {
            this.id = item.id;
            this.detail = item;
        },
        initilaize: function () {
          Newspaper.getUserInfo().then (userInfo => {
            this.libId = userInfo.libId;
            this.initData ()
          });
        },
        
    }
})