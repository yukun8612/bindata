Vue.prototype.$http = axios;
Vue.config.errorHandler = (error, vm) => {
    console.log(error, '错误信息')
    vm.$message({
        showClose: true,
        message: error,
        type: 'warning'
    });
};
Newspaper.$http = axios;
// 使用一个vue实例 作为事件的载体,用于绑定事件和处理发送事件，作为调度中心
let Bus = new Vue();
// 全局定义数据
// tree组件 （公共部分） @click="handleNodeClick(model,index)"  @click="getIndex(model, index)" @click="toggle(model.name)"
var myTree = {
    props: ['model', 'index'],
    template: `<li @click="handleNodeClick(model,index)">
                <p @click="toggle(model, index)">
                    <span class="title text-nobr">
                        <i v-if="isFolders" class="icon" :class="[open ? 'folder-open': 'folder']"></i>
                        <i v-if="!isFolders" class="icon file-text"></i>
                          <span class="subTitle text-nobr" v-bind:title="model.name + (model.count != null ? '   ('+ model.count +')': '')">{{ model.name }}
                            <i v-if="model.count != null">( {{ model.count }} )</i>
                          </span>
                    </span>
                </p> 
                <ul v-show="open" v-if="isFolders">
                   <tree-menu v-for="(item,index) in model.classifies" :key="item.id" :model="item"></tree-menu>
                </ul>
            </li>`,
    name: 'treeMenu',
    mounted() {
        //    console.log(this.model, this.index, '我想要的')
    },
    computed: {
        // isFolders() {
        //     return this.model.classifies && this.model.classifies.length
        // }
    },
    data: function () {
        return {
            isFolders: true,
            open: false,
        }
    },
    methods: {
        handleNodeClick: function (model, i) {
            this.$parent.isRetrieval = false;
        },
        toggle: function (model, i) {
            if (model.name != '分类导航' && model.name != '年份导航' && model.name != '地名导航' && model.name != '人名导航' && model.menuCode != 'area' && model.menuCode != 'author') {
                Bus.$emit("childEvent", model)
            }
            if (this.isFolders) {
                this.open = !this.open;
            }
        },
    }
}
// 创建-个vue实力
new Vue({
    el: '#wrap',
    // router:router,
    // 定义属性，并设置初始值
    data: function () {
        return {
            // 分类导航数据
            // relationshipV:'', // 关系值
            // relationships:[{label:'AND',value:0},{label:'OR',value:1}],
            downMenu: '全部',
            singleElect: 3,
            inputV: '', // 输入值
            inTime: '', // 在时间之间
            brforeTime: '', // 之前时间
            afterTime: '', // 之后时间
            Spinner: [
                { title: '全部', val: 's_content' },
                { title: '全文', val: 'contentShow' },
                { title: '题名', val: 'title' },
                { title: '作者', val: 'author' },
                { title: '主题词', val: 'subjectword' },
                { title: '关键词', val: 'keyword' },
            ],
            retrievalClustering: [], // 检索聚类里面的数据
            // 高级检索
            isRetrieval: false, // 控制是否进行高级检索
            newspaperType: [],  // 存放报纸种类数据容器
            inputVal: '',
            newspaperTypeVal: '',
            searchV: '',
            val: '',
            inputTerm: [{ search: '全文', content: '' }, { term: 'AND', search: '全文', content: '' }],


            isRetrievalContent: false, // 控制是否是普通检索中的检索全部和全文
            inpVal: '',
            inpSearchVal: '',//只针对搜索框的内容
            searchVal: '',//搜索条件
            parameter: 'address', // 给后台传的参数
            // 分类导航table数据
            classifyData: [],
            classifyPageInfo: {
                currentPage: 1, //初始页
                pagesize: 10, //    每页的数据
            },
            classifyTotal: 0, // 总数
            EnglishName: '', // 检索时下拉框选中的值得英文名字
            sorting: 'desc', // 排序变量 desc降序 asc 升序 默认降序
            isQuery: false, // 是否模糊查询 isQuery= true 模糊查询 isQuery = false 精确查询
            error: '抱歉、数据请求失败',
            percent: 50,
            userVipData: {}
        }
    },
    components: {
        'my-tree': myTree,
    },
    computed: {
    },
    created() {
        sessionStorage.setItem('active', 2)
        if (this.getUrlParam('downMenu') && this.getUrlParam('downMenu') != '') {
            this.downMenu = this.getUrlParam('downMenu');
        }
        if (this.getUrlParam('inpVal') && this.getUrlParam('inpVal') != '') {
            this.inpVal = this.getUrlParam('inpVal')
        }
        this.inpSearchVal = this.getUrlParam('inpVal')
        this.$nextTick(() => {
            Bus.$on('childEvent', ref => {
                this.classifyPageInfo.currentPage = 1
                let url = "";
                let search = '';
                if (!this.EnglishName) {
                    if (!this.inpSearchVal) {
                        search = ''
                    } else {
                        search = this.inpSearchVal + ' AND '
                    }
                } else {
                    search = this.EnglishName + ':' + this.inpSearchVal + ' AND '
                }
                this.searchVal = search

                if (ref.search) {
                    this.searchVal = this.searchVal + ref.search
                }
                if (ref.menuCode == 'year') {
                    this.isRetrievalContent = false
                    url = '/api/newspaper/select?q=' + this.searchVal + '&page=' + this.classifyPageInfo.currentPage + '&size=' + this.classifyPageInfo.pagesize
                } else {
                    url = '/api/newspaper/select?q=' + this.searchVal + ' classify:' + ref.id + '&page=' + this.classifyPageInfo.currentPage + '&size=' + this.classifyPageInfo.pagesize
                    this.searchVal = this.searchVal + ' classify:' + ref.id
                }

                this.$http.get(url).then(res => {
                    this.classifyData = res.data.itemList;
                    this.getClassifyPage(res.data.recordCount)
                }).catch(error => {
                    console.log(error, '检索错误信息');
                    this.$message({
                        showClose: true,
                        message: this.error,
                        type: 'warning'
                    });
                })
            })
        })

    },
    mounted() {
        this.getClassifyData()
        this.init()

        this.getUserInfoData()
    },
    methods: {
        getUserInfoData() {
            var self = this
            Newspaper.getUserInfo().then(res => {
                console.log(res, 'Newspaper.getUserInfo')
                self.userVipData = {
                    freeArtclies: res.freeArtclies,
                    vipLevel: res.userInfo.vipLevel,
                }
            })
        },
        toVip() {
            this.$message({
                showClose: true,
                message: '成为VIP，查看所有检索结果',
                type: 'warning'
            });
        },
        // --------------- 分类导航事件 -----------
        // 获取分类导航数据
        init: function () { // desc 是降序也是倒序 asc升序 默认降序
            this.$http.get('/api/newspaper/select?q=' + this.EnglishName + ((this.EnglishName != '' && this.inpVal != '') ? ':' : '') + this.inpVal + '&page=' + this.classifyPageInfo.currentPage + '&size=' + this.classifyPageInfo.pagesize + '&sort=publishedDate ' + this.sorting).then(res => {
                // 获取左边检索聚类中的分类导航数据
                if (res.data.menus.length > 0) {
                    this.retrievalClustering = res.data.menus;
                }
                this.classifyData = res.data.itemList;
                this.getClassifyPage(res.data.recordCount)
                if (this.getUrlParam('downMenu') || this.getUrlParam('inpVal')) {
                    this.retrieval()
                }

            }).catch(error => {
                console.log(error, '检索错误信息');
                this.$message({
                    showClose: true,
                    message: this.error,
                    type: 'warning'
                });
            })
        },
        // 获取分类导航数据
        getClassifyData: function () {
            this.$http.get('/api/newspaper/select?q=' + this.searchVal + '&page=' + this.classifyPageInfo.currentPage + '&size=' + this.classifyPageInfo.pagesize + '&sort=publishedDate ' + this.sorting).then(res => {
                this.classifyData = res.data.itemList;
                this.getClassifyPage(res.data.recordCount)
            }).catch(error => {
                console.log(error, '检索错误信息');
                this.$message({
                    showClose: true,
                    message: this.error,
                    type: 'warning'
                });
            })
        },
        // 获取分类导航分页
        getClassifyPage: function (recordCount) {
            console.log(recordCount, '总数')
            var that = this;
            var num = recordCount / this.classifyPageInfo.pagesize;
            if (Number.isInteger(num)) { // 判断num是不是整数
                var pageSize = parseInt(recordCount / this.classifyPageInfo.pagesize);
            } else {
                var pageSize = parseInt(recordCount / this.classifyPageInfo.pagesize) + 1;
            }
            if (pageSize == undefined) pageSize = 0;
            $("#classifyPage").paging({
                pageNum: this.classifyPageInfo.currentPage, // 当前页面
                pageSize: pageSize, // 总页码
                totalList: recordCount, // 记录总数量
                callback: function (num) { //回调函数
                    that.classifyPageInfo.currentPage = num;
                    that.getClassifyData();
                }
            });
        },
        // 点击检索下拉框
        clitit: function (item) {
            this.downMenu = item.title;
        },
        // 点击检索按钮
        retrieval() {
            // alert(this.downMenu)
            this.classifyPageInfo.currentPage = 1
            switch (this.downMenu) {
                case '全文':
                    this.EnglishName = 'contentShow';
                    this.isRetrievalContent = true;
                    break;
                case '题名':
                    this.EnglishName = 'title';
                    this.isRetrievalContent = false;
                    break;
                case '作者':
                    this.EnglishName = 'author';
                    this.isRetrievalContent = false;
                    break;
                case '主题词':
                    this.EnglishName = 'subjectword';
                    this.isRetrievalContent = false;
                    break;
                case '关键词':
                    this.EnglishName = 'keyword';
                    this.isRetrievalContent = false;
                    break;
                default:
                    this.isRetrievalContent = true;
                    this.EnglishName = '';
            }
            this.inpVal = this.inpSearchVal
            // 默认精确检索，你拼接检索词时加个双引号。
            if (this.isQuery) { // isQuery = true 模糊检索
                this.inpVal = this.inpVal;
            } else if (!this.isQuery && this.inpVal != '' && this.inpVal != null) { // isQuery = false 精确检索
                this.inpVal = '"' + this.inpVal + '"';
            }
            this.searchVal = this.EnglishName + ((this.EnglishName != '' && this.inpVal != '') ? ':' : '') + this.inpVal
            if (this.searchVal == "null") {
                this.searchVal = '';
            }
            this.$http.get('/api/newspaper/select?q=' + this.searchVal + '&page=' + this.classifyPageInfo.currentPage + '&size=' + this.classifyPageInfo.pagesize + '&sort=publishedDate ' + this.sorting).then(res => {
                this.retrievalClustering = res.data.menus;
                this.classifyData = res.data.itemList;
                this.getClassifyPage(res.data.recordCount)
            }).catch(error => {
                console.log(error, '检索错误信息');
                this.$message({
                    showClose: true,
                    message: this.error,
                    type: 'error'
                });
            })
        },
        // 检索的回车事件
        searchEnterFun: function (e) {
            if (e.keyCode == 13) {
                this.retrieval();
            }
        },
        // 点击排序
        sortChange: function (param) {
            if (param.order == 'ascending') { // 升序
                this.sorting = 'asc'
            } else if (param.order == 'descending') {  // 倒序降序
                this.sorting = 'desc';
            }
            this.getClassifyData();
        },
        // 高级检索
        advancedSearch: function () {
            this.isRetrieval = true;
            this.getNewspaperType();
        },
        /**
         * 点击模糊搜索
        */
        fuzzySearch: function () {
            this.retrieval();
        },
        // 返回普通检索
        returnOrdinary: function () {
            this.isRetrieval = false;
        },
        // 处理结果数据
        handleResult: function (result) {
            if (result == null) {
                this.$message({
                    showClose: true,
                    message: '您搜索的暂无内容请重新输入',
                    type: 'warning'
                });
                this.inpVal = '';
            } else {
                this.classifyData = result.list;
                this.classifyTotal = result.total;
            }
        },
        // 点击分类导航每一行 即在线阅读
        CClick: function (item) {
            window.open('readingPage.html?articleId=' + item.id, 'readingPage');
        },

        // --------------- 高级检索部分 -----------
        // 获取报纸种类
        getNewspaperType: function () {
            return new Promise((resolve, reject) => {
                this.$http.get('/api/newspaper/papers').then(res => {
                    if (res.data.code == 0 && res.data.data.length != 0) {
                        this.newspaperType = res.data.data;
                        this.newspaperType.unshift({ id: 0, name: '全部', type: 1 })
                    } else {
                        throw error = '报纸种类数据为空'
                    }
                })

            })
        },
        // 点击加号添加数据
        plus: function () {
            this.inputTerm.push({ term: 'AND', search: '全文', content: '' })

            this.$nextTick(() => {
                this.minus();
            })
        },
        // 高级检索中的检索id:3375 OR id:3376 AND keyword:中小企业
        advanced: function () {
            let searchTermArr = [];
            let searchTermMidArr = [];
            let content;
            if (this.newspaperTypeVal) {
                searchTermArr.push(`paperId:${this.newspaperTypeVal}  `)
            }
            this.inputTerm.forEach(term => {
                this.Spinner.forEach(spinner => {
                    if (term.search == spinner.title) {
                        term.EnglishName = spinner.val
                    }
                });
                if (term.content) {
                    if (!term.term) {
                        searchTermMidArr.push(`${term.EnglishName}:${term.content}`)
                    } else {
                        searchTermMidArr.push(`${term.term} ${term.EnglishName}:${term.content}`)
                    }
                }
            });
            if (searchTermMidArr.length > 0) {
                searchTermArr.push(searchTermMidArr.join(' '))
            }
            if (this.inTime && this.singleElect == 3) {
                searchTermArr.push(`publishedDate:%5B${this.inTime[0]} TO ${this.inTime[1]}%5D`)
            }
            if (this.brforeTime && this.singleElect == 4) {
                searchTermArr.push(`publishedDate:%5B0000-01-01 TO ${this.brforeTime}%5D`)
            }
            if (this.afterTime && this.singleElect == 5) {
                searchTermArr.push(`publishedDate:%5B${this.afterTime} TO 9999-12-29%5D`)
            }
            this.searchVal = searchTermArr.join(' AND ')
            this.$http.get(`/api/newspaper/select?q=${this.searchVal}&page=1&size=10`).then(res => {

                console.log(searchTermArr);
                this.retrievalClustering = res.data.menus;
                this.classifyData = res.data.itemList;
                // this.classifyTotal = res.data.recordCount;
                this.getClassifyPage(res.data.recordCount)
            })
            this.$nextTick(() => {
                this.returnOrdinary()
            })
        },
        // 点击减号
        minus() {
            var that = this;
            $('.myLi .el-icon-minus').click(function () {
                var findPEli = $(this).parents('.PEli').get(0);
                findPEli.remove()
            })
        },


        // 获取地址栏参数
        getUrlParam: function (name) {
            var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
            var url = decodeURI(window.location.search) ////如果出现乱码的话，可以用decodeURI()进行解码
            var r = url.substr(1).match(reg);
            if (r != null) return unescape(r[2]); return null;
        },
    },
    watch: {

    }
})