(function(){
    function generateRandom() {
        return Math.floor((1 + Math.random()) * 0x10000)
          .toString(16)
          .substring(1);
      }  
      if(typeof androidExt !="undefined"){
        // This only works if `open` and `send` are called in a synchronous way
        // That is, after calling `open`, there must be no other call to `open` or
        // `send` from another place of the code until the matching `send` is called.

        requestID = null;
        XMLHttpRequest.prototype.reallyOpen = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function(method, url, async, user, password) {
            requestID = generateRandom()
            var signed_url = url + "AJAXINTERCEPT" + requestID;
            this.reallyOpen(method, signed_url , async, user, password);
        };
        XMLHttpRequest.prototype.reallySend = XMLHttpRequest.prototype.send;
        XMLHttpRequest.prototype.send = function(body) {
            androidExt.customAjax(requestID, body);
            this.reallySend(body);
        };
      }
})();
Vue.prototype.$http = axios;
Vue.config.errorHandler = (error, vm) => {
    console.log(error, '错误信息')
    vm.$message({
        showClose: true,
        message: error,
        type: 'warning'
    });
};
Newspaper.$http = axios;

new Vue({
    el: '#app',
    data: function() {
        var validateName = (rule, value, callback) => {
           console.log(value, '值')
           if (value == '') {
                callback(new Error('请输入账户'));
            }else if (value.length < 2 || value.length > 20) {
                callback(new Error('账户长度在2~20个字符之间，请重新输入您的账户'));
            }
             else {
                callback();
            }
        }
        var validatePass = (rule, value, callback) => {
            if (value == '') {
                callback(new Error('请输入密码'));
            }else if (value.length < 5 || value.length > 20) {
                callback(new Error('密码长度在5~20个字符之间，请重新输入您的密码'));
            }
             else {
                callback();
            }
        }
        return {
            // 资源库信息
            library: {},
            // 用户信息
            userInfo: {},
            // 报刊列表
            papers: {},
            // 表单信息
            form: {
                password:'',
                username:''
            },
            rules:{
                username:[
                    { required: true,validator:validateName,trigger: 'blur' }
                ],
                password:[
                    { required: true, validator:validatePass,trigger: 'blur' }
                ]
            },
            error:'请输入信息'
        }

    },
    created() {
        this.initialize();

    },

    methods: {
        initialize() {
            Newspaper.getUserInfo().then(userInfo => {
                this.userInfo = userInfo;
            });
            Newspaper.getLibraryInfo().then(library => { this.library = library });
            Newspaper.getPapers().then(papers => { this.papers = papers; });
        },
        // 点击登录
        doSubmit (formName) {
            this.$refs[formName].validate((valid) => {
                if (valid) {
                    var username = $("input[name='username']").val();
                    var password = $("input[name='password']").val();
                    var that = this;
                    // $('#form').serialize()
                    $.ajax({
                        type: "post",
                        url: "/login",
                        data: {
                            "username": username,
                            "password": password,
                            "validateCode" :'',
                            "rememberMe": false,
							"uuid":localStorage.getItem('login.uuid_'+username)
                        },
                        success: function(res) {
                            if (res.code == 0) {
								if(res.data != null)
								  localStorage.setItem('login.uuid_'+username, res.data);
                                window.location.href = 'index.html'
                            } else {
                                that.$message({
                                    showClose: true,
                                    message: res.msg,
                                    type: 'warning'
                                });
                                that.form.username = '';
                                that.form.password = '';
                            }
                        }
                    })
                } else {
                    console.log('error submit!!');
                    return false;
                }    
                
            });
        },
        // IP登录
        IPSubmit () {
            location.href = this.userInfo.baseUrl
        }
    }
});