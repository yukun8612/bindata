﻿Vue.prototype.$http = axios;
Vue.config.errorHandler = (error, vm) => {
    console.log(error, '错误信息')
    vm.$message({
        showClose: true,
        message: error,
        type: 'warning'
    });
};
Newspaper.$http = axios;

vueObj = new Vue({
    el: '#pad',
    data: function() {
        return {
            // 资源库信息
            library: {},
            // 用户信息
            userInfo: {},
            // 报刊列表
            papers: {},
        }

    },
    created() {
        this.initialize();

    },

    methods: {
        initialize() {
            Newspaper.getUserInfo().then(userInfo => {
                this.userInfo = userInfo;
                if (this.userInfo.userType == "Visitor") { // 游客
                    window.location.href = "login.html";
                }
            });
            Newspaper.getLibraryInfo().then(library => { this.library = library });
            Newspaper.getPapers().then(papers => { 
                this.papers = papers;
            });
        },
        // 点击登录
        signIn () {
          window.location.href = 'login.html';
        },
        // 退出
        signOut: (userType) =>{
            $.ajax({
                  type: "post",
                  url: "/logout",
                  success: function(res) {
                    location.href = 'login.html';
                  }
            });
        },
        // 点击切换资源库
        handleCommand (item) {
          window.location.href = '/' + item.code;
        }
    }
});