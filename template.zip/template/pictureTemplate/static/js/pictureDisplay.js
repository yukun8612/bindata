Vue.prototype.$http = axios;
// 创建-个vue实力
var vueObj = new Vue({
    el:'#wrap',
    // 定义属性，并设置初始值
    data:function () {
      return {
        dialogVisible:false,
        dialogImageUrl:'',
        pageInfo: {
          pageNum:1,
          pageSize:10
        },
        // 轮播图数据
        swiperData:[],
        objDesc:{
        //  title:'',
        //  author:'',
        //  published:''
        },
        id:'', // 获取地址栏参数
        start:0, // 从第几张图片开始
        // 具体那张图
        detail:{},
        error:'抱歉、数据请求失败'
      }
    },
    created () {
       console.log(getUrlParam('id'), '获取id')
       if (getUrlParam('id') && getUrlParam('id') != null) {
         this.id = getUrlParam('id');
         this.getDetail (this.id)
       }
    },
    mounted () {
      this.initialize ();  
    },
    methods:{
        // 初始化数据
        initialize: function () {
          this.$http.get('/api/module/photoSearch?pageNum='+this.pageInfo.pageNum+'&pageSize='+this.pageInfo.pageSize).then ( res => {
             this.swiperData = res.data.map.resultList;
             this.objDesc = this.swiperData[0];
             var count = -1;
             this.swiperData.forEach((item, k)=> {
                 count ++;
               item.picturesUrl = '/resource/红色照片/' + item.picturesUrl;
               if (item.id == this.id) {
                this.objDesc = this.detail;
                this.start = count;
               }
             });
             this.$nextTick(() => {
                this.doSwiper()
             })
            //  this.getPage(res.data.recordCount);

          }).catch(error => {
            this.$message({
               showClose:true,
               message: '抱歉，数据请求失败',
               type:'warning'
            })
         })
        },
        doSwiper: function () {
          $("#pikame").PikaChoose({startOn:this.start,carousel:true, carouselVertical:true});
          $('.pika-stage img').on ('click', function() {
                vueObj.dialogVisible = true;
                vueObj.dialogImageUrl = $(this).attr('src');
          })
        },
        // 获取分页数据
        getPage:function (recordCount) {
            console.log(recordCount, '动态资讯总数')
            var that = this;
            var num = recordCount/this.pageInfo.pagesize;
            if (Number.isInteger(num)) { // 判断num是不是整数
                var pageSize = parseInt(recordCount/this.pageInfo.pagesize);
            } else {
              var pageSize = parseInt(recordCount/this.pageInfo.pagesize) + 1;
            }
            if (pageSize == undefined) pageSize = 0;
            $("#page").paging({
                pageNum: this.currentPage, // 当前页面
                pageSize: pageSize, // 总页码
                totalList: recordCount, // 记录总数量
                callback: function (num) { //回调函数
                    that.pageInfo.currentPage = num;
                    that.initData ()
                }
            });     
        },
        // 根据地址栏参数id 查询具体图片
        getDetail: function (id) {
           this.$http.get('/api/module/photo/'+id+'/detail').then (res => {
             if (res.data.code == 0) {
               this.detail = res.data.data;
             }
           }).catch (error => {
              console.log(error, '错误信息')
              this.$message({
                  showClose:true,
                  message: '抱歉，根据id查询失败!',
                  type:'warning'
              })

           })
        },
        // 点击缩略图
        clickImg: function (item) {
          this.objDesc = item;
        }
    }
})