Vue.prototype.$http = axios;
Vue.config.errorHandler = (error, vm) => {
    console.log(error, '错误信息')
    vm.$message({
        showClose: true,
        message: error,
        type: 'warning'
    });
};
// 使用一个vue实例 作为事件的载体,用于绑定事件和处理发送事件，作为调度中心
let Bus = new Vue();
// 创建-个vue实力
new Vue({
    el:'#wrap',
    // router:router,
    // 定义属性，并设置初始值
    data:function () {
      return {
        downMenu:'题名',
        Spinner:[
          {title:'题名',val:'title'},
          {title:'作者',val:'author'},
          {title:'主题词',val:'subTitle'},
          {title:'关键词',val:'keyword'},
        ],
        // title subTitle author keyword
        inpSearchVal:'',//只针对搜索框的内容
        // 图片列表数据
        pictureData: [],
        pageInfo: {
            pageNum: 1, //初始页
            pageSize: 10, //    每页的数据
        },
        EnglishName:'', // 检索时下拉框选中的值得英文名字
        error:'抱歉、数据请求失败',
      }
    },
    components:{},
    computed : {},
    created () {},
    mounted () {
      this.initialize();
    },
    methods:{
        // 初始化加载数据
        initialize: function () {
           this.$http.get('/api/module/photoSearch?pageNum='+this.pageInfo.pageNum+'&pageSize='+this.pageInfo.pageSize).then ( res => {
              this.pictureData = res.data.map.resultList;
              this.pictureData.forEach((item, k)=> {
                item.picturesUrl = '/resource/红色照片/' + item.picturesUrl;
              });
              this.getPage(res.data.recordCount);
           })
        },
        // 获取图片列表分页
        getPage: function (recordCount) {
            console.log(recordCount, '总数')
            var that = this;
            var num = recordCount/this.pageInfo.pageSize;
            if (Number.isInteger(num)) { // 判断num是不是整数
                var pageSize = parseInt(recordCount/this.pageInfo.pageSize);
            } else {
               var pageSize = parseInt(recordCount/this.pageInfo.pageSize) + 1;
            }
            if (pageSize == undefined) pageSize = 0;
            $("#page").paging({
                pageNum: this.pageInfo.pageNum, // 当前页面
                pageSize: pageSize, // 总页码
                totalList: recordCount, // 记录总数量
                callback: function (num) { //回调函数
                    that.pageInfo.pageNum = num;
                    // that.retrieval ();
                    that.initialize ();
                }
            });   
        },
        // 点击检索下拉框
        clitit: function (item) {
           this.downMenu = item.title;
        },
        // 点击检索按钮
        retrieval (){
            this.pageInfo.pageNum = 1;
            switch (this.downMenu) {
               case '题名':
                   this.EnglishName = 'title';
                   break;
               case '作者':
                   this.EnglishName = 'author';
                   break;
               case '主题词':
                    this.EnglishName = 'subTitle';
                    break;
               case '关键词':
                   this.EnglishName = 'keyword';
                   break;
               default:
                   this.EnglishName = '';   
            }
            // 如果筛选条件有一个为空 则走列表页接口 否则走筛选接口
            if (this.inpSearchVal == '' || this.EnglishName == '') {
                this.initialize();
            } else {
                this.$http.get('/api/module/photoSearch/'+this.EnglishName+'/'+this.inpSearchVal+'?pageNum='+this.pageInfo.pageNum+'&pageSize='+this.pageInfo.pageSize).then ( res => {
                    this.pictureData = res.data.map.resultList;
                    this.pictureData.forEach((item, k)=> {
                        item.picturesUrl = '/resource/红色照片/' + item.picturesUrl;
                      });
        
                    this.getPage(res.data.recordCount);
                }).catch(error => {
                    console.log(error, '检索错误信息');
                    this.$message({
                        showClose: true,
                        message: this.error,
                        type: 'warning'
                    });
                })
            }
            
        },
        // 检索的回车事件
        searchEnterFun: function (e) {
          if (e.keyCode == 13) {
            this.retrieval ();   
          }
        },
    },
    watch: {
      
    }
})