Vue.prototype.$http = axios;
Newspaper.$http = axios;
// 创建-个vue实力
vueObj = new Vue({
    el:'#wrap',
    // 定义属性，并设置初始值
    data:function () {
      return {
       
        // 用户基本信息
        library:{},
        pageInfo:{
          pageNum:1,
          pageSize:6,
        },
        swiperData:[
          // {
          //   picturesUrl:'./static/images/swiper/p1.png'
          // },
          // {
          //   picturesUrl:'./static/images/swiper/p2.png'
          // },
          // {
          //   picturesUrl:'./static/images/swiper/p3.png'
          // },
          // {
          //   picturesUrl:'./static/images/swiper/p4.png'
          // },
          // {
          //   picturesUrl:'./static/images/swiper/p5.png'
          // },
          // {
          //   picturesUrl:'./static/images/swiper/p6.png'
          // }
        ],
        paperText:'',
        seeNone:'none'
      }
    },
    // 在模板渲染成html前调用，即通常初始化某些属性值，然后再渲染成视图。
    created () {
    },
    // 在模板渲染成html后调用，通常是初始化页面完成后，再对html的dom节点进行一些需要的操作
    mounted () {
        this.initialize();
    },
    methods:{
        // 初始数据
        initialize: function () {
          Newspaper.getLibraryInfo().then (library => {
            this.library = library;
            if (this.library.paperText.length >= 200) {
                let str = this.library.paperText.substr(0, 109);
                this.paperText = str;
                this.seeNone = "";
            } else {
                this.paperText = library.paperText;  
            }
          })
          // 获取轮播图
          this.$http.get('/api/module/photoSearch?pageNum='+this.pageInfo.pageNum+'&pageSize='+this.pageInfo.pageSize).then ( res => {
            if (res.data.map.resultList.length > 6) {
             this.swiperData = res.data.map.resultList.slice(0,6);
            } else {
             this.swiperData = res.data.map.resultList;
            }
            this.$nextTick (() => {
              this.doSwiper ();
            })
          }).catch(error => {
            console.log(error)
            this.$message({
                showClose: true,
                message: error,
                type: 'warning'
            });
          })
        },
        doSwiper: function () {
            $("div.wrapper").each(function (i, e) {
                $(e).attr("ondragstart", "return false");
            });
            var $demo1 = $("div.demo1");
            console.time("t");
            var carousel1 = new Carousel($demo1.children("ul.container"), {
                opacity: .9,
                scale: [.9],
                transition: "400ms",
                switchBtn: $demo1.children("i.btn-direct"),
                isClickCard: true,
                isAuto: true,
                interval: 4000
            });
            console.timeEnd("t");
        },
    }
})