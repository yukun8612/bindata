Vue.prototype.$http = axios;
Vue.config.errorHandler = (error, vm) => {
    console.log(error, '错误信息')
    vm.$message({
        showClose: true,
        message: error,
        type: 'warning'
    });
};
Newspaper.$http = axios;
// 使用一个vue实例 作为事件的载体,用于绑定事件和处理发送事件，作为调度中心
let Bus = new Vue();
// 创建-个vue实力
new Vue({
    el:'#wrap',
    // 定义属性，并设置初始值
    data:function () {
      return {
        inpSearchVal:'', // 输入框里面的内容
        // searchVal:'',
        library:{},
        archivesData:[],// 档案库数据
        archivesPageInfo: {
          pageNum:1,
          pageSize:3
        },
        downMenu:"标题",
        Spinner:[
            {title: '标题',val:'title'},
            {title:'副标题',val:'subTitle'},
            {title:'作者',val:'author'},
            {title:'档案馆',val:'archives'},
        ],
        EnglishName:'', // 检索时下拉框选中的值得英文名字
        isRetrievalContent:false, // 控制是否是普通检索中的检索全部和全文
      }
    },
    components:{
    },
    computed : {
    },
    created () {
      if (getUrlParam('searchVal') && getUrlParam('searchVal') != '') {
         this.inpSearchVal = getUrlParam('searchVal');
         this.btnRoute()
      }
    },
    mounted () {
      this.initialize ()
    },
    methods:{
        // 初始化加载数据
        initialize: function () {
          this.getLibrary ();
          this.getArchives ();
        },
        // 获取资源信息
        getLibrary: function () {
            Newspaper.getLibraryInfo().then(library => {
                this.library = library;  
             })
        },
        // 获取档案库数据
        getArchives: function () {
            this.$http.get('/api/module/researchChecked/'+(this.EnglishName == '' ? ' ' : this.EnglishName)+'/'+(this.inpSearchVal == '' ? ' ' : this.inpSearchVal)+'?pageNum='+this.archivesPageInfo.pageNum+'&pageSize='+this.archivesPageInfo.pageSize+'').then (res => {
              res.data.map.resultList.forEach(item => {
                // console.log(Base64.encode(item.linkAddr), 'dd')
                 item.linkAddr = Base64.encode(item.linkAddr)
              })
              this.archivesData = res.data.map.resultList;
              // this.archivesData[0].linkAddr = '/profile/download/%E9%98%BF%E9%87%8C%E5%B7%B4%E5%B7%B4Java%E5%BC%80%E5%8F%91%E6%89%8B%E5%86%8C%E7%BB%88%E6%9E%81%E7%89%88v1.3.0.pdf';
              // console.log(this.archivesData)
              this.getPage(res.data.recordCount)
            }).catch(error => {
              console.log(error, '检索错误信息');
              this.$message({
                  showClose: true,
                  message: this.error,
                  type: 'warning'
              });
            })
        },
        getPage:function (recordCount) {
            var that = this;
            var num = recordCount/this.archivesPageInfo.pageSize;
            if (Number.isInteger(num)) { // 判断num是不是整数
             var pageSize = parseInt(recordCount/this.archivesPageInfo.pageSize);
            } else {
             var pageSize = parseInt(recordCount/this.archivesPageInfo.pageSize) + 1;
            }
            if (pageSize == undefined) pageSize = 0;
             $("#page").paging({
                 pageNum: this.archivesPageInfo.pageNum, // 当前页面
                 pageSize: pageSize, // 总页码
                 totalList: recordCount, // 记录总数量
                 callback: function (num) { //回调函数
                     that.archivesPageInfo.pageNum = num;
                     that.getArchives ()
                 }
             });     
        },
        // 检索
        btnRoute: function () {
          switch(this.downMenu) {
            case '标题':
                this.EnglishName = 'title';
                break;
            case '副标题':
                this.EnglishName = 'subTitle';
                break;
            case '作者':
                this.EnglishName = 'author';
                break;
            case '档案馆':
                this.EnglishName = 'archives';
                break;
            default:
                this.EnglishName = '';

          }
          this.getArchives ()
        },
        searchEnterFun:function (e) {
          if (e.keyCode == 13) {
            this.btnRoute()
          }
        },
        CClick: function (item) {
            window.open('readingPage.html?articleId='+ item.id, 'readingPage');
        },
         // 点击检索的下拉框
        clitit: function (item) {
          this.downMenu = item.title;  
        },
    }
        
})