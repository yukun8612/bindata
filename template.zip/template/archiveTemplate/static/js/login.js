Vue.prototype.$http = axios;
Vue.config.errorHandler = (error, vm) => {
  console.log(error, '错误信息')
  vm.$message({
      showClose: true,
      message: error,
      type: 'warning'
  });
};
Newspaper.$http = axios;
// 创建-个vue实力
new Vue({
    el:'#app',
    // 定义属性，并设置初始值
    data:function () {
      var validateName = (rule, value, callback) => {
        console.log(value, '值')
        if (value == '') {
             callback(new Error('请输入用户名'));
         }else if (value.length < 2 || value.length > 20) {
             callback(new Error('用户名长度在2~20个字符之间，请重新输入您的用户名'));
         }
          else {
             callback();
         }
     }
     var validatePass = (rule, value, callback) => {
         if (value == '') {
             callback(new Error('请输入密码'));
         }else if (value.length < 5 || value.length > 20) {
             callback(new Error('密码长度在5~20个字符之间，请重新输入您的密码'));
         }
          else {
             callback();
         }
     }
      return {
        form:{
          username: '',   // 用户名
          password: '',   // 密码
          validateCode: '',     // 验证码
          rememberMe:false,
        },
        // 基本信息
        userInfo: {},
        library:{},
        rules:{
          username:[
              { required: true,validator:validateName,trigger: 'blur' }
          ],
          password:[
              { required: true, validator:validatePass,trigger: 'blur' }
          ]
      },
        error:'抱歉、数据请求失败'
      }
    },
    // 在模板渲染成html前调用，即通常初始化某些属性值，然后再渲染成视图。
    created () {
    },
    // 在模板渲染成html后调用，通常是初始化页面完成后，再对html的dom节点进行一些需要的操作
    mounted () {
      this.initialize ();
    },
    methods:{
       // 初始化加载数据
      initialize: function () {
        Newspaper.getUserInfo().then(userInfo => {
            this.userInfo = userInfo;
            if (this.userInfo.userType == "Visitor") { // 游客
                window.location.href = "login.html";
            } 
        });
        Newspaper.getLibraryInfo().then(library => {
          this.library = library;
        })
      },
      // 点击登录
      doSubmit:function (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
              var username = $("input[name='username']").val();
              var password = $("input[name='password']").val();
              var that = this;
              // $('#form').serialize()
              $.ajax({
                  type: "post",
                  url: "/login",
                  data: {
                      "username": username,
                      "password": password,
                      "validateCode" :'',
                      "rememberMe": false,
					  "uuid":localStorage.getItem('login.uuid_'+username)
                  },
                  success: function(res) {
                      if (res.code == 0) {
						  if(res.data != null)
						    localStorage.setItem('login.uuid_'+username, res.data);
                          window.location.href = 'index.html'
                      } else {
                          that.$message({
                              showClose: true,
                              message: res.msg,
                              type: 'warning'
                          });
                          that.form.username = '';
                          that.form.password = '';
                      }
                  }
              })
          } else {
              console.log('error submit!!');
              return false;
          }    
          
      });
      },
      // IP登录
      IPSubmit: function () {
        location.href = this.userInfo.baseUrl;
      },
      // 进入关于页面
      goAbout: function (txt) {
        if (txt == '购买申请') {
          window.location.href = 'purchaseApplication.html'; 
        } else {
          window.location.href = 'copyright.html';
        }
      }
    }
})