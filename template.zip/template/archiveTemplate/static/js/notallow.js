Vue.prototype.$http = axios;
// 创建-个vue实力
new Vue({
    el:'#app',
    // 定义属性，并设置初始值
    data:function () {
      return {
        error:'抱歉、数据请求失败'
      }
    },
    // 在模板渲染成html前调用，即通常初始化某些属性值，然后再渲染成视图。
    created () {
    },
    // 在模板渲染成html后调用，通常是初始化页面完成后，再对html的dom节点进行一些需要的操作
    mounted () {
    },
    methods:{

    }
})