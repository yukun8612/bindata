let watermark = {}

let setWatermark = (str) => {
    let id = '1.23452384164.123412416';

    // if (document.getElementById(id) !== null) {
    //     document.body.removeChild(document.getElementById(id));
    // }

    //创建一个画布
    let can = document.createElement('canvas');
    //设置画布的长宽
    can.width = 550;
    can.height = 200;

    let cans = can.getContext('2d');
    let wid = '300px'
    let hid = '200px'
        //旋转角度
    cans.rotate(3 * Math.PI / 180);
    cans.font = '100px Vedana';
    //设置填充绘画的颜色、渐变或者模式
    cans.fillStyle = 'rgba(200, 200, 200, 0.30)';
    //设置文本内容的当前对齐方式
    cans.textAlign = 'left';
    //设置在绘制文本时使用的当前文本基线
    cans.textBaseline = 'Middle';
    //在画布上绘制填色的文本（输出的文本，开始绘制文本的X坐标位置，开始绘制文本的Y坐标位置）
    cans.drawImage(str, can.width / 10, can.height / 58, 350, 150);
    var ReadingPage_rightTextbox = document.getElementById('readingPage_rightTextbox')
    let div = document.createElement('div');

    div.id = id;
    div.style.pointerEvents = 'none';
    div.style.top = 0;
    div.style.left = '55%';
    div.style.position = 'absolute';
    div.style.zIndex = '1000';
    // 100000
    div.style.width = 100 + '%';
    div.style.height = 100 + '%';
    div.style.background = 'url(' + can.toDataURL('image/png') + ') left top repeat';
    // div.style.opacity = 0.3

    ReadingPage_rightTextbox.appendChild(div);
    return id;
}

// 该方法只允许调用一次
watermark.set = (str) => {
    let id = setWatermark(str);
    // setInterval(() => {
    //     if (document.getElementById(id) === null) {
    //         id = setWatermark(str);
    //     }
    // }, 500);
    // window.onresize = () => {
    //     setWatermark(str);
    // };
}