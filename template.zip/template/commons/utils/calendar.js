var componentCalendar = {
    template: "#calendar",
    data() {
        return {
            // 接受控制日历的变量
            propsCanlendar: this.isCanlendar,
            calendarData: {},
            calendar: [],
            allYears: [],
            allMonths: [],
            year: '',
            month: '',
            page: {},
            ready: false
        }
    },
    props: ['isCanlendar'],
    watch: {
        year: function(val) {
            this.setCalendar(this.year, this.month);
            //   this.month = this.allMonths[0].value;
        },
        month: function(val) {
            this.setCalendar(this.year, this.month);
        },
    },
    computed: {},
    created() {
        this.$nextTick(() => {
            //  获取父组件paper数据
            Bus.$on('paper', ref => {
                    this.paper = ref;
                    this.handleDate(ref);
                })
                // 获取父组件page数据
            Bus.$on('page', ref => {
                    if (typeof ref.publishedDate != "undefined") {
                        this.page = ref;
                        this.year = ref.publishedDate.getFullYear();
                        this.month = ref.publishedDate.getMonth();
                        this.setCalendar(this.year, this.month)
                    }
                })
                // 获取父组件点击期次时的时间
            Bus.$on('publishedDate', ref => {
                this.year = new Date(ref).getFullYear();
                this.month = new Date(ref).getMonth();
                this.setCalendar(this.year, this.month)
            })
        })
    },
    mounted() {},
    methods: {
        //  设置日历
        setCalendar: function(year, month) {
            if (!this.ready) return;
            let date = new Date(year, month + 1, 0);
            let days = date.getDate();
            date.setDate(1);
            let delay = date.getDay();
            let calendar = new Array(delay + days);
            for (let i = 0; i < delay; i++) {
                calendar[i] = {
                    text: '',
                    enable: false //测试，enable记录该日期是否有报纸    
                }
            }
            for (let i = 1; i <= days; i++) {
                calendar[delay + i - 1] = {
                    text: String(i),
                    enable: false, //测试，enable记录该日期是否有报纸 
                    // style:'ui-state-default'                           
                }
            }
            this.calendar = calendar;
            if (this.calendarData[this.year][this.month] != undefined) {
                this.calendarData[this.year][this.month].forEach((item, n) => {
                    calendar[delay + item.day - 1].enable = true;
                    calendar[delay + item.day - 1].issueNo = item.issueNo;

                });
            }

            this.allYears = [];
            for (var key in this.calendarData) {
                this.allYears.push(parseInt(key));
            }
            this.allMonths = [];
            var monthText = ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"]
            for (var key in this.calendarData[this.year]) {
                this.allMonths.push({
                    value: parseInt(key),
                    text: monthText[key]
                });
            }
        },
        clickCalendar: function(item) {
            if (item.enable) {
                this.$parent.issueValue = item.issueNo;
                this.$parent.clickIssue();
                this.$parent.issueValue = ''
                Bus.$emit('childEvent', this.propsCanlendar);
            }
            // this.$parent.issueValue = item.issueNo;
            // this.$parent.clickIssue()
            // this.$parent.issueValue = ''
            // Bus.$emit('childEvent', this.propsCanlendar);
        },


        //  处理日期
        handleDate: function(paper) {
            var firstDate = new Date();
            paper.forEach(item => {
                var date = new Date(item.publishedDate);
                if (date < firstDate)
                    firstDate = date;
                // 保存年
                if (this.calendarData[date.getFullYear()] == undefined)
                    this.calendarData[date.getFullYear()] = {};
                // 保存月
                var month = this.calendarData[date.getFullYear()];
                if (month[date.getMonth()] == undefined)
                    month[date.getMonth()] = [];
                // 保存天
                var days = month[date.getMonth()];
                if (days.indexOf(date.getDate()) <= -1)
                    days.push({
                        day: date.getDate(),
                        issueNo: item.issueNo
                    });

            });
            this.ready = true;
            // this.year = new Date(firstDate).getFullYear();
            // this.month = new Date(firstDate).getMonth();
        }
    }
}