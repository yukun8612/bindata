
 /**
 * 防抖函数
 * @param method 事件触发的操作
 * @param delay 多少毫秒内连续触发事件，不会执行
 * @returns {Function}
 */
function debounce(method,delay) {
  let timer = null;
  return function () {
    // 获取函数的作用域和变量
      let self = this,
          args = arguments;
      timer && clearTimeout(timer);
      timer = setTimeout(function () {
          method.apply(self,args);
      },delay);
  }
}
// 封装ajax
function ajax(methods,url,callBack,text) {
  //步骤一:创建异步对象
  if(window.XMLHttpRequest){
      //  IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
      var xhr = new XMLHttpRequest()
  }else{
     // IE6, IE5 浏览器执行代码
      var xhr = new ActiveXObject("Microsoft.XMLHTTP")
  }
  //步骤二:设置请求的url参数,参数一是请求的类型,参数二是请求的url,可以带参数,
  // 给methods 一个默认值
  var methods = methods|| 'get' ;
  xhr.open(methods,url,true);
  //步骤三:发送请求
  // 如果是get请求，直接调用send方法发送请求
  if (methods== 'get'){
      xhr.send();
  }
  // 如果是post请求，则可配置请求参数
  if (methods=='post'){
      xhr.send(text);
  }
  //步骤四:注册事件 onreadystatechange 状态改变就会调用
  xhr.onreadystatechange=function(){
      if(xhr.readyState == 4){
          if(xhr.status== 200){
             //步骤五 如果能够进到这个判断 说明 数据 完美的回来了,并且请求的页面是存在的
              // 请求成功之后调用回调函数
              callBack(xhr.responseText);
          }else{
              let error = '错误码' + xhr.status
              callBack(error);
          }
      }
  }
}
function detectZoom (){ 
  var ratio = 0,
    screen = window.screen,
    ua = navigator.userAgent.toLowerCase();
 
   if (window.devicePixelRatio !== undefined) {
      ratio = window.devicePixelRatio;
  }
  else if (~ua.indexOf('msie')) {  
    if (screen.deviceXDPI && screen.logicalXDPI) {
      ratio = screen.deviceXDPI / screen.logicalXDPI;
    }
  }
  else if (window.outerWidth !== undefined && window.innerWidth !== undefined) {
    ratio = window.outerWidth / window.innerWidth;
  }
   
   if (ratio){
    ratio = Math.round(ratio * 100);
  }
   
   return ratio;
};
/**
 * 日期格式化
 * @param fmt yyyyMMddHHmmss
 * @returns {*}
 */

Date.prototype.pattern = function (fmt) {
  var o = {
    "M+": this.getMonth() + 1, //月份
    "d+": this.getDate(), //日
    "h+": this.getHours() % 12 == 0 ? 12 : this.getHours() % 12, //小时
    "H+": this.getHours(), //小时
    "m+": this.getMinutes(), //分
    "s+": this.getSeconds(), //秒
    "q+": Math.floor((this.getMonth() + 3) / 3), //季度
    "S": this.getMilliseconds() //毫秒
  };
  var week = {
    "0": "/u65e5",
    "1": "/u4e00",
    "2": "/u4e8c",
    "3": "/u4e09",
    "4": "/u56db",
    "5": "/u4e94",
    "6": "/u516d"
  };
  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
  }
  if (/(E+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, ((RegExp.$1.length > 1) ? (RegExp.$1.length > 2 ? "/u661f/u671f" : "/u5468") : "") + week[this.getDay() + ""]);
  }
  for (var k in o) {
    if (new RegExp("(" + k + ")").test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    }
  }
  return fmt;
};
// 时间的封装
function getTime(dt) {
  dt = new Date(Date.parse(dt.replace(/-/g,"/")));
  var year = dt.getFullYear();
  var month = dt.getMonth() + 1;
  var day = dt.getDate();
  var hour = dt.getHours();
  var min = dt.getMinutes();
  var s = dt.getSeconds();
  // 修改双位数
  month = month < 10 ? "0" + month : month;
  day = day < 10 ? "0" + day : day;
  hour = hour < 10 ? "0" + hour : hour;
  min = min < 10 ? "0" + min : min;
  s = s < 10 ? "0" + s : s;
  return year + "年" + month + "月" + day + "日";
}
//进行检查的工具函数.
 // 校验电话号
function isPhone (value){
    const isPhone = /^([0-9]{3,4}-)?[0-9]{7,8}$/; // 0571-86295197
    const isPhone02 = /^\d{3,4}-\d{3,4}-\d{3,4}$/; // 4001-550-520
    const isMob=/^[1][3,4,5,6,7,8,9][0-9]{9}$/;
    // const phone02 = /^0\d{2,3}-?\d{7,8}$/;
    const valuePhone = value.trim();
    if (isMob.test(valuePhone) || isPhone.test(valuePhone) || isPhone02.test(valuePhone)) { // 正则验证
        // callback(); // 校验通过
        return true;
    } else {
        // callback('请输入正确手机号或座机电话'); // 校验不通过
        return false;
    }
}
// 纯数字校验
function isNumberOnly(value){
  if(value === "" || value === "undefined" || value === null) return true;
  var reg = /^[0-9]*$/;
  return  reg.test(value);
}
//为空校验
function notEmpty(value){
  return typeof(value)!= "undefined" && !(value === "") && !(value === null);
}
 // 校验电话号
function checkTel(tel){
  if (tel === "" || tel === "undefined" || tel === null) return true;
    //  var isTel = /^\d{3}-\d{7,8}|\d{4}-\d{7,8}$/;
    var isPhone = /^([0-9]{3,4}-)?[0-9]{7,8}$/;
    var isMob=/^((\+?86)|(\(\+86\)))?(13[012356789][0-9]{8}|15[012356789][0-9]{8}|18[02356789][0-9]{8}|147[0-9]{8}|1349[0-9]{7})$/;
    //  var isMob = /^((0\d{2,3}-\d{7,8})|(1[3584]\d{9}))$/;
     if(isPhone.test(tel)){
      return isPhone.test(tel);
     }
     if (isMob.test(tel)) {
      return isMob.test(tel);
     }
     
}
 //校验电子邮箱
 function checkEmail(email){
  //为空不检查
  if(email === "" || email === "undefined" || email === null) return true;
  //	return /^[0-9a-z_][-_\.0-9a-z-]{0,63}@([0-9a-z][0-9a-z-]*\.)+[a-z]{2,4}$/.test(email); 
  return /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/.test(email);
}
// 校验姓名格式
function isName (name) {
    var xingming = /^([\u4E00-\u9FA5]|[·])*$/;
    var xingming1 = /^[A-Za-z0-9\(\)、.·-](\s{0,1}[A-Za-z0-9\(\)、.·-])+$/;
    if (xingming.test(name) || xingming1.test(name)) {
    } else {
        return false;
    }
    return true;
}
// 校验姓名长度
function checkNameLength (name) {
  var xingming = /^([\u4E00-\u9FA5]|[·])*$/;
  var xingming1 = /^[A-Za-z0-9\(\)、.·-](\s{0,1}[A-Za-z0-9\(\)、.·-])+$/;
  if (xingming.test(name)) {
      if (name.length < 101) {
      } else {
          return false;
      }
  } else {
      if (xingming1.test(name)) {
          if (name.length > 0 && name.length < 201) {
          } else {
              return false;
          }
      } else {
          return false;
      }
  }
  return true;
}
// 校验错误描述长度
function checkDescriptionLength (val) {
  var  miaoshu= /^([\u4E00-\u9FA5]|[·])*$/;
  var miaoshu1 = /^[A-Za-z0-9\(\)、.·-](\s{0,1}[A-Za-z0-9\(\)、.·-])+$/;
  if (miaoshu.test(val)) {
      if (val.length < 101) {
      } else {
          return false;
      }
  } else {
      if (miaoshu1.test(val)) {
          if (val.length > 0 && val.length < 201) {
          } else {
              return false;
          }
      } else {
          return false;
      }
  }
  return true;
}
/**
 * @Description:获取地址栏参数 
 * @author wangating
 * @date 2019-10-13 

 */
function getUrlParam (name) {
  var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
  var url = decodeURI(window.location.search)
  var r = url.substr(1).match(reg);
  if (r != null) return unescape(r[2]); return null;
}
/**
 * @Description:vue 自定义指令 【点击空白处让日历弹框消失的自定义指令】 
 * @author wangating
 * @date 2019-12-10 
*/
Vue.directive('clickoutside',{
  // 初始化指令
  bind(el, binding, vnode) { //bind：只调用一次，指令第一次绑定到元素时调用。在这里可以进行一次性的初始化设置。
    function documentHandler(e) {
        // 这里判断点击的元素是否是本身，是本身，则返回
        if (el.contains(e.target)) {
            return false;
        }
        // 判断指令中是否绑定了函数
        if (binding.expression) {
            // 如果绑定了函数 则调用那个函数，此处binding.value就是handleClose方法
            binding.value(e);
        }
    }
    // 给当前元素绑定个私有变量，方便在unbind中可以解除事件监听
    el.__vueClickOutside__ = documentHandler;
    document.addEventListener('click', documentHandler, false);
},
unbind(el, binding) {
    // 解除事件监听
    document.removeEventListener('click', el.__vueClickOutside__, false);
    delete el.__vueClickOutside__;
}
})
