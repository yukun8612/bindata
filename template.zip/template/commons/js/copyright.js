Vue.prototype.$http = axios;
Newspaper.$http = axios;
// 创建-个vue实力
new Vue({
  el: '#wrap',
  // 定义属性，并设置初始值
  data: function () {
    // 意见建议中的电话校验
    const validateTel = (rule, value, callback) => {
      if (!checkTel(value)) {
        callback(new Error('您输入的电话格式有误，请重新输入'))
      } else {
        callback();
      }
    };
    // 意见建议中的邮箱格式校验
    var validateEmail = (rule, value, callback) => {
      if (!checkEmail(value)) {
        callback(new Error('您输入的邮箱格式有误，请重新输入'))
      } else {
        callback();
      }
    };
    return {
      tabPosition: 'left',
      activeName: '56',
      opinion: {
        name: '',
        content: '',
        userName: '',
        tel: '',
        email: ''
      },
      rules: {
        content: [
          { required: true, message: '请输入建议内容', trigger: 'blur' }
        ],
        userName: [
          { required: true, message: '请输入姓名', trigger: 'blur' }
        ],
        tel: [
          { validator: validateTel, trigger: 'blur' }
        ],
        email: [
          { validator: validateEmail, trigger: 'blur' }
        ]
      },
      aboutConfig: '',
      copyrightConfig: '',
      contactConfig: '',
      copId: '56',
      userInfo: {
        loginName: ''
      },
      about: null,
      isAbout: false,
      // 用户权限
      permission: {},
      error: '抱歉、数据请求失败'
    }
  },
  // 在模板渲染成html前调用，即通常初始化某些属性值，然后再渲染成视图。
  created() {
    this.getIntroduce();
    //  获取地址栏参数
    if (getUrlParam('about') != null) {
      this.about = getUrlParam('about');
      this.judge(this.about);
    }
    if (getUrlParam('userType') != null) {
      var userType = getUrlParam('userType');
      if (userType == 'IPUser') {
        this.userInfo.userType = 'IPUser';
      }
      else if (userType == 'SysUser') {
        this.userInfo.userType = 'SysUser';
      }
    }
  },
  // 在模板渲染成html后调用，通常是初始化页面完成后，再对html的dom节点进行一些需要的操作
  mounted() {

    this.getItemInfoConfig();
    if (!this.isAbout) {
      this.getUserInfo();
    }
    this.getPermission();
  },
  methods: {
    getIntroduce: function () {
      this.$http.get('/api/module/info/' + this.copId).then(res => {

        if (res.data.code == 0) {
          this.aboutConfig = res.data.data.content;
        }

      })
    },
    handleClick(tab, event) {
      this.copId = tab.name;

      if (tab.name == 'login') {
        window.location.href = 'login.html';
      }
      this.getIntroduce();
    },
    // 获取用户信息
    getUserInfo: function () {
      Newspaper.getUserInfo().then(userInfo => {
        this.userInfo = userInfo;
      })
    },
    // 获取意见建议配置
    getItemInfoConfig: function () {
      this.$http.get('/api/library/itemInfoConfig').then(res => {
        if (res.data.code == 0) {
          // this.aboutConfig = res.data.data.itemInfoConfig.aboutConfig;
          this.copyrightConfig = res.data.data.itemInfoConfig.copyrightConfig;
          this.contactConfig = res.data.data.itemInfoConfig.contactConfig;
          // this.clientDownloadConfig = res.data.data.itemInfoConfig.clientDownloadConfig;
        } else {
          throw this.error = res.msg
        }
      }).catch(error => {
        console.log(error, '错误信息')
        this.$message({
          showClose: true,
          message: this.error,
          type: 'warning'
        });
      })
    },
    // 获取用户权限
    getPermission: function () {
      Newspaper.getPermission().then(permission => {
        this.permission = permission;
      })
    },
    // -------------------------- 业务事件处理 ------------------------
    judge: function (about) {
      console.log(123123123123)
      if (about == '联系我们') {
        this.activeName = 'contactUs';
      } else if (about == '意见建议') {
        this.activeName = 'suggestions';
      }
      this.isAbout = true;
    },
    // 意见建议表单提交
    onSubmit: function (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$http.get('/api/library/itemAdviseManage', {
            params: {
              adviseName: this.opinion.name,
              adviseContent: this.opinion.content,
              name: this.opinion.userName,
              tel: this.opinion.tel,
              email: this.opinion.email
            }
          }).then(res => {
            if (res.data.data == 1) {
              this.opinion.name = "",
                this.opinion.content = "",
                this.opinion.userName = "",
                this.opinion.tel = "",
                this.opinion.email = "",
                this.$message({
                  showClose: true,
                  message: '提交成功',
                  type: 'success'
                });
            } else {
              throw this.error = res.data.msg;
            }
          }).catch(error => {
            this.$message({
              showClose: true,
              message: '提交失败,请稍后再试',
              type: 'warning'
            });
          })
        } else {
          console.log('error submit');
          return false;
        }
      })
    },
    // 点击登录按钮
    signIn: function () {

      window.location.href = 'login.html';
    },
    // 后台管理
    management: function () {
      location.href = '/admin';
    },
    // 点击个人中心
    personalCenter: function () {
      window.location.href = 'personalCenter.html';
    },
    // 退出
    signOut: function (userType) {
      $.ajax({
        type: "post",
        url: "/logout",
        success: function (res) {
          location.href = 'login.html';
        }
      });
    },

  },
  computed: {
    newsTitle: function () {
      var newsTitles = {
        56: "责任说明",
        57: "版权信息",
        58: "免责声明",
        59: "编制体例",
        suggestions: "意见建议",
        contactUs: "联系我们",
        clientDownload: "客户端下载",
        login: "登录"
      }
      var newsTitle = ''
      // if(+this.copId===56||+this.copId===57||+this.copId===58||+this.copId===59){
      //   newsTitle = newsTitles[+this.copId]
      // }
      return newsTitles[this.activeName]
    }
  }
})