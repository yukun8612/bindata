/**
 * 网页注释操作类
 */
class Annotate {
    constructor(element) {
        this.element = element;
    }


    // 向前计算字符数量，先遍历previousSibling，如果为空，遍历父节点的previousSibling


    getSelectPos() {
        var container = this.element;

        function getTextPos(el) {
            if (el == container) //遍历结束
                return 0;
            var count = 0;
            // 计数前序的兄弟节点
            while (el.previousSibling != null) {
                el = el.previousSibling;
                count += el.textContent.trim().length;
            }
            // 计数父节点的前序节点
            count += getTextPos(el.parentNode);
            return count;
        }

        var selection = document.getSelection();
        if (selection.rangeCount > 0) {
            var range = selection.getRangeAt(0);
            return {
                begin: getTextPos(range.startContainer) + range.startOffset,
                end: getTextPos(range.endContainer) + range.endOffset,
                selectedText: range.toString()
            }
        }
    }

    /**
     * 根据位置查找对象
     */
    getElementByPos(pos) {
        function getElement(el, pos) {
            var count = 0;
            for (el = el.firstChild; el != null && (count + el.textContent.trim().length) <= pos; el = el.nextSibling) {
                count += el.textContent.trim().length;
            }
            if (el == null) return null;
            if (el.firstChild == null) return {
                el: el,
                pos: pos - count
            }
            return getElement(el, pos - count);
        }
        return getElement(this.element, pos);
    }

    /**
     * 选择文本
     * @param {*} start 
     * @param {*} end 
     */
    selectElement(start, end) {
        // var range = window.getSelection().getRangeAt(0);
        var range = document.createRange();
        window.getSelection().addRange(range);
        var start = this.getElementByPos(start);
        var end = this.getElementByPos(end);
        range.setStart(start.el, start.pos);
        range.setEnd(end.el, end.pos);
    }

    /**
     * 标记对象位置
     * @param {}} pos 
     */
    markElement(pos, newNode) {
        // var newNode = document.createElement("div");
        // newNode.innerHTML = "<img src='./static/images/icon/note.png' />"
        pos = this.getElementByPos(pos);
        // var range = window.getSelection().getRangeAt(0);
        var range = document.createRange();
        window.getSelection().addRange(range);
        range.setStart(pos.el, pos.pos);
        range.setEnd(pos.el, pos.pos);
        range.surroundContents(newNode);
        window.getSelection().empty();
    }
}