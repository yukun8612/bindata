Vue.prototype.$http = axios;
// 创建-个vue实力
new Vue({
    el:'#app',
    // 定义属性，并设置初始值
    data:function () {
      return {
        formItem:{
          username: '',   // 用户名
          password: '',   // 密码
          validateCode: '',     // 验证码
          rememberMe:false,
        },
        modal_loading:false,
        show_num: [],
        // 基本信息
        baseInfo: {},
        // 报纸库介绍数据
        paperText:'',
        isPass:false,
        isUser:false,
        error:'抱歉、数据请求失败'
      }
    },
    // 在模板渲染成html前调用，即通常初始化某些属性值，然后再渲染成视图。
    created () {
       this.$nextTick (() => {
        this.draw(this.show_num);
       })
    },
    // 在模板渲染成html后调用，通常是初始化页面完成后，再对html的dom节点进行一些需要的操作
    mounted () {
      this.validateRule();
      this.getUserInfo();
      this.getIntroduce ();
    },
    methods:{
      // 点击验证码
      getYZM: function () {
        this.draw(this.show_num);
      },
      //生成并渲染出验证码图形
      draw:function (show_num) {
        var canvas_width=$('#canvas').width();
        var canvas_height=$('#canvas').height();
        $('#canvas').css({
          'cursor': 'pointer'
        })
        var canvas = document.getElementById("canvas");//获取到canvas的对象，演员
        var context = canvas.getContext("2d");//获取到canvas画图的环境，演员表演的舞台
        canvas.width = canvas_width;
        canvas.height = canvas_height;
        var sCode = "a,b,c,d,e,f,g,h,i,j,k,m,n,p,q,r,s,t,u,v,w,x,y,z,A,B,C,E,F,G,H,J,K,L,M,N,P,Q,R,S,T,W,X,Y,Z,1,2,3,4,5,6,7,8,9,0";
        var aCode = sCode.split(",");
        var aLength = aCode.length;//获取到数组的长度
        
        for (var i = 0; i < 4; i++) {  //这里的for循环可以控制验证码位数（如果想显示6位数，4改成6即可）
            var j = Math.floor(Math.random() * aLength);//获取到随机的索引值
            // var deg = Math.random() * 30 * Math.PI / 180;//产生0~30之间的随机弧度
            var deg = Math.random() - 0.5; //产生一个随机弧度
            var txt = aCode[j];//得到随机的一个内容
            show_num[i] = txt.toLowerCase();
            var x = 10 + i * 20;//文字在canvas上的x坐标
            var y = 20 + Math.random() * 8;//文字在canvas上的y坐标
            context.font = "bold 23px 微软雅黑";

            context.translate(x, y);
            context.rotate(deg);

            context.fillStyle = this.randomColor();
            context.fillText(txt, 0, 0);

            context.rotate(-deg);
            context.translate(-x, -y);
        }
        for (var i = 0; i <= 5; i++) { //验证码上显示线条
            context.strokeStyle = this.randomColor();
            context.beginPath();
            context.moveTo(Math.random() * canvas_width, Math.random() * canvas_height);
            context.lineTo(Math.random() * canvas_width, Math.random() * canvas_height);
            context.stroke();
        }
        for (var i = 0; i <= 10; i++) { //验证码上显示小点
            context.strokeStyle = this.randomColor();
            context.beginPath();
            var x = Math.random() * canvas_width;
            var y = Math.random() * canvas_height;
            context.moveTo(x, y);
            context.lineTo(x + 1, y + 1);
            context.stroke();
        }
      },
    
      //得到随机的颜色值
      randomColor:function () {
        var r = Math.floor(Math.random() * 125);
        var g = Math.floor(Math.random() * 125);
        var b = Math.floor(Math.random() * 125);
        return "rgb(" + r + "," + g + "," + b + ")";
      },
      // 验证输入框
      validateRule: function () {
        var icon = "<i class='icon iconfont icon-Group-'></i> ";
        $("#signupForm").validate({
            rules: {
                username: {
                    required: true
                },
                password: {
                    required: true
                }
            },
            messages: {
                username: {
                    required: icon + "请输入您的用户名",
                },
                password: {
                    required: icon + "请输入您的密码",
                }
            }
        })
      },
      // 点击登录
      doSubmit:function (e) {
            e.preventDefault();
            var username = $("input[name='username']").val();
            var password = $("input[name='password']").val();
            var validateCode = $("input[name='validateCode']").val().toLowerCase();
            var rememberMe = $("input[name='rememberme']").is(':checked');
            var num = this.show_num.join("");
          if (username == '' && password == '') {
                this.$message({
                  showClose: true,
                  message: '请输入您的用户名和密码',
                  type: 'warning'
                });
          } else if (username == '' && password != '') {
            this.$message({
              showClose: true,
              message: '请输入您的用户名',
              type: 'warning'
            });
        }
         else if (username != '' && password == '') {
            if (username.length < 2 || username.length > 20) {
              this.$message({
                showClose: true,
                message: '用户名长度在2~20（包括2和20）个字符之间，请重新输入您的用户名',
                type: 'warning'
              });
            } else {
              this.$message({
                showClose: true,
                message: '请输入您的密码',
                type: 'warning'
              });
            }
        } else if (username !='' && password != '') {
            if (password.length < 5 || password.length > 20) {
              this.$message({
                showClose: true,
                message: '密码长度在5~20（包括5和20）个字符之间，请重新输入您的密码',
                type: 'warning'
              });
            } else if (validateCode == ''){
              this.$message({
                showClose: true,
                message: '请输入验证码',
                type: 'warning'
              });
            } else if (validateCode != num) {
                this.$message({
                  showClose: true,
                  message: '验证码输入有误，请重新输入',
                  type: 'warning'
                });
            } else {
              var that = this;
              $.ajax({
                  type: "post",
                  url: "/login",
                  data: {
                      "username": username,
                      "password": password,
                      "validateCode" : validateCode,
                      "rememberMe": rememberMe,
					  "uuid":localStorage.getItem('login.uuid_'+username)
                  },
                  success: function(res) {
                      if (res.code == 0) {
						  if(res.data != null)
						    localStorage.setItem('login.uuid_'+username, res.data);
                        console.log(document.referrer, '需要的')
                          window.location.href = 'index.html'
                          // if (document.referrer != null && document.referrer != "")
                          //     location.href = document.referrer;
                          // else
                          //     location.href = that.baseInfo.baseUrl;
                      } else {
                          that.$message({
                              showClose: true,
                              message: res.msg,
                              type: 'warning'
                          });
                          that.formItem.username = '';
                          that.formItem.password = '';
                          that.formItem.validateCode = '';
                      }
                  }
              });
              return false;
          }
        }
      },
      // IP登录
      IPSubmit: function (e) {
        e.preventDefault();
        location.href = this.baseInfo.baseUrl
      },
      getUserInfo: function () {
        this.$http.get('/api/user/info').then (res => {
           if (res.data.code == 0) {
             console.log(res.data.data, '信息')
             this.baseInfo = res.data.data;
           } else {
              throw error = '抱歉、数据查询失败'
           }
        }).catch(error => {
          this.$message({
              showClose: true,
              message: this.error,
              type: 'warning'
          });
     })
      },
      // 获取报纸库介绍
      getIntroduce: function () {
        this.$http.get('/api/module/info/'+ Config.Platform_Intro_id).then (res => {
           console.log(res, '报纸库')
           if (res.data.code == 0) {
             this.paperText = res.data.data.content;
           }
        })
      },
      // 进入关于页面
      goAbout: function (txt) {
        if (txt == '购买申请') {
          window.location.href = 'purchaseApplication.html'; 
        } else {
          window.location.href = 'copyright.html';
        }
      }
    }
})