Vue.prototype.$http = axios;
Vue.config.errorHandler = (error, vm) => {
  console.log(error, '错误信息')
  vm.$message({
      showClose: true,
      message: error,
      type: 'warning'
  });
};
// 创建-个vue实力
new Vue({
    el:'#wrap',
    // 定义属性，并设置初始值
    data:function () {
        var validatePass = (rule, value, callback) => {
            if (value == '') {
              callback(new Error('请输入旧密码'));
            } else if (value.length < 5 || value.length > 20) {
              callback(new Error('密码长度在5~20个字符之间，请重新输入您的旧密码'));
            } else {
              callback();
            }
        }
        var validatePass1 = (rule, value, callback) => {
            if (value === '') {
              callback(new Error('请输入新密码'));
            } else if (value.length < 5 || value.length > 20) {
              callback(new Error('密码长度在5~20个字符之间，请重新输入您的新密码'));
            } else if (this.formPassword.newPwd == this.formPassword.oldPwd) {
              callback(new Error('新密码不能和旧密码重复，请重新输入您的新密码'));
            }
            else {
              if (this.formPassword.confirmNewPwd !== '') {
                this.$refs.formPassword.validateField('confirmNewPwd');
              }
              callback();
            }
        };
        var validatePass3 = (rule, value, callback) => {
            if (value === '') {
              callback(new Error('请再次输入新密码'));
            }
            setTimeout(() => {
                  if (value !== this.formPassword.newPwd) {
                    callback(new Error('两次输入密码不一致!，请重新输入'));
                  } else {
                    callback();
                  }
            }, 1000);
        };
        // 修改信息中的电话校验
        var validateTel = (rule, value, callback) => {
          if (!checkTel(value)) {
             callback (new Error('您输入的电话格式有误，请重新输入'))
          } else {
            callback ();
          }
        };
        // 修改信息中的邮箱格式校验
        var validateEmail = (rule, value, callback) => {
          if (!checkEmail (value)) {
            callback (new Error('您输入的邮箱格式有误，请重新输入'))
          } else {
            callback ();
          }
        }
      return {
        formItem:{
          orgName: '',   // 所属机构
          name: '',   //用户名
          passWord: '',     // 密码
          workUnit:'',  // 工作单位
          job:'', // 职务
          sex:'', // 性别
          telphone:'', // 电话
          email:'', // 邮箱
        },
        formPassword:{
            oldPwd:'',
            newPwd:'',
            confirmNewPwd:''
        },
        rules:{
          oldPwd:[
            { required: true,validator:validatePass,trigger: 'blur' }
          ],
          newPwd:[
            { required: true,validator:validatePass1, trigger: 'blur' }
          ],
          confirmNewPwd:[
            { required: true, validator:validatePass3, trigger: 'blur' } 
          ]
        },
        userHistoryData:[],
        historyPageInfo: {
          currentPage: 1, //初始页
          pagesize: 6, //    每页的数据
        },
        modal_loading:false,
        show_num: [],
        // 基本信息
        baseInfo: {

        },
        isPass:false,
        isUser:false,
        centerTabList: [{
                title: "用户信息",
                tabItem:"myCenterOrder"
            },
            {
                title: "修改信息",
                tabItem:"myCenterHandle",
            },
            {
                title: "修改密码",
                tabItem:"myCenterCollection",
            },
            {
                title: "浏览记录",
                tabItem:"operationHistory",
             }
            // ,{
            //     title: "注释管理",
            //     tabItem:"myCenterPayment",
            // },
            // {
            //     title: "修改密码",
            //     tabItem:"myCenterLicence",
            // }
        ],
        userInfo:{}, // 用户信息容器
        userHistory:{},
        org:{}, // 机构信息
        curIndex:0,
        curTitle:'用户信息',
        // 修改信息中的表单验证
        ruleItem: {
          telphone:[
            {validator:validateTel, trigger: 'blur' } 
          ],
          email:[
            {validator:validateEmail, trigger: 'blur'}
          ]
        },
        error:'抱歉、数据请求失败'
      }
    },
    // 在模板渲染成html前调用，即通常初始化某些属性值，然后再渲染成视图。
    created () {

    },
    // 在模板渲染成html后调用，通常是初始化页面完成后，再对html的dom节点进行一些需要的操作
    mounted () {
      this.getUserInfo ();
      this.getUserHistory();
    },
    methods:{
      // 获取用户信息
      getUserInfo: function () {
        this.$http.get('/api/user/info').then (res => {
          if (res.data.code == 0) {
              let result = res.data.data;
              this.org = result.org;
              this.userInfo = result.userInfo;
              // this.formItem = result.userInfo;
              this.formItem.orgName = result.org.name;
              this.formItem.name = result.userInfo.name;
              this.formItem.workUnit = result.userInfo.workUnit;
              this.formItem.job = result.userInfo.job;
              this.formItem.sex = result.userInfo.sex;
              this.formItem.telphone = result.userInfo.telphone;
              this.formItem.email = result.userInfo.email;
              // 1女0男
              // this.formItem.sex = result.userInfo.sex == "1" ? "女" : "男";
          } else {
            throw error = '抱歉、数据查询失败'
          }
        }).catch (error => {
            this.$message({
                showClose: true,
                message: this.error,
                type: 'warning'
            });
        })
      },
      getUserHistory: function () {
        this.$http.get('/api/user/getUserHistory?pageNum='+this.historyPageInfo.currentPage+'&pageSize='+this.historyPageInfo.pagesize).then(res => {
          if (res.data != null) {
            if (res.data.map.userHistories.length > 0) {
              this.userHistoryData = res.data.map.userHistories;
              this.getPage (res.data.recordCount);
            }
          }
        }).catch (error => {
            this.$message({
                showClose: true,
                message: this.error,
                type: 'warning'
            });
        })
      },
      // 获取分页数据
      getPage:function (recordCount) {
        console.log(recordCount, '数量')
        var that = this;
        var num = recordCount%this.historyPageInfo.pagesize;
        if (num != 0) {
         var pageSize = parseInt(recordCount/this.historyPageInfo.pagesize) + 1; 
        }
          // console.log(num, pageSize)
         $("#page").paging({
             pageNum: this.historyPageInfo.currentPage, // 当前页面
             pageSize: pageSize, // 总页码
             totalList: recordCount, // 记录总数量
             callback: function (num) { //回调函数
                 console.log(num);
                 that.historyPageInfo.currentPage = num;
                 that.getUserHistory ()
             }
         });   
     },
     // 点击人名导航table中每一行数据
       toRead: function (item) {
        console.log(item)
        window.location.href = 'readingPage.html?paperId=' + item.paperId + '&issueNo=' + item.issueNo + '&pageNo=' + item.pageNo
      },
      clickTab: function (item, i) {
        this.curTitle = item.title;
        this.curIndex = i;  
      },
      // 点击修改信息里面的提交
      onSubmit: function (formName) {
        this.$refs[formName].validate((valid) => {
           if (valid) {
              this.formItem.id = this.userInfo.id;
                this.$http.post('/api/user/info',
                  $('#formItem').serialize()
                ).then (res => {
                  if (res.data.code == 0) {
                      this.$message({
                        showClose: true,
                        message: res.data.msg,
                        type: 'success'
                      });
                      this.getUserInfo()
                  } else {
                    throw this.error = res.data.msg;
                  }
                }).catch (error => {
                    this.$message({
                        showClose: true,
                        message: this.error,
                        type: 'warning'
                    });
              })
           } else {
            console.log('error submit!!');
            return false;
           }
        })
      },
      // 点击修改信息里面的取消按钮
      onCancel: function (formName) {
        this.$refs[formName].resetFields();
      },
      resetForm: function (formName) {
        this.$refs[formName].resetFields();
      },
      // 点击修改密码里面的保存
      onSave: function (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
               this.$http.post('/api/user/info', 
                   $('#form1').serialize()
                ).then (res => {
                  if (res.data.code == 0 && res.data.data == 1) {
                      this.$message({
                        showClose: true,
                        message: res.data.msg,
                        type: 'success'
                      });
                      // this.$refs[formName].resetFields();
                  } else {
                     throw this.error = res.data.msg;
                  }
                }).catch (error => {
                    this.$message({
                        showClose: true,
                        message: this.error,
                        type: 'warning'
                    });
                }) 
            
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      }
    }
})