/**
 * 透镜类
 */
class Lens{
    constructor(ctx, w, h){
        this.ctx = ctx;
        this.w = w;
        this.h = h;
    }
    draw(){
        this.ctx.save();
        this.ctx.beginPath();
        this.ctx.globalCompositeOperation = 'destination-out'
        this.ctx.fillRect(0, 0, this.w, this.h);
        this.ctx.fill();
        this.ctx.restore();
    }
    move(x, y){

    }
    reset(w, h, r){
        this.w = w;
        this.h = h;
    }
}
/**
 * 圆形透镜
 */
class ArcLens extends Lens {
  constructor(ctx, x, y, r) {
    super();
    this.ctx = ctx;
    this.x = x;
    this.y = y;
    this.r = r;
  }
    drawGradient(x0, y0, x1, y1){
        var g = this.ctx.createLinearGradient(0, y0, 0, y1);
        g.addColorStop(0,   'rgba(0, 0, 0, 0)');
        g.addColorStop(0.1, 'rgba(255, 255, 255, 1)');
        g.addColorStop(0.9, 'rgba(255, 255, 255, 1)');
        g.addColorStop(1,   'rgba(0, 0, 0, 0)');
        this.ctx.fillStyle = g;
    }
  /**
   * 绘制透镜
   */
  draw() {
    this.ctx.save();
    this.ctx.beginPath();
    this.ctx.globalCompositeOperation = 'destination-out'
    this.drawGradient(this.x - this.r, this.y - this.r, this.x + this.r, this.y + this.r);
    this.ctx.arc(this.x, this.y, this.r, 0, 2 * Math.PI);
    this.ctx.fill();
    this.ctx.restore();
  }
  move(x, y){
      this.x = x;
      this.y = y;
  }
  reset(w, h, r){
     this.r = r;
  }
}

/**
 * 矩形透镜
 */
class RectLens extends Lens{
    constructor(ctx, t, w, h) {
        super();
        this.ctx = ctx;
        this.t = t;
        this.w = w;
        this.h = h;
      }
      drawGradient(x0, y0, x1, y1){
        var g = this.ctx.createLinearGradient(0, y0, 0, y1);
        g.addColorStop(0,   'rgba(0, 0, 0, 0)');
        g.addColorStop(0.1, 'rgba(255, 255, 255, 1)');
        g.addColorStop(0.9, 'rgba(255, 255, 255, 1)');
        g.addColorStop(1,   'rgba(0, 0, 0, 0)');
        this.ctx.fillStyle = g;
      }
      /**
       * 绘制透镜
       */
      draw() {
        this.ctx.save();
        this.ctx.beginPath();
        this.ctx.globalCompositeOperation = 'destination-out';
        this.drawGradient(0, this.t, this.w, this.t + this.h);
        this.ctx.fillRect(0, this.t, this.w, this.h);
        this.ctx.fill();
        this.ctx.restore();
      }
      move(x, y){
          this.t = y - this.h/2;
      }
      reset(w, h, r){
          this.w = w;
          this.h = r;
      }
    
}
/**
 * 视口对象
 */
class View {
  /**
   * 初始化视图
   * @param {*} element Canvas对象
   * @param {*} size  透镜大小
   */
  constructor(element, type, size) {
    this.element = element;
    // 装载背景图
    this.img = new Image();
    this.img.src = "./static/images/bg/grid1.jpg";
    this.img.addEventListener("load",  e =>{this.update()});
    // 监听元素父窗口变化
    if ('ResizeObserver' in window) {new ResizeObserver(e => {this.reset();}).observe(this.element.parentElement)};
    this.ctx = this.element.getContext("2d");
    this.lensSize = size;
    //初始化透镜对象
    this.createlens(type);
    
    this.x = this.y = this.lensSize/2 - this.lensSize * 0.1;
    this.update();


    /**
     * 检测鼠标事件
     */
    window.addEventListener("mousemove", e => {
      if (this.mouseIn(e.clientX, e.clientY)){
        var el = this.element.getBoundingClientRect();
        this.x = e.clientX - el.left;
        this.y = e.clientY - el.top;
        this.update();
      }
    });
  }

  createlens(type){
      if ( type == 'none' )
          this.lens = new Lens(this.ctx, this.element.width, this.element.height);
      else if (type == "rect")
          this.lens = new RectLens(this.ctx, 0, this.element.width, this.lensSize);
      else
          this.lens = new ArcLens(this.ctx, this.lensSize/2, this.lensSize/2, this.lensSize/2);
  }

  mouseIn(x, y){
    var border = this.lensSize * 0.1;//透镜的虚化边缘大小
    var el = this.element.getBoundingClientRect()
    var rect = {
      l : el.left + this.lensSize /2 - border,
      r : el.right - this.lensSize /2 + border,
      t : el.top + this.lensSize /2 - border,
      b : el.bottom -this.lensSize /2 + border
    };
    return x > rect.l && x < rect.r && y>rect.t && y <rect.b;
  }
  //更新视口
  update() {
    this.clear();
    this.draw();
  }

  //清屏
  clear() {
    this.ctx.clearRect(0, 0, this.element.width, this.element.height);
    this.ctx.save();
    this.ctx.fillStyle="rgba(255,255,255, 0.6)";
    this.ctx.fillRect(0, 0, this.element.width, this.element.height);
    if (this.img.complete){
        this.ctx.globalAlpha = 0.75;
        var pat = this.ctx.createPattern(this.img, "repeat");
        this.ctx.rect(0, 0, this.element.width, this.element.height);
        this.ctx.fillStyle = pat;
        this.ctx.fill();
        this.ctx.globalAlpha = 1;
    }
    this.ctx.restore();
  }

  //绘制
  draw() {
      this.lens.move(this.x, this.y);
      this.lens.draw();
      // this.watermarking();
  }
  reset(type, lensSize){
      if (type != null)  this.createlens(type);
      if ( lensSize != null ) this.lensSize = lensSize;
      this.x = this.y = this.lensSize/2 - this.lensSize * 0.1;
      var pEle = this.element.parentElement;
      if ( pEle != null){
        this.element.setAttribute("width", pEle.clientWidth + ".px");
        this.element.setAttribute("height", pEle.clientHeight + ".px");
        this.lens.reset(pEle.clientWidth, pEle.clientHeight, this.lensSize*24);
        this.update();
      }
  }

    /**
     * 绘制水印
     */
    watermarking() {
        var ox = this.element.width / 2;
        var oy = this.element.height / 2;
        this.ctx.save();
        this.ctx.font = "bold 100px  黑体";
        this.ctx.textAlign = "center";
        this.ctx.textBaseline = "middle";
        this.ctx.strokeStyle = "rgba(100, 100, 100, 0.3)";
        this.ctx.translate(ox, oy); // 将画布的原点移动到正中央
        this.ctx.rotate((Math.PI / 180) * 45); // 弧度 = (Math.PI/180)*角度
        this.ctx.strokeText("延安大学", 0, 0);
        this.ctx.translate(-ox, -oy); // 将画布
        this.ctx.restore();
    }
}
