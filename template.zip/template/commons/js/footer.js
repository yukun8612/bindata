Vue.prototype.$http = axios;
Newspaper.$http = axios;
// 创建-个vue实力
new Vue({
    el:'#footer',
    // 定义属性，并设置初始值
    data:function () {
      return {
        linkData:[],
        error:'抱歉、数据请求失败'
      }
    },
    created () {},
    mounted () {
      this.getLibId();
    },
    methods:{
      getLibId: function () {
        Newspaper.getUserInfo().then (userInfo => {
           this.getFriendshiplink(userInfo.libId);
        }) 
      },
      // 获取友情链接数据
      getFriendshiplink: function (libId) {
        this.$http.get('/api/library/link_item/'+libId).then (res => {
          if (res.data.code == 0) {
             this.linkData = res.data.data;
          } else {
            throw this.error = '数据查询失败'
          }
        }).catch (error => {
          console.log(error, '错误信息')
          this.$message({
              showClose: true,
              message: error,
              type: 'warning'
          });  
        })
      }  
    }
})