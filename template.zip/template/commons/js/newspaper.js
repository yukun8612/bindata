﻿/**
 * 封装后台接口的调用
 */
let Newspaper = {
    userInfo : null,
    libraryInfo : null,
    $http: {},
    /**获取资源库信息 **/
    getLibraryInfo() {
        return new Promise((resolve, reject) => {
            if ( this.libraryInfo == null){
                this.$http.get('/api/library/info'+ '?f=' + location.hostname + location.pathname).then(res => {
                    if (res.data.code == 0) {
                        this.libraryInfo = res.data.data;
                        resolve(res.data.data);
                    } else {
                        throw this.error = '获取资源库信息失败'
                    }
                })    
            }else{
                resolve(this.libraryInfo);
            }
        })
    },

    /**获取用户信息 */
    getUserInfo() {       
        return new Promise((resolve, reject) => {
            if ( this.userInfo == null){
                this.$http.get('/api/user/info').then(res => {
                    if (res.data.code == 0) {
                        this.userInfo = res.data.data;
                        resolve(res.data.data);
                    } else {
                        throw this.error = '获取用户信息失败'
                    }
                })
            }else{
                resolve(this.userInfo);
            }
        })
    },

    /**获取报刊信息 */
    getPapers() {
        return new Promise((resolve, reject) => {
            this.$http.get('/api/newspaper/papers').then(res => {
                if (res.data.code == 0) {
                    resolve(res.data.data);
                } else {
                    throw this.error = '获取报刊列表信息失败'
                }
            })
        })
    },
    /**获取报纸信息 */
    getPaper: function(paperId, issueNo) {
        return new Promise((resolve, reject) => {
            this.$http.get('/api/newspaper/paper/' + paperId).then(res => {
                if (res.data.code == 0) {
                    if (res.data.data.length == 0) {
                        throw this.error = '抱歉、数据为空'
                    } else {
                        resolve(res.data.data);
                    }
                } else {
                    //    抛出异常
                    throw this.error = '抱歉、报纸数据出错，' + paperId + "," + issueNo;
                }
            })
        })
    },
    /**获取文章信息 */
    getArticle: function (articleId) {
        return new Promise((resolve, reject) => {
            this.$http.get('/api/newspaper/article/' + articleId).then(res => {
                if (res.data.code == 0 && res.data.data != null) {
                    resolve(res.data.data);
                } else {
                    throw this.error = '文章数据为空'
                }
            })
        })
    },
    /**获取用户权限信息 */
    getPermission: function () {
        return new Promise((resolve, reject) => {
            this.$http.get('/api/user/permission/').then(res => {
                if (res.data.code == 0) {
                    resolve(res.data.data);
                } else {
                    throw this.error = '获取用户权限数据出错';
                }
            })
        })
    }
    


}