Vue.prototype.$http = axios;
// 创建-个vue实力
new Vue({
    el:'#wrap',
    // 定义属性，并设置初始值
    data:function () {
      var checkphone = (rule, value,callback)=>{
          if (!value){
              callback(new Error('请输入联系电话'))
          }else  if (!isPhone(value)){
          callback(new Error('请输入正确的手机号码'))
          }else {
              callback()
          }
      };
      return {
        active:'1',
        current:1,
        buyForm:{
          name:'',
          content:'',
          tel:'',
          email:'',
          buyGroup:'',
          selectService:'',
          company:'',
          job:'',
          email:''
        },
        // 购买申请校验
        buyRules: {
          buyGroup: [
            { required: true, message: '请选择购买群体', trigger: 'change' }
          ],
          selectService:[
            { required: true, message: '请选择服务', trigger: 'change'}
          ],
          name: [
            { required: true, message: '请输入姓名', trigger: 'blur' }
          ],
          company: [
            { required: true, message: '请输入单位', trigger: 'blur' }
          ],
          job:[
            { required: true, message: '请输入职务', trigger: 'blur' }
          ],
          tel:[
            { required: true, message: '请输入联系电话', trigger: 'blur' },
            {required: true, validator:checkphone, trigger:'blur'}
          ],
          email: [
            { required: true, message: '请输入邮箱地址', trigger: 'blur' },
            { type: 'email', message: '请输入正确的邮箱地址', trigger: ['blur', 'change'] }
          ],
          content: [
            { required: true, message: '请输入需求描述', trigger: 'blur' }
          ]
        },
        buyCodeList:[],
        about:null,
        buyApplyExplain:'',
        error:'抱歉、数据请求失败'
      }
    },
    // 在模板渲染成html前调用，即通常初始化某些属性值，然后再渲染成视图。
    created () {
    },
    // 在模板渲染成html后调用，通常是初始化页面完成后，再对html的dom节点进行一些需要的操作
    mounted () {
        this.getItemInfoConfig();
        this.getLibraryBuyApply();
    },
    methods:{
      // 获取购买申请配置
      getItemInfoConfig: function () {
        this.$http.get('/api/library/itemInfoConfig').then(res => {
          if (res.data.code == 0) {
            // this.buyApplyExplain = res.data.data.itemInfoConfig.buyApplyExplain;
            this.buyCodeList = res.data.data.buyCodeList;
            // $("#buyApplyExplain").html(this.buyApplyExplain);
            console.log(this.buyCodeList)
            // this.copyrightConfig = res.data.data.itemInfoConfig.copyrightConfig;
          } else {
            throw this.error = res.msg
          }
        }).catch(error => {
          console.log(error, '错误信息')
          this.$message({
              showClose: true,
              message: this.error,
              type: 'warning'
          });
        })
      },
      // 获取报纸库购买申请说明
      getLibraryBuyApply: function () {
        this.$http.get('/api/library/libraryBuyApply').then(res => {
          console.log(res)
          if (res.data.code == 0) {
            this.buyApplyExplain = res.data.data.buyApplyExplain;
            // $("#buyApplyExplain").html(this.buyApplyExplain);
          } else {
            throw this.error = res.msg
          }
        }).catch(error => {
          console.log(error, '错误信息')
          this.$message({
              showClose: true,
              message: this.error,
              type: 'warning'
          });
        })
      },
      // 购买申请表单提交
      onSubmit: function (formName) { 
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.$http.get('/api/library/itemBuyApply',{
               params: {
                  orgType:this.buyForm.buyGroup,
                  serviceType:this.buyForm.selectService,
                  name:this.buyForm.name,
                  company:this.buyForm.company,
                  job:this.buyForm.job,
                  tel:this.buyForm.tel,
                  email:this.buyForm.email,
                  content:this.buyForm.content
               }
            }).then (res => {
                if (res.data.data == 1) {
                  // this.buyForm.buyGroup="",
                  // this.buyForm.selectService="",
                  // this.buyForm.name="",
                  // this.buyForm.company="",
                  // this.buyForm.job="",
                  // this.buyForm.tel="",
                  // this.buyForm.email="",
                  // this.buyForm.content="",
                  this.$message({
                      showClose: true,
                      message: '申请提交成功',
                      type: 'success'
                  });
                  this.clearForm(formName);
                } else {
                   throw this.error = res.data.msg;
                }
            }).catch (error => {
                  this.$message({
                      showClose: true,
                      message: '提交失败,请稍后再试',
                      type: 'warning'
                  });
            })
          } else {
              console.log('error submit');
              return false;
          }
        })
      },
      clearForm: function (formName) {
        this.$refs[formName].resetFields();
      }
    }
})