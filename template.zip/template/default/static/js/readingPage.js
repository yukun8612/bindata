Vue.prototype.$http = axios;
// axios.defaults.baseURL = 'http://59.108.36.232';
// axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
Vue.config.errorHandler = (error, vm) => {
    console.log(error, '错误信息')
    vm.$message({
        showClose: true,
        message: error,
        type: 'warning'
    });
};
vueObj = new Vue({
    el: '#app',
    data: function () {
        //定义一个全局的变量，校验手机号
        var checkphone = (rule, value,callback)=>{
            if (!value){
                callback(new Error('请输入联系电话'))
            }else  if (!isPhone(value)){
            callback(new Error('请输入正确的手机号码'))
            }else {
                callback()
            }
        };
        // 校验姓名
        var checkname = (rule, value, callback) => {
           if (!value) {
              callback (new Error ('请输入您的姓名'));
           } else if (!isName(value)) {
              callback (new Error ('姓名格式不正确'))
           } else if (!checkNameLength(value)) {
             callback (new error('姓名长度不能少于2字符且不能大于50字符（1汉字=2个字符）'))
           } else {
             callback()
           }
        }
        // 校验错误描述
        var checkwrongDescription = (rule, value, callback) => {
          if (!isName(value)) {
             callback (new Error ('错误描述格式不正确'));
          } else if (!checkNameLength(value)){
            callback (new Error('错误描述长度不能少于2字符且不能大于200字符（1汉字=2个字符）')) 
          } else {
             callback()
          }
        }
        return {
            allTitle: '',
            // 左侧控制热区数据
            hotSpan: {
                title: '',
                id: '',
                style: ''
            },
            // 右侧数据
            shHide: 'block',
            deficiencyTitleHeight: '',
            // 右侧子数据
            issueValue: '',
            paper: [], // 右侧期面容器
            issue: {},
            //左侧当前打开的版
            page: {
                // paperId:'',
                issueNo: '', // 期版id
                pageNo: '', // 版面id
            },
            //右侧当前显示的文章
            article: {},
            //用户权限
            permission: {},
            // 右侧报纸期次列表
            // 当前的paperId
            paperId: '',
            articleId:'', // 文章id
            error: '抱歉、数据请求失败',
            // 有奖纠错
            disputeVisible: false,
            disputeForm: {
                userName: '',
                userContact: '', // 用户联系方式
                description: '', // 错误描述
                images: '', // 截图
            },
            // 有奖纠纷校验规则
            disputeRules: {
                userName: [
                    { required: true, message: '请输入您的姓名', trigger: 'blur' },
                    { required: true, validator:checkname, trigger:'blur'}
                ],
                userContact: [
                    { required: true, message: '请输入您的联系电话', trigger: 'blur' },
                    {required: true, validator:checkphone, trigger:'blur'}
                ],
                description: [
                    { required: true, message: '请输入您的错误描述', trigger: 'blur' },
                    {required:true, validator:checkwrongDescription, trigger:'blur'}
                ],
                // screenshot: [
                //     { required: true, message: '请上传您的截图', trigger: 'blur' }
                // ]
            },
            // 打印、复制、下载
            dialogVisible: false,
            jurisdictionTotal:'', // 下载、打印、复制弹框头部的权限信息
            jurisdictionNuit:'', // 单位（年、月、日）
            jurisdictionSurplus:'', // 剩余篇数

            form: {
                userName: '', // 真实姓名
                workUnit: '', // 单位
                contact: '', // 联系电话
                description: '', //用途描述
            },
            // 下载、打印、复制校验规则
            formRules: {
                userName: [
                    { required: true, message: '请输入您的姓名', trigger: 'blur' },
                    { required: true, validator:checkname, trigger:'blur'}
                ],
                contact: [
                    { required: true, message: '请输入您的联系电话', trigger: 'blur' },
                    {required: true, validator:checkphone, trigger:'blur'}
                ],
                description: [
                    { required: true, message: '请输入您的用途描述', trigger: 'blur' },
                    {required:true, validator:checkwrongDescription, trigger:'blur'}
                ]
            },

            // 注释部分
            notesVisible:false,
            notesForm:{
                description:''
            },
            notesRules:{
                description: [
                    { required: true, message: '请输入您的注释描述', trigger: 'blur' },
                    {required:true, validator:checkwrongDescription, trigger:'blur'}
                ]  
            },
            scrollTop: 0,
            container: {//窗口大小
                width: 1090,
                height: 694
            },
            // 蒙层对象
            lensView: null,
        }
    },
    computed: {},
    created() {
        if (this.getUrlParam('paperId') != '') {
            this.paperId = this.getUrlParam("paperId")
        }
        if (this.getUrlParam("issueNo") != '') {
            this.page.issueNo = this.getUrlParam('issueNo')
        }
        if (this.getUrlParam("pageNo") != '') {
            this.page.pageNo = this.getUrlParam("pageNo")
        }
        if (this.getUrlParam('articleId') != '') {
          this.articleId = this.getUrlParam('articleId');
        }
    },
    mounted() {
        this.initialize();
        this.initViewer();
        this.setPasteImg();
        // 调用屏幕滚动事件 
        //  注意是将事件绑定在window上，监听整个文档的滚动，也可以绑在document或者document.body上
        //  需要在元素加载之后再监听滚动事件 
        // 需要将addEventListener的第三个参数设置为true，即取消冒泡，要不然会绑定不成功
        this.$nextTick(function () {
            window.addEventListener('scroll', this.handleScroll, true);
            document.addEventListener('copy', function(event){
                console.log(this, 'this指向')
                // setClipboardText(event);
            });
        });
        window.addEventListener('resize', e => {
            this.resetContainer();
        });
        this.magnifier()
        this.getChoose ();
    },
    destroyed() {
        window.addEventListener('scroll', this.handleScroll, true);
    },
    methods: {
        // 初始化加载数据
        initialize: function () {
            var articleId = this.getUrlParam("articleId");
            var paperId = this.getUrlParam("paperId");
            var pageNo = this.getUrlParam('pageNo');
            var issueNo = this.getUrlParam('issueNo');
            var _this = this;
            // 如果没有pageNo, issueNo 只有paperId 择显示列表页
            if ((pageNo == null || issueNo == null) && paperId != null) {
                this.shHide = "none";
            } else {
                this.shHide = "block";
            }
            this.getPermission();
            if (paperId == null && articleId != null) {
                this.getArticle(articleId).then(
                    article => {
                        this.getPaper(article.paperId, article.issueNo).then(
                            paper => {
                                this.getPage(article.paperId, article.issueNo, article.pageNo, articleId);
                            }
                        )
                    }
                )
            } else if (paperId != null) {
                this.getPaper(paperId, issueNo).then(
                    paper => {
                        if (issueNo == null)
                            issueNo = paper[0].issueNo;
                        if (pageNo == null)
                            pageNo = paper[0].pages[0].pageNo;
                        this.getPage(paperId, issueNo, pageNo);
                    }
                )
            }
        },
        // 获取某报纸期次列表
        getPaper: function (paperId, issueNo) {
            return new Promise((resolve, reject) => {
                this.$http.get('/api/newspaper/paper/' + paperId
                ).then(res => {
                    if (res.data.code == 0) {
                        if (res.data.data.length == 0) {
                            throw this.error = '抱歉、数据为空'
                        } else {
                            this.paper = res.data.data; //报纸对象
                            if (issueNo == null)
                                this.issue = this.paper[0]; //期对象
                            else
                                this.paper.forEach((item, index) => {
                                    if (item.issueNo == issueNo)
                                        this.issue = item;
                                })
                            resolve(res.data.data);
                        }
                    } else {
                        //    抛出异常
                        throw this.error = '抱歉、数据查询失败';
                    }
                })
            })
        },
        getPage: function (paperId, issueNo, pageNo, articleId) {
            return new Promise((resolve, reject) => {
                this.$http.get('/api/newspaper/page/' + paperId + '/' + issueNo + '/' + pageNo
                ).then(res => {
                    if (res.data.code == 0) {
                        if (res.data.data.length == 0) {
                            throw this.error = '抱歉、数据为空'
                        } else {
                            this.handlePage(res.data.data, articleId)
                        }
                        resolve(res.data.data);

                    } else {
                        throw "null data";
                    }
                })
            })
        },
        // 获取文章
        getArticle: function (articleId) {
            return new Promise((resolve, reject) => {
                this.$http.get('/api/newspaper/article/' + articleId).then(res => {
                    if (res.data.code == 0 && res.data.data.length != 0) {
                        resolve(res.data.data);
                    } else {
                        throw error = '文章数据为空'
                    }
                })
            })
        },
        // 处理初始数据
        handlePage: function (data, articleId) {
            // 判断将处理的数据是否为数组，如果是返回true、 否则返回false、

            var articles = new Array();
            data.forEach((item, index) => {
                //此处需要处理多矩形情况
                var hotArray = [];
                item.hotspot.split('/').forEach((hotstr, index) => {
                        var hots = hotstr.split(',');
                        //刊的热区是全文
                        if (hots.length < 4) hots = [0, 0, 412, 586];
                        var hot = {
                            l: hots[0] / 412,
                            t: hots[1] / 586,
                            r: hots[2] / 412,
                            b: hots[3] / 586,
                            toString: function(img) {
                                return this.l * img.offsetWidth + ',' + this.t * img.offsetHeight + ',' +
                                    this.r * img.offsetWidth + ',' + this.b * img.offsetHeight;
                        }
                    }    
                    hotArray.push(hot);
                });
                if (this.issue.paperType == 2)
                    item.relatedPages = item.relatedPages.split(","); //分隔文章跨版
                else
                    item.relatedPages = [];
                //设置已读信息
                var ids = this.permission.newspaper.readedResIds;
                if (ids && ids.indexOf(item.id) > -1) item.readed = true;

                articles.push({
                    hot: hotArray,
                    title: item.title,
                    data: item,
                    id : item.id
                });
            })
            this.page = {
                img: data[0].pageImageSmall,
                pageNo: data[0].pageNo,  // 版面
                issueNo: data[0].issueNo, // 期次id
                hasNext: this.issue.pages[this.issue.pages.length - 1].pageNo != data[0].pageNo,
                hasPre: this.issue.pages[0].pageNo != data[0].pageNo,
                articles: articles,
                id: data[0].id
            }
            if (articleId == null)
                this.article = this.page.articles[0].data;
            else
                this.page.articles.forEach((item, index) => {
                    if (item.data.id == articleId)
                        this.article = item.data;
                })
            document.title = this.article.paperName;
            // 将分页的状态给右边版本状态

        },
        //获取用户权限
        getPermission: function () {
            return new Promise((resolve, reject) => {
                this.$http.get('/api/user/permission/'
                ).then(res => {
                    if (res.data.code == 0 && res.data != null) {
                        this.permission = res.data.data;
                    } else {
                        throw this.error = '抱歉、用户权限数据为空';
                    }
                    if (this.lensView != null)
                        this.lensView.reset(this.permission.newspaper.shadowType, this.permission.newspaper.shadowSize);
                    resolve(res.data.data);
                })
            })
        },
        // 放大图片
        initViewer: function () {
            const ViewerDom = document.getElementById('version_period');
            const viewer = new Viewer(ViewerDom, {
                // 配置
                'button': true, // 显示右上角关闭按钮
                'loading': true,
                show: function () { // 动态加载图片后，更新实例
                    viewer.update();
                },
            })
            this.resetContainer();
        },
        // 模糊放大读文章
        magnifier: function () {
            if (this.lensView == null) {
                if (this.permission.newspaper == null) {
                    this.lensView = new View(document.getElementById("myCanvas"), "rect", 200);
                } else if (this.permission.newspaper.shadowType != "none") {
                    this.lensView = new View(document.getElementById("myCanvas"),
                        this.permission.newspaper.shadowType, this.permission.newspaper.shadowSize);
                }
            }else
                this.lensView.reset(this.permission.newspaper.shadowType, this.permission.newspaper.shadowSize);
        },
        // 点击左侧的热点图
        listId(i) {
            //判断点击路由时触发的哪个id
            this.shHide = 'block';
            this.article = this.page.articles[i].data;
            this.$nextTick(() => {
                this.magnifier()
            })

            this.optLog("read");
            console.log(this.article, '当前文章')
        },
        // 上一版
        pageNoleft() {
            var idx = 0;
            for(idx = 0; idx < this.issue.pages.length; idx++){
                if (this.issue.pages[idx].pageNo == this.page.pageNo)
                    break;
            }
            idx = idx  - 1; //下一版索引
            if ( idx >= 0){

                if (this.paperId == null && this.articleId != null) {
                    this.getArticle(this.articleId).then(
                        article => {
                            this.getPage(article.paperId, this.page.issueNo, this.issue.pages[idx].pageNo);
                        }
                    )
    
                } else if (this.paperId != null) {
                    this.getPage(this.paperId, this.page.issueNo, this.issue.pages[idx].pageNo);
                }
            }else {
                this.$message({
                    showClose: true,
                    message: '已经是第一版了',
                    type: 'warning'
                });
            }
                

            if (this.shHide == 'block') {
                this.scrollToTop()
            }
        },
        // 下一版
        pageNoright() {
            // animated rollIn
            // $('#flashImg').removeClass('animated rollIn');
            // console.log($('#flashImg'), 'sjsjskjk')
            // console.log(document.getElementById('flashImg').className, 'fff')
            // document.getElementById('flashImg').className = "animated rollIn";
            var idx = 0;
            for(idx = 0; idx < this.issue.pages.length; idx++){
                if (this.issue.pages[idx].pageNo == this.page.pageNo)
                    break;
            }
            idx = idx + 1; //下一版索引
            if ( idx < this.issue.pages.length){
                if (this.paperId == null && this.articleId != null) {
                    this.getArticle(this.articleId).then(
                        article => {
                            this.getPage(article.paperId, this.page.issueNo, this.issue.pages[idx].pageNo);
                        }
                    )
    
                } else if (this.paperId != null) {
                    this.getPage(this.paperId, this.page.issueNo, this.issue.pages[idx].pageNo);
                }
                // this.getPage(this.paperId, this.page.issueNo, this.issue.pages[idx].pageNo);
            }
            else {
                this.$message({
                    showClose: true,
                    message: '已经是最后一版了',
                    type: 'warning'
                });
            }

            if (this.shHide == 'block') {
                this.scrollToTop()
            }
        },
        //判断鼠标滑过area标签的id值，判断触发热区的位置，控制span的位置以及大小
        moveseOver(index, article, event) {
            this.hotSpan.title = article.title;
            //点击期版之后的图片的热区
            var coords = event.target.coords.split(',');
            this.hotSpan.id = index;
            this.hotSpan.style = {
                display: 'block',
                left: coords[0] + 'px',
                top: coords[1] + 'px',
                width: coords[2] - coords[0] + 'px',
                height: coords[3] - coords[1] + 'px'
            }
        },
        // 移出热区
        moveOut() {
            //鼠标离开span标签
            this.hotSpan.style = {
                display: 'none'
            }
        },
        calcHotBorder(hot, img){
            var coord = {
                left : hot.l * img.offsetWidth,
                top : hot.t * img.offsetHeight,
                width: hot.r * img.offsetWidth - hot.l * img.offsetWidth - 4,   //减去border
                height: hot.b * img.offsetHeight - hot.t * img.offsetHeight - 4
            };
            return {
                'pointer-events': 'none',
                left : coord.left + 'px',
                top : coord.top + 'px',
                width : coord.width + 'px',
                height : coord.height + 'px'
            }
        },        
        // --------------- 右侧事件 start -----------
        // 点击有奖纠纷
        clickWardDispute: function () {
            this.disputeVisible = true;
            this.clearForm ();
        },
        //获取粘贴板上的图片
        setPasteImg: function () {
            //粘贴事件
            var that = this;
            document.addEventListener('paste', function (event) {

                if (event.clipboardData || event.originalEvent) {
                    var clipboardData = (event.clipboardData || event.originalEvent.clipboardData);
                    console.log(clipboardData, '想要的')
                    if (clipboardData.items) {
                        var blob;
                        for (var i = 0; i < clipboardData.items.length; i++) {
                            if (clipboardData.items[i].type.indexOf("image") !== -1) {
                                blob = clipboardData.items[i].getAsFile();
                            }
                        }
                        var render = new FileReader();
                        console.log(render, 'ass')
                        var file = document.getElementById('img');
                        render.onload = function (evt) {
                            console.log(evt, 'evt')
                            //输出base64编码
                            // var base64 = evt.target.result;
                            that.disputeForm.images = evt.target.result;
                            document.getElementById('img').setAttribute('src', that.disputeForm.images);
                           
                        }
                        // if (file) {
                            render.readAsDataURL(blob);
                        // } else {
                        //     document.getElementById('img').setAttribute('src', '');
                        // }
                       
                    }

                }

            })

        },
        // 有奖纠纷弹框提交
        confirmDispute: function (formName) {
            console.log(this.paperId, this.articleId, this.page,this.article, '想要的')
            this.articleId = this.page.id;
            this.$refs[formName].validate((valid) => {
                if (valid) {
                        this.$http.post('/api/newspaper/commitError?paperId='+this.paperId+'&pageNo='+this.page.pageNo+'&issueNo='+this.page.issueNo+ '&articleId='+this.articleId+ '&title='+this.article.title+'&userName='+this.disputeForm.userName+'&userContact=' + this.disputeForm.userContact+'&description=' + this.disputeForm.description +'&images=' +this.disputeForm.images)
                        .then (res => {
                           if (res.data.code == 0) {
                            this.disputeVisible = false;
                            var attr = document.getElementById('img').getAttribute('src');
                            if (attr != '') {
                              document.getElementById('img').setAttribute('src', '');
                            }
                            throw this.error = '操作成功';
                           } else {
                            //    抛异常
                             throw this.error = '抱歉、数据查询失败'
                           }
                          
                        }).catch(error => {
                            this.$message({
                                showClose: true,
                                message: this.error,
                                type: 'warning'
                            });
                        })
                   
                } else {
                    console.log('error submit');
                    return false;
                }
            })
        },
        // 有奖纠纷弹框取消
        cancelDispute: function (formName) {
            this.disputeVisible = false;
            this.$refs[formName].resetFields();
            this.clearForm ();
            var attr = document.getElementById('img').getAttribute('src');
            if (attr != '') {
              document.getElementById('img').setAttribute('src', '');
            }
            
        },
        //点击返回目录，控制页面展示的哪个页面 调所有数据接口
        toGo() {
            this.dialogVisible = false;
            this.shHide = 'none';
        },
        // 下载、打印、复制事件
        downloadPrintCopy(opt) {
            this.dialogVisible = true;
            console.log(this.permission, '用户权限')
            this.clearForm ();
            if (opt == 'download') { // 下载
                this.jurisdictionTotal = '下载总数'+ this.permission.picture.download.total;
                this.jurisdictionNuit = this.permission.picture.download.cycle;
                this.jurisdictionSurplus = '下载' + this.permission.picture.download.available;
             } else if (opt == 'print') {  // 打印
                this.jurisdictionTotal = '打印总数'+ this.permission.picture.print.total;
                this.jurisdictionNuit = this.permission.picture.print.cycle;
                this.jurisdictionSurplus = '打印' + this.permission.picture.print.available; 
             } else { // 复制copy
                this.jurisdictionTotal = '复制总数'+ this.permission.picture.copy.total;
                this.jurisdictionNuit = this.permission.picture.copy.cycle;
                this.jurisdictionSurplus = '复制' + this.permission.picture.copy.available; 
             }  

        },
        // 下载、打印、复制 弹框提交
        confirm: function (formName) {
            this.$refs[formName].validate((valid) => {
                if (valid) {
                  if (this.jurisdictionTotal.indexOf('下载') > -1) {
                     this.downloadArticle()
                  } else if (this.jurisdictionTotal.indexOf ('打印') > -1) {
                      this.printArticle ();
                  } else if (this.jurisdictionTotal.indexOf ('复制') > -1) {
                      this.copyArticle ()
                      this.copyUrl ();
                  }
                  this.dialogVisible = false;
                } else {
                    console.log('error submit');
                    return false;
                }
            })


        },
        // 取消
        cancel: function (formName) {
            this.dialogVisible = false;
            this.$refs[formName].resetFields();
        },
        // 点击第几期
        clickIssue() {
            let find = false;
            this.paper.forEach(item => {
                if (this.issueValue.indexOf(item.issueNo) != -1) {
                    this.issue = item;
                    find = true;
                }
            });
            if (!find) throw error = "未找到此期次";
        },
        //点击期次触发事件
        selectPeriod: function (item, index) {
            console.log(this.page, this.issue, item,'Minaos')
            if (this.paperId == null && this.articleId != null) {
                this.getArticle(this.articleId).then(
                    article => {
                        this.getPaper(article.paperId, item.issueNo).then(
                            paper => {
                                this.getPage(article.paperId, item.issueNo, item.pages[0].pageNo)
                            }
                        )
                    }
                )
            } else if (this.paperId != null) {
                this.getPaper(this.paperId, item.issueNo).then(
                    paper => {
                        this.getPage(this.paperId, item.issueNo, item.pages[0].pageNo);
                    }
                )
            }
            // this.issue = item;
            // this.getPage(this.paperId, item.issueNo, item.pages[0].pageNo)
        },
        //点击版次触发
        selectEdition: function (item, index) {
            // 如果没有paperId 有articleId 则走if条件 
            if (this.paperId == null && this.articleId != null) {
                this.getArticle(this.articleId).then(
                    article => {
                        this.getPage(article.paperId, this.page.issueNo, item.pageNo)
                    }
                )
            } else if (this.paperId != null) {
                this.getPage(this.paperId, this.page.issueNo, item.pageNo);
 
            }
        },
        // 获取鼠标选中的内容
        getChoose: function () {
            var that = this;
             //将该id下的文章，鼠标选中松开后弹窗
            $("#content").mouseup(function (e) {
                var x = 10;
                var y = 10;
                var r = "";
                if (document.selection) {
                   r = document.selection.createRange().text;
                }
                else if (window.getSelection()) {
                   r = window.getSelection();
                }
                if (r!= "") {
                    var tooltip = "<div id='tooltip' class='tooltip'><button id='copy'>复制</button><button id='notes'>注释</button></div>";
                    $("body").append(tooltip);
                    $("#tooltip").css({
                        "top": (e.pageY + y) + "px",
                        "left": (e.pageX + x) + "px",
                        "position": "absolute"
                    }).show("fast");
                    that.addEvent(that)
                    //     $('#copy').mousedown(function(){
                    //     // alert(r)
                    //     // that.dialogVisible = true;
                    //     that.downloadPrintCopy('复制');
                    //     console.log(this,that, 'this直系那个')
                    //     console.log('登录')
                    // })  
                }
            }).mousedown(function () {
                $("#tooltip").remove();
            });
        },
        addEvent: function (that) {
          $('#copy').click(function () {
            that.downloadPrintCopy('复制');
          })
          $('#notes').click( function () {
             that.notesVisible = true;
          })
        },
        // 注释部分表单提交
        notesConfirm: function (formName) {
            this.$refs[formName].validate((valid) => {
                if (valid) {
                 
                } else {
                    console.log('error submit');
                    return false;
                }
            })
        },
        // 注释表单取消
        notesCancel: function(formName) {
            this.notesVisible = false;
            this.$refs[formName].resetFields();
        },
        //点击标题，对id值进行判断 
        sectionClic(item, i) {
            this.listId(i)
        },
        // 屏幕滚动事件
        handleScroll() {
            if (this.shHide == 'block') {
                let dom = document.getElementsByClassName('content')[0];
                // console.log(dom.scrollTop, '目的')
                this.scrollTop = dom.scrollTop;
            }
        },
        scrollToTop() {
            let timer = null;
            let _this = this;
            cancelAnimationFrame(timer);
            timer = requestAnimationFrame(function fn() {
                if (_this.scrollTop > 5000) {
                    _this.scrollTop -= 1000;
                    document.getElementsByClassName("content")[0].scrollTop = _this.scrollTop;
                    timer = requestAnimationFrame(fn);
                } else if (_this.scrollTop > 1000 && _this.scrollTop <= 5000) {
                    _this.scrollTop -= 500;
                    document.getElementsByClassName("content")[0].scrollTop = _this.scrollTop;
                    timer = requestAnimationFrame(fn);
                } else if (_this.scrollTop > 200 && _this.scrollTop <= 1000) {
                    _this.scrollTop -= 100;
                    document.getElementsByClassName("content")[0].scrollTop = _this.scrollTop;
                    timer = requestAnimationFrame(fn);
                } else if (_this.scrollTop > 50 && _this.scrollTop <= 200) {
                    _this.scrollTop -= 10;
                    document.getElementsByClassName("content")[0].scrollTop = _this.scrollTop;
                    timer = requestAnimationFrame(fn);
                } else if (_this.scrollTop > 0 && _this.scrollTop <= 50) {
                    _this.scrollTop -= 5;
                    document.getElementsByClassName("content")[0].scrollTop = _this.scrollTop;
                    timer = requestAnimationFrame(fn);
                } else {
                    cancelAnimationFrame(timer);
                }
            });
        },
        resetContainer() {
            var sh = document.body.clientHeight - 60;
            var sw = document.body.clientWidth - 10;
            if (sw < sh * 1.57)
                sh = sw / 1.57;
            else
                sw = sh * 1.57;
            this.container.width = sw;
            this.container.height = sh + 60;
        },
        // 下载文章
        downloadArticle() {
            var url = "http://172.18.89.226/api/newspaper/writeDoc/" + this.article.id;//此处base地址要用userinfo取
            console.log(this.form, 'json数据')
            this.optLog("download",this.form);
            console.log(url);
            window.open(url);
        },
        // 打印
        printArticle() {
            $("#readingPage_rightTextbox").print({
                  // 是否包含父文档样式
                   globalStyles:true,
                  //是否包含media='print'的链接标签。会被globalStyles选项覆盖，默认为false 
                   mediaPrint:false,
                  //外部样式表的URL地址，默认为null
                   stylesheet:null, 
                  //不想打印的元素的jQuery选择器，默认为".no-print"
                   noPrintSelector:".no-print",
                  //是否使用一个iframe来替代打印表单的弹出窗口，true为在本页面进行打印，false就是说新开一个页面打印，默认为true 
                   iframe:true, 
                  // 将内容添加到打印内容的后面
                   append:null,
                   //将内容添加到打印内容的前面，可以用来作为要打印内容
                    prepend:null,
                    //回调函数
                    deferred: $.Deferred(),
             });
            //使用iframe，重新设置document.body.innerHTML，调用window.print进行打印
            // var printBox = document.getElementById('readingPage_rightTextbox');
            // //拿到打印的区域的html内容
            // var newContent = printBox.innerHTML;
            // //将旧的页面储存起来，当打印完成后返给给页面。
            // var oldContent = document.body.innerHTML;
            // //赋值给body
            // document.body.innerHTML = newContent;
            // //执行window.print打印功能
            // window.print();
            // // 重新加载页面，以刷新数据。以防打印完之后，页面不能操作的问题
            // window.location.reload();
            // document.body.innerHTML = oldContent;
            this.optLog("print", this.form);
        },
        // 复制文章
        copyArticle() {
            this.optLog("copy", this.form);
        },
        /**
         * 记录操作日志，
         * @param opt，操作类型，read,copy,print,down,search
         * @param optParam
         */
        optLog(opt, optParam){
            this.$http.get('/api/user/optlog',{
                params : {
                    resType: 'newspaper',
                    paperId: this.article.paperId,
                    resId: this.article.id,
                    opt: opt,
                    optParam: optParam
                }});
        },

        // -------------- 右侧事件 end ---------------

        // -------------- 公共事件 start ---------------
        setClipboardText: function (event){
            event.preventDefault();
            var node = document.createElement('div');
            node.innerHTML=window.getSelection(0).toString();
            var htmlData = '<div>著作权归作者所有。<br />'
                            + '商业转载请联系作者获得授权，非商业转载请注明出处。<br />'
                            + '作者：0zero<br />链接：https://segmentfault.com/u/codedemon<br />'
                            + '来源：segmentfault<br /><br />'
                            + node.innerHTML
                            + '</div>';
            var textData = '著作权归作者所有。\n'
                            + '商业转载请联系作者获得授权，非商业转载请注明出处。\n'
                            + '0zero\n链接：https://segmentfault.com/u/codedemon\n'
                            + '来源：segmentfault\n\n'
                            + window.getSelection(0).toString();
            if(event.clipboardData){
                event.clipboardData.setData("text/html", htmlData);
                event.clipboardData.setData('text/plain', textData);
            }
            else if(window.clipboardData){
                return window.clipboardData.setData("text", textData);
            }
        },
        copyUrl: function () {
            var Url2=document.getElementById("content").innerText;
            var oInput = document.createElement('input');
            oInput.value = Url2;
            document.body.appendChild(oInput);
            oInput.select(); // 选择对象
            document.execCommand("Copy"); // 执行浏览器复制命令
            oInput.className = 'oInput';
            oInput.style.display='none';
        },
        // 获取地址栏参数
        getUrlParam: function (name) {
            var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
            var url = decodeURI(window.location.search)
            var r = url.substr(1).match(reg);
            if (r != null) return unescape(r[2]); return null;
        },
        // 清空form表单
        clearForm: function () {
          this.form.userName = '';
          this.form.workUnit = '';
          this.form.contact = '';
          this.form.description = '';

          this.disputeForm.userName = '';
          this.disputeForm.userContact = '';
          this.disputeForm.description = '';
          this.disputeForm.images = '';
        }
        // -------------- 公共事件 end ---------------
    }
})