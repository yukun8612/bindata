Vue.prototype.$http = axios;
// 创建-个vue实力
new Vue({
    el:'#app',
    // 定义属性，并设置初始值
    data:function () {
      return {
        currentPage: 1, //初始页
        pagesize: 10, // 每页的数据
        titFormsName: '',
        tableData: [], // 表格容器
        totalNum:0, // 总数
        libId:'',
        id:'', // 根据数据id 获取数据详情信息
        detail:{}, // 详情页容器
        error:'抱歉、数据请求失败'
      }
    },
    created () {
        sessionStorage.setItem('active',5)
        if (sessionStorage.getItem('libId') != '' || sessionStorage.getItem('libId') != null) {
            this.libId = sessionStorage.getItem('libId');   
        }
        if (this.getUrlParam('id') && this.getUrlParam('id') != '') {
          this.id = this.getUrlParam('id')
          this.getDetail()
        }
    },
    mounted () {
        this.initData ()
    },
    methods:{
        // 初始化表格
        initData:function () {
           this.$http.get('/api/module/infoPage/'+this.libId+'?pageNum='+this.currentPage+'&pageSize='+this.pagesize
           ).then (res => {
               console.log(res.data, '动态资讯数据')
             this.tableData = res.data.list
             this.totalNum = res.data.total;
           }).catch(error => {
              this.$message({
                 showClose:true,
                 message: '抱歉，数据请求失败',
                 type:'warning'
              })
           })
        },
        // 根据id 获取详情页数据
        getDetail:function () {
          this.$http.get('/api/module/info/'+this.id
          ).then(res => {
           console.log(res.data.data, '详情页数据')
           if (res.data.code == 0) {
              this.detail = res.data.data;
           } else {
             throw error = '抱歉、数据查询失败'
           }
          }).catch(error => {
            this.$message({
                showClose:true,
                message: this.error,
                type:'warning'
             })
          })
        },
        handleSizeChange: function(size) {
            console.log(size)
            this.pagesize = size;
            this.initData()
        },
        //点击第几页
        handleCurrentChange: function(currentPage) {
            this.currentPage = currentPage;
            this.initData()
        },
        //获取点击当前元素内的数据拿到当前数据id 地址栏传参
        trCli(item) {
            console.log(item, 'table每一行数据')
            this.id = item.id;
            this.detail = item;
        },
         // 获取地址栏参数
        getUrlParam: function(name){
            var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
            var url = decodeURI(window.location.search)
            var r = url.substr(1).match(reg);
            if (r!=null) return unescape(r[2]); return null;
        },
    }
})