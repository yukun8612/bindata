
Vue.prototype.$http = axios;
// 使用一个vue实例 作为事件的载体,用于绑定事件和处理发送事件，作为调度中心
let Bus = new Vue();
// tree组件 （公共部分） @click="handleNodeClick(model,index)"  @click="getIndex(model, index)" @click="toggle(model.name)"
var myTree = {
  props:['model', 'index'],
  template:`<li @click="handleNodeClick(model,index)">
              <p @click="toggle(model, index)">
                  <span>
                      <i v-if="isFolders" class="icon" :class="[open ? 'folder-open': 'folder']"></i>
                      <i v-if="!isFolders" class="icon file-text"></i>
                      {{ model.menuName }}
                  </span>
              </p> 
              <ul v-show="open" v-if="isFolders">
                 <tree-menu v-for="(item,index) in model.children" :key="item.id" :model="item"></tree-menu>
              </ul>
          </li>`,
  name: 'treeMenu',
  mounted () {
     console.log(this.model, this.index, '我想要的')
  },
  computed: {
      // isFolders() {
      //     return this.model.classifies && this.model.classifies.length
      // }
  },
  data:function () {
    return {
      isFolders: true,
      open: false,
    }
  },
  methods: {
      handleNodeClick: function (model, i) {
          // if (i == 0) {
          // }else if (i == 1) {
          // }else if (i == 2) { // 地名导航
          // } else {
          //     return false;
          // }
      },
      toggle:function(model, i){
          Bus.$emit("childEvent", model.menuName)
          if (this.isFolders) {
            this.open = !this.open;
          }
      },
  }
};
// 创建-个vue实力
new Vue({
    el:'#app',
    // 定义属性，并设置初始值
    data:function () {
      return {
        theModel:[
          {
            "menuName":"曲谱",
            "children":[
              {
                "menuName":"红色中华"
              },
              {
                "menuName":"解放日报"
              },
              {
                "menuName":"新中华报"
              }
            ]
          },{
            "menuName":"插图"
          },{
            "menuName":"地图"
          },{
            "menuName":"题词"
          }
        ],
        viewSwiper:'',
        previewSwiper:'',
        // 图库左侧数据
        pictureEnjoyModuleManagesVosData:[],
        // 轮播图片数据
        pictureEnjoyVos:[],
        picturePageInfo: {
          currentPage: 1, //初始页
          pagesize: 10, //    每页的数据
        },
        pictureInfo:{
          title:'', // 标题
          author:'', // 作者
          createTime:'',
        },
        num:0,
        isNone:false,
        menuName:'',
        error:'抱歉、数据请求失败'
      }
    },
    components:{
      'my-tree':myTree,
    },
    created () {
        sessionStorage.setItem('active',4);
        // 接受子组件传过来的方法、拿到menuName 重新请求接口
        this.$nextTick(() => {
          Bus.$on('childEvent', ref => {
            this.menuName = ref;
            this.getPictures()
          })
        })
    },
    mounted () {
      this.init ();
    },
    methods:{
      init: function () {
        this.getPictures ()
      },
      getPictures: function () {
          this.$http.get('/api/library/subject/picture/'+(this.menuName == '' ? ' ' : this.menuName)+'?pageNum='+this.picturePageInfo.currentPage+'&pageSize='+this.picturePageInfo.pagesize).then(res => {
            if (res.data.code == 0 && res.data.data!= null) {
              console.log(res.data.data, '获取图库数据')
                  this.pictureEnjoyModuleManagesVosData = res.data.data.pictureEnjoyModuleManagesVos;
                  if (res.data.data.pictureEnjoyVos.length == 0) {
                    this.pictureEnjoyVos = [];
                    this.pictureInfo.title = '暂无数据';
                    this.pictureInfo.author = '暂无';
                    this.pictureInfo.createTime = '暂无';
                  } else {
                    this.pictureEnjoyVos = res.data.data.pictureEnjoyVos;
                    this.pictureInfo.title = this.pictureEnjoyVos[0].title;
                    this.pictureInfo.author = this.pictureEnjoyVos[0].author;
                    this.pictureInfo.createTime = getTime(this.pictureEnjoyVos[0].createTime);
                  }
              //  在获取完数据后，将swiper放在$nextTick下一个UI帧再初始化
               this.$nextTick(() => {
                  this.swiper ();
               })
            } else {
              throw this.error = '抱歉、数据查询失败'
            }
          }).catch(error => {
            console.log(error, '错误信息')
            this.$message({
                showClose: true,
                message: this.error,
                type: 'warning'
            });
          })
      },
      // 初始化轮播
      swiper:function () {
        var that = this;
        that.viewSwiper = new Swiper('.view .swiper-container', {
            onSlideChangeStart: function() {
              that.updateNavPosition();
            }
        })
        that.previewSwiper = new Swiper('.preview .swiper-container', {
          visibilityFullFit: true,
          slidesPerView: 'auto',
          onlyExternal: true,
          onSlideClick: function() {
            that.viewSwiper.swipeTo(that.previewSwiper.clickedSlideIndex);
          }
        }) 
      },
      updateNavPosition: function () {
          $('.preview .active-nav').removeClass('active-nav');
          var activeNav = $('.preview .swiper-slide').eq(this.viewSwiper.activeIndex).addClass('active-nav');
          if(!activeNav.hasClass('swiper-slide-visible')) {
            if(activeNav.index() > this.previewSwiper.activeIndex) {
              var thumbsPerNav = Math.floor(this.previewSwiper.width / activeNav.width()) - 1;
              this.previewSwiper.swipeTo(activeNav.index() - thumbsPerNav);
            } else {
              this.previewSwiper.swipeTo(activeNav.index());
            }
          }
      },
      //点击上一个
      prev: function () {
        this.num --;
        if (this.num < 0) {
          this.num = this.pictureEnjoyVos.length -1;
        }
        this.pictureInfo.title = this.pictureEnjoyVos[this.num].title;
        this.pictureInfo.author = this.pictureEnjoyVos[this.num].author;
        this.pictureInfo.createTime = getTime(this.pictureEnjoyVos[this.num].createTime);
        if(this.viewSwiper.activeIndex == 0) {
          this.viewSwiper.swipeTo(this.viewSwiper.slides.length - 1, 1000);
          return;
        }
        this.viewSwiper.swipePrev();
      },
      // 点击下一个
      next: function () {
          this.num ++;
          if (this.num > this.pictureEnjoyVos.length -1) {
            this.num = 0;
          }
          this.pictureInfo.title = this.pictureEnjoyVos[this.num].title;
          this.pictureInfo.author = this.pictureEnjoyVos[this.num].author;
          this.pictureInfo.createTime = getTime(this.pictureEnjoyVos[this.num].createTime);
          if(this.viewSwiper.activeIndex == this.viewSwiper.slides.length - 1) {
            this.viewSwiper.swipeTo(0, 1000);
            return
          }
          this.viewSwiper.swipeNext();
			
      },
      // 进入阅读页
      goReadingPage: function (item) {
       window.open('readingPage.html?articleId='+ item.paperId, 'readingPage');
      },
      photosSizeChange: function (size) {
       
      },
      photosCurrentChange: function (currentPage) {

      }
    }
})