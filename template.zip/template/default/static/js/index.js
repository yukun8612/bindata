Vue.prototype.$http = axios;
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded'
// 创建-个vue实力
new Vue({
    el:'#app',
    // 定义属性，并设置初始值
    data:function () {
      return {
        newspaperIntroduction:'',
        // "向外发展的革命战争，正在各方积极的进行着，英勇的红军已夺取了上杭，武平；大大的开辟了赣南苏区疆土，包围了赣州。在开始就取得大的胜利中，正是敌人惊慌告急，正是我们乘胜去大大发展革命战争，猛烈进攻敌人，夺下赣州，以至争取一省几省首先胜利的最好时候呵！要使革命战争更大的向前发展，去争取更大的胜利，这不仅在红军的勇敢作战，而且还在动员广大工农群众，积极的参加革命战争的工作；不单是前方的努力，而且要有巩固的得力的后方工作，以加强和补充前方的战斗力量，这样，才能使革命战争一天天更大的开展，使新的胜利不断的获得。临时中央政府为了加强革命战争的发展建立巩固的后方工作，曾号召各级政府，努力作动员群众参加革命战争的工作，领导广大工农群众配合红军作战；努力做扩大红军的工作，以充实革命战争的武装战斗力量；积极领导群众去耕种『红军公田』和帮助红军家属耕种，切实执行优待红军条例，以鼓励群众踊跃的参加红军：领导群众努力春耕，提高生产，以加强发展革命战争的经济力量",
        newspaperIntroductions: "", // 报纸介绍
        seeNone:'none',
        inpVal:'',
        titFormsName_title:'',
        // 轮播图数据
        swiperData:[],
        // 动态资讯数据
        dynamicInfo: [],
        dynamicInfoNone:'none',
        downMenu:'全部',
        EnglishName:'', // 检索时下拉框选中的值得英文名字
        newArray:'',
        Spinner: [
            {
            title: "全部"
            },
            {
            title: "全文"
            },
            {
            title: "题名"
            },
            {
            title: "作者"
            },
            {
            title: "主题词"
            },
            {
            title: "关键词"
            }
        ],
        // 历史上的今天数据容器
        historyToday:[],
        lunarCalendar:'', // 农历时间
        date:'', // 当前系统时间
        week:'',
        historyTodayNone:'none',
        // 所有报纸列表数据
        newspaperData:[],
        error:'抱歉、数据请求失败',
        libId:'',
        // 用户基本信息
        userInfo:{
          
        }
      }
    },
    // 在模板渲染成html前调用，即通常初始化某些属性值，然后再渲染成视图。
    created () {
        sessionStorage.setItem('active',0);
       // 初始化获取一些时间
      let  weeks = '日一二三四五', 
           Year ='' ,
           Month = '',// 月
           Day = ''; // 日
      this.date = new Date().pattern('yyyy年MM月dd日');
      this.week = weeks.charAt(new Date().getDay());
      Year = new Date().getFullYear();
      Month = new Date().getMonth() + 1;
      this.Day = new Date().getDate();
      //   调用获取农历时间的方法
      this.lunarCalendar = GetCNDate(Year,Month,Day);
      this.initUser()
      this.$nextTick(() => {
        this.getInfo();
      })

    },
    // 在模板渲染成html后调用，通常是初始化页面完成后，再对html的dom节点进行一些需要的操作
    mounted () {
        this.init ();
    },
    methods:{
        // 初始数据
        init: function () {
            this.newspaperList ();
        },
        initUser: function () {
            this.$http.get('/api/user/info').then (res => {
               if (res.data.code == 0) {
                 console.log(res.data, '用户信息')
                 this.userInfo = res.data.data.userInfo;
                 // res.data.data.userType = 'SysUser'
                 sessionStorage.setItem('libId', res.data.data.libId)
                 this.userInfo = res.data.data;
               } else {
                  throw error = '抱歉、用户信息查询失败'
               }
            }).catch (error => {
                 this.$message({
                     showClose: true,
                     message: error,
                     type: 'warning'
                 });  
            })
        },
        // 获取资源库基本信息
        getInfo: function () {
           this.$http.get('/api/library/info'+ '?f=' + location.hostname + location.pathname).then(res => {
              console.log(res.data.data, '获取资源库信息')
              if (res.data.code == 0) {
                this.handleInfo (res.data.data);
              } else {
                throw this.error = '资源库基本信息查询失败'  
              }
           }).catch(error => {
                this.$message({
                    showClose: true,
                    message: this.error,
                    type: 'warning'
                });
           })
        },
        // 处理资源库基础信息
        handleInfo: function (obj) {
            // 轮播图数据
            if (obj.pictureEnjoyVos.length > 0) {
                // 在数组原型上创建一个方法以4个元素为一个单位，提取到一个数组中，建立一个二维数组
                Array.prototype.chunk = function (len) {
                    var len = parseInt(len);
                    // if (len <= 1 || this.length < len) {
                    //     return this;
                    // }   
                    var groups = [], loop = Math.ceil(this.length / len);
                    for (var i = 0; i < loop; i++) {
                        groups.push(this.slice(len * i, len * (i + 1)));
                    }    
                    return groups;
                }
                this.swiperData =obj.pictureEnjoyVos.chunk(4);
                // this.swiperData = obj.pictureEnjoyVos;
                console.log(this.swiperData, '想要的数组')
                this.$nextTick(() => {  // 下一个UI帧再初始化swiper
                        this.doSwiper ();
               });
            }
            // 报纸介绍数据
            if (obj.paperText != null) {
                this.newspaperIntroduction = obj.paperText;
                if (this.newspaperIntroduction.length >= 100) {
                    let str = this.newspaperIntroduction.substr(0, 70);
                    this.newspaperIntroductions = str;
                    this.seeNone = "";
                } else {
                    this.newspaperIntroductions = obj.paperText;  
                }
            }
            // 动态资讯数据
            if (obj.dynamicInfos != null) {
                let arr = obj.dynamicInfos;
                if (arr.length >= 6) {
                    this.dynamicInfoNone = 'block';
                  }
                  let arrs = arr.slice(0, 6);
                  this.dynamicInfo = arrs;
            }
            // 历史上的今天数据
            if (obj.historyToday.length >0) {
                let historyToday = obj.historyToday;
                historyToday.forEach(element => {
                    if (element.createTime != '') {
                        element.createTime = getTime(element.createTime)   
                    } else {
                    element.createTime = new Date().pattern('yyyy年MM月dd日')
                    } 
                });
                if(historyToday.length >= 3) {
                this.historyTodayNone = 'block';
                }
                let historyTodays = historyToday.slice(0,3);
                this.historyToday = historyTodays;
            }
           
        },
        // 获取所有报纸列表数据
        newspaperList: function () {
           this.$http.get('/api/newspaper/papers').then (res => {
              if (res.data.code == 0) {
                  if (res.data.data.length > 3) {
                     this.newspaperData = res.data.data.slice(0, 3);  
                  } else {
                    this.newspaperData = res.data.data;
                  }
              } else {
                this.$message({
                    showClose: true,
                    message: '抱歉，报纸列表数据查询失败',
                    type: 'warning'
                });  
              }

           }).catch(error => {
                this.$message({
                    showClose: true,
                    message: '抱歉，报纸列表数据请求失败',
                    type: 'warning'
                });  
           })
        },
        // 轮播图方法调用
        doSwiper: function () {
            new Swiper(".swiper-container", {
                loop: true,
                // 如果需要分页器
                pagination: {
                    el: ".swiper-pagination",
                    clickable: true
                }
                // 如果需要前进后退按钮
                // 如果需要滚动条
            });
        },
        // 下拉框选择
        clitit:function (item) {
            this.downMenu = item.title;
        },
        // 检索
        btnRoute:function () {
            window.location.href = 'newspaperSearch.html?downMenu='+this.downMenu+'&inpVal='+this.inpVal;
        },
        // 搜索回车事件
        searchEnterFun: function (e) {
          console.log(e, '回车事件')
          if (e.keyCode == 13) {
            this.btnRoute()  // 回车键触发、搜索事件  
          }
        },
        // 点击报纸列表的每一条数据
        goPeriod: function (id) {
           window.open("readingPage.html?paperId=" + id, "readingPage");
        },
        imgToRead(subItem) {
            //window.location.href = 'readingPage.html?articleId='+ subItem.paperId;
            window.open('readingPage.html?articleId='+ subItem.paperId, 'readingPage');
        },
        // 动态资讯列表详情页
        goRead(item) {
            console.log(item, '每一条动态数据')
            // 跳转到阅读页面api/module/info/
            window.location.href = 'homeInformation.html?id='+item.id;
        },
         // 动态资讯更多
        ConsultingAll() {
            this.$router.push({
                name: "homeInformation"
            });
            // 防止页面刷新后、状态消失
            window.sessionStorage.setItem("activeId", 5);
            eventBus.$emit("activeId", 5);
        },
        
    }
})