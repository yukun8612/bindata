
Vue.prototype.$http = axios;
// 使用一个vue实例 作为事件的载体,用于绑定事件和处理发送事件，作为调度中心
let Bus = new Vue();
// tree组件 （公共部分） @click="handleNodeClick(model,index)"  @click="getIndex(model, index)" @click="toggle(model.name)"
var myTree = {
  props:['model', 'index'],
  template:`<li @click="handleNodeClick(model,index)">
              <p @click="toggle(model, index)">
                  <span>
                      <i v-if="isFolders" class="icon" :class="[open ? 'folder-open': 'folder']"></i>
                      <i v-if="!isFolders" class="icon file-text"></i>
                      {{ model.menuName }}
                  </span>
              </p> 
              <ul v-show="open" v-if="isFolders">
                 <tree-menu v-for="(item,index) in model.children" :key="item.id" :model="item"></tree-menu>
              </ul>
          </li>`,
  name: 'treeMenu',
  mounted () {
     console.log(this.model, this.index, '我想要的')
  },
  computed: {
      // isFolders() {
      //     return this.model.classifies && this.model.classifies.length
      // }
  },
  data:function () {
    return {
      isFolders: true,
      open: false,
    }
  },
  methods: {
      handleNodeClick: function (model, i) {
          if (i == 0) {
              this.$parent.curPage = 0;
          }else if (i == 1) {
            
          }else if (i == 2) { // 地名导航
          
          
          } else if (i == 3) { // 人名导航
          
          } else {
              return false;
          }
      },
      toggle:function(model, i){
          Bus.$emit("childEvent", model.menuName)
          if (this.isFolders) {
            this.open = !this.open;
          }
      },
  }
};
// 创建-个vue实力
new Vue({
    el:'#app',
    // 定义属性，并设置初始值
    data:function () {
      return {
        // 左侧报纸研究数据
        theModel:[],
        // 报纸研究数据
        researchData:[],
        researchPageInfo: {
          currentPage: 1, //初始页
          pagesize: 10, //    每页的数据
        },
        researchTotal:0,
        menuName:'',
        // 每一条数据的id
        researchId:'',
        // 详情页容器
        detail:{},
      }
    },
    components:{
      'my-tree':myTree,
    },
    created () {
        sessionStorage.setItem('active',3);
        // 接受子组件传过来的值
        this.$nextTick(() => {
          Bus.$on("childEvent", ref => {
            this.menuName = ref;
            this.getRetrieval ()
          })
        })
    },
    mounted () {
      this.getRetrieval ()
    },
    methods:{
      // 获取报纸研究数据
      getRetrieval: function () {
          this.$http.get('/api/library/subject/research/'+(this.menuName == '' ? ' ': this.menuName)+'?pageNum='+this.researchPageInfo.currentPage+'&pageSize='+this.researchPageInfo.pagesize).then(res => {
            if (res.data.code == 0 && res.data.data.length != 0) {
              console.log(res.data.data, '获取报纸研究数据')
              this.theModel = res.data.data.researchModuleManagesVos;
              this.researchData = res.data.data.newspaperResearchVos;
              this.researchTotal = res.data.data.recordCount;
              
            } else {
              throw this.error = '抱歉、数据查询失败'
            }
          }).catch(error => {
            console.log(error, '错误信息')
            this.$message({
                showClose: true,
                message: this.error,
                type: 'warning'
            });
          })
      },
      // 每页显示多少条
      researchSizeChange: function (size) {
        console.log(size, '每页显示'+size+'条')
        this.researchPageInfo.pagesize = size;
        this.getRetrieval ()
      },
      // 点击第几页
      researchCurrentChange: function (currentPage) {
        console.log(currentPage, '前往第'+currentPage+'页')
        this.researchPageInfo.currentPage = currentPage;
        this.getRetrieval ()
      },
      // 点击表格每一行数据
      rowClick: function (item) {
        console.log(item, '数据')
        this.researchId = item.id;
        this.detail = item;
        // window.open('readingPage.html?articleId='+item.articleId, '_bank');
      }
    }
})