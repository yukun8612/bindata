Vue.prototype.$http = axios;
Vue.config.errorHandler = (error, vm) => {
    console.log(error, '错误信息')
    vm.$message({
        showClose: true,
        message: error,
        type: 'warning'
    });
};
// 使用一个vue实例 作为事件的载体,用于绑定事件和处理发送事件，作为调度中心
let Bus = new Vue();
// 全局定义数据
var myData = [
    {
        'id': '1',
        'menuName': '分类导航',
        'menuCode': '10',
        'margin': '10px',
        'bar': '#D5C78A',
        'children': [
            {
                'menuName': '用户管理',
                'menuCode': '11',
                'margin': '20px',
            }, 
            {
                'menuName': '角色管理',
                'menuCode': '12',
                'margin': '20px',
                'children': [
                    {
                        'menuName': '管理员',
                        'menuCode': '121',
                        'margin': '30px',
                    }, 
                    {
                        'menuName': 'CEO',
                        'menuCode': '122',
                        'margin': '30px',
                    }, 
                    {
                        'menuName': 'CFO',
                        'menuCode': '123',
                        'margin': '30px',
                    }, 
                    {
                        'menuName': 'COO',
                        'menuCode': '124',
                        'margin': '30px',
                    }, 
                    {
                        'menuName': '普通人',
                        'menuCode': '124',
                        'margin': '30px',
                    }
                ]
            },
            {
                'menuName': '权限管理',
                'menuCode': '13',
                'margin': '20px',
            }
        ]
    }, 
    {
        'id': '2',
        'menuName': '年份导航',
        'menuCode': '',
        'margin': '10px',
        'bar': '#D5C78A',
    }, 
    {
        'id': '3',
        'menuName': '地名导航',
        'menuCode': '30',
        'margin': '10px',
        'bar': '#D5C78A',
        'children': [
            {
                'menuName': '红色中华',
                'menuCode': '31',
                'margin': '20px',
            },
            {
                'menuName': '新中华报',
                'menuCode': '32',
                'children': [],
                'margin': '20px',
            }, 
            {
                'menuName': '解放日报',
                'menuCode': '33',
                'children': [],
                'margin': '20px',
            }
        ]
    }, 
    {
        'id': '4',
        'menuName': '人名导航',
        'menuCode': '',
        'margin': '10px',
        'bar': '#D5C78A',
        'children': [],
    }
];
// tree组件 （公共部分） @click="handleNodeClick(model,index)"  @click="getIndex(model, index)" @click="toggle(model.name)"
var myTree = {
    props:['model', 'index'],
    template:`<li @click="handleNodeClick(model,index)">
                <p @click="toggle(model, index)">
                    <span>
                        <i v-if="isFolders" class="icon" :class="[open ? 'folder-open': 'folder']"></i>
                        <i v-if="!isFolders" class="icon file-text"></i>
                        {{ model.name }} <i v-if="model.count != null">( {{ model.count }} )</i>
                    </span>
                </p> 
                <ul v-show="open" v-if="isFolders">
                   <tree-menu v-for="(item,index) in model.classifies" :key="item.id" :model="item"></tree-menu>
                </ul>
            </li>`,
    name: 'treeMenu',
    mounted () {
    //    console.log(this.model, this.index, '我想要的')
    },
    computed: {
        // isFolders() {
        //     return this.model.classifies && this.model.classifies.length
        // }
    },
    data:function () {
      return {
        isFolders: true,
        open: false,
      }
    },
    methods: {
        handleNodeClick: function (model, i) {
            if (i == 0) {
                this.$parent.curPage = 0;
            }else if (i == 1) {
                this.$parent.curPage = 0;

            }else if (i == 2) { // 地名导航
                this.$parent.curPage = 2;
                this.$parent.ifShow = 'block';
            
            } else if (i == 3) { // 人名导航
                this.$parent.curPage = 3;
                this.$parent.ifShow = 'block';
                //  调用父级方法
                // this.$parent.getName ();
            } else {
                return false;
            }
        },
        toggle:function(model, i){
             if (model.name != '分类导航' && model.name != '年份导航' && model.name != '地名导航' && model.name != '人名导航' && model.menuCode != 'area' && model.menuCode != 'author') {
               Bus.$emit("childEvent", model)
             }
            if (this.isFolders) {
              this.open = !this.open;
            }
        },
    }
}
// 创建-个vue实力
new Vue({
    el:'#app',
    // router:router,
    // 定义属性，并设置初始值
    data:function () {
      return {
        // 分类导航数据
        relationshipV:'', // 关系值
        relationships:[{label:'AND',value:0},{label:'OR',value:1}],
        downMenu:'全部',
        singleElect:3,
        inputV:'', // 输入值
        inTime:'', // 在时间之间
        brforeTime:'', // 之前时间
        afterTime: '', // 之后时间
        Spinner:[
          {title: '全部',val:''},
          {title:'全文',val:'contentShow'},
          {title:'题名',val:'title'},
          {title:'作者',val:'author'},
          {title:'主题词',val:'subjectword'},
          {title:'关键词',val:'keyword'},
        ],
        retrievalClustering:[], // 检索聚类里面的数据
        // 高级检索
        isRetrieval:false, // 控制是否进行高级检索
        newspaperType:[],  // 存放报纸种类数据容器
        inputVal:'',
        newspaperTypeVal:'',
        searchV:'',
        val:'',
        inputTerm:[{search:'全文',content:''},{term:'AND',search:'全文',content:''}],


        isRetrievalContent:false, // 控制是否是普通检索中的检索全部和全文
        inpVal:'',
        inpSearchVal:'',//只针对搜索框的内容
        searchVal:'',//搜索条件
        parameter:'address', // 给后台传的参数
        // 分类导航table数据
        classifyData: [],
        classifyPageInfo: {
            currentPage: 1, //初始页
            pagesize: 10, //    每页的数据
        },
        classifyTotal:0, // 总数
        EnglishName:'', // 检索时下拉框选中的值得英文名字
        // 地名导航数据
        ifShow:'block',
        plcaeArray:[], // 地名导航第一层数据
        newArray:[],   // 地名导航第二层数据
        curPage:0,
        placeItem:"Z",
        // 首字母状态
        placeActive:'22',
        titFormsNames:'',
        // 地名导航表格数据
        placeData:[],
        placePageInfo: {
            currentPage: 1, //初始页
            pagesize: 10, //    每页的数据 
        },
        placeTotal:0, // 总数据
        curKeyword: '', // 当前的keyword,方便分页时调方法
        titFormsName1:'',
        // 人名导航数据
        peopleData:[],
        peoplePageInfo: {
            currentPage: 1, //初始页
            pagesize: 10, //    每页的数据
        },
        peopleTotal:0,
        curAuthor: '', // 当前的author, 方便分页时调用
        peopleArray:[], // 人名导航数据
        peopleItem:'A',
        peopleActive:0,
        // 跟返回人名导航对齐的标题
        titFormsName:'',
        InitialsList: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'W', 'X', 'Y', 'Z'],
        error:'抱歉、数据请求失败',
      }
    },
    components:{
        'my-tree':myTree,
    },
    computed : {
    },
    created () {
        sessionStorage.setItem('active',2)
        if (this.getUrlParam('downMenu') && this.getUrlParam('downMenu') != '') {
           this.downMenu = this.getUrlParam('downMenu');
        //    this.retrieval()
        }
        if (this.getUrlParam('inpVal') && this.getUrlParam('inpVal') != '') {
            this.inpVal = this.getUrlParam('inpVal')
            // this.retrieval()
        }
	    this.inpSearchVal = this.getUrlParam('inpVal') 
        this.$nextTick (() => {
            Bus.$on('childEvent', ref => {
                this.classifyPageInfo.currentPage =1
                let url ="";
                let search = '';
                if(!this.EnglishName){
                    if(!this.inpSearchVal){
                        search = ''
                    }else{
                        search = this.inpSearchVal+' AND '
                    }
                }else{
                    search =this.EnglishName+':'+this.inpSearchVal+' AND '
                }
                this.searchVal = search
                
                if(ref.search){
                    this.searchVal = this.searchVal+ref.search
                }
                if(ref.menuCode == 'year'){
                    this.isRetrievalContent =false
                    url = '/api/newspaper/select?q='+this.searchVal+'&page='+this.classifyPageInfo.currentPage+'&size='+this.classifyPageInfo.pagesize 
                }else{
                    url = '/api/newspaper/select?q='+this.searchVal+' classify:'+ref.id+'&page='+this.classifyPageInfo.currentPage+'&size='+this.classifyPageInfo.pagesize    
                    this.searchVal = this.searchVal+' classify:'+ref.id 
                }
               
               this.$http.get(url).then(res => {
                this.classifyData = res.data.itemList;
                this.classifyTotal = res.data.recordCount;
               }).catch(error => {
                    console.log(error, '检索错误信息');
                    this.$message({
                        showClose: true,
                        message: this.error,
                        type: 'warning'
                    });
               })
            })
       })
        
    },
    mounted () {
        this.getClassifyData()
        this.init()
    },
    methods:{
        init:function () {
            this.getRegion ();
            this.getName ()
        },
        // --------------- 分类导航事件 -----------
         // 获取分类导航数据
         init:function () {
            this.$http.get('/api/newspaper/select?q='+this.EnglishName+((this.EnglishName != '' && this.inpVal != '') ? ':' :'')+this.inpVal+'&page='+this.classifyPageInfo.currentPage+'&size='+this.classifyPageInfo.pagesize).then(res => {
                console.log(res.data.menus,res.data, '获取分类导航数据')
                // 获取左边检索聚类中的分类导航数据
                if (res.data.menus.length > 0) {
                   this.retrievalClustering = res.data.menus;
                }
                this.classifyData = res.data.itemList;
                this.classifyTotal = res.data.recordCount;
                if (this.getUrlParam('downMenu') || this.getUrlParam('inpVal')) {
                    this.retrieval()
                }
               
            }).catch(error => {
                console.log(error, '检索错误信息');
                this.$message({
                    showClose: true,
                    message: this.error,
                    type: 'warning'
                });
            })
        },
          // 获取分类导航数据
        getClassifyData:function () {
            this.$http.get('/api/newspaper/select?q='+this.searchVal+'&page='+this.classifyPageInfo.currentPage+'&size='+this.classifyPageInfo.pagesize).then(res => {
                this.classifyData = res.data.itemList;
                this.classifyTotal = res.data.recordCount;
          
               
            }).catch(error => {
                console.log(error, '检索错误信息');
                this.$message({
                    showClose: true,
                    message: this.error,
                    type: 'warning'
                });
            })
        },
        // 处理左侧聚类中的分类导航数据
        handleRetrievalClustering: function (data) {
          console.log(data, 'chulishuju')
        },
        // 点击检索下拉框
        clitit: function (item) {
           this.downMenu = item.title;
        },
        // 点击检索按钮
        retrieval (){
            // alert(this.downMenu)
            this.classifyPageInfo.currentPage =1
            switch (this.downMenu) {
               case '全文':
                   this.EnglishName = 'contentShow';
                   this.isRetrievalContent= true;
                   break;
               case '题名':
                   this.EnglishName = 'title';
                   this.isRetrievalContent= false;
                   break;
               case '作者':
                   this.EnglishName = 'author';
                   this.isRetrievalContent= false;
                   break;
               case '主题词':
                    this.EnglishName = 'subjectword';
                    this.isRetrievalContent= false;
                     break;
               case '关键词':
                   this.EnglishName = 'keyword';
                   this.isRetrievalContent= false;
                   break;
               default:
                   this.isRetrievalContent= true;
                   this.EnglishName = '';   
            }
            this.inpVal = this.inpSearchVal
            this.searchVal =this.EnglishName+((this.EnglishName != '' && this.inpVal != '') ? ':' :'')+this.inpVal
            this.$http.get('/api/newspaper/select?q='+this.EnglishName+((this.EnglishName != '' && this.inpVal != '') ? ':' :'')+this.inpVal+'&page='+this.classifyPageInfo.currentPage+'&size='+this.classifyPageInfo.pagesize).then(res => {
                console.log(res.data.itemList, '------ 获取检索数据 -----')
                this.retrievalClustering = res.data.menus;
                this.classifyData = res.data.itemList;
                this.classifyTotal = res.data.recordCount;
                // this.inpVal = '';
            }).catch(error => {
                console.log(error, '检索错误信息');
                this.$message({
                    showClose: true,
                    message: this.error,
                    type: 'error'
                });
            })
        },
        // 检索的回车事件
        searchEnterFun: function (e) {
          if (e.keyCode == 13) {
            this.retrieval ();   
          }
        },
        // 高级检索
        advancedSearch: function () {
          this.isRetrieval = true;
          this.getNewspaperType();
        },
        // 返回普通检索
        returnOrdinary: function () {
            this.isRetrieval = false;
        },
        // 处理结果数据
        handleResult: function (result) {
            if (result == null) {
                this.$message({
                    showClose: true,
                    message: '您搜索的暂无内容请重新输入',
                    type: 'warning'
                });
                this.inpVal = '';
            } else {
              this.classifyData = result.list;
              this.classifyTotal = result.total;
            }
        },
        // 点击分类导航每一行 即在线阅读
        CClick:function (item) {
            window.open('readingPage.html?paperId='+ item.paperId + '&issueNo=' + item.issueNo +'&pageNo='+item.pageNo, 'readingPage');
        },
        //每页下拉显示数据
        classifySizeChange: function(size) {
           this.classifyPageInfo.pagesize = size
           this.getClassifyData() 
        },
        //点击第几页
        classifyCurrentChange: function(currentPage) {
           this.classifyPageInfo.currentPage = currentPage;
           this.getClassifyData() 
             
        },
        // --------------------- 地名导航事件 ----------------
         // 获取地名数据
        getRegion: function () {
            let that = this;
            this.$http.get('/api/newspaper/country/' + this.placeItem).then (res => {
               console.log(res.data.data, '!----获取地名数据----!')
               if (res.data.code == 0) {
                   var data = res.data.data;
                   if (data.length == 0) {
                    this.plcaeArray = [
                        ['暂时还没有数据']
                    ]
                   } else {
                        this.NameList = data
                        let index = 0;
                        var arr = []
                        while (index < this.NameList.length) {
                            arr.push(this.NameList.slice(index, index += 4));
                        }
                        this.plcaeArray = arr
                        arr = []
                    }
               }
            }).catch(error => {
               this.$message.error('抱歉，请求数据失败');
            })  
        },
        // 返回地名导航
        returnPlaceNavigation: function () {
            this.ifShow = 'nosee'
            // sessionStorage.setItem('ifShow', this.ifShow)
            // 让表格数据、分页总数、每页显示多少条、当前页清空
            this.placeData = [];
            this.placeTotal = 0;
            this.placePageInfo.pagesize = 10;
            this.placePageInfo.currentPage = 1;
        },
        // 点击地名导航上面的首字母
        placeClic(i, item) {
            this.placeActive = i;
            this.$http.get("/api/newspaper/country/" + item).then(res => {
              if (res.data.data.length == 0) {
                this.plcaeArray = [["暂时还没有数据"]];
              } else {
                this.NameList = res.data.data;
                let index = 0;
                var arr = [];
                while (index < this.NameList.length) {
                  arr.push(this.NameList.slice(index, (index += 4)));
                }
                this.plcaeArray = arr;
                arr = [];
              }
            }).catch(error => {
                this.$message({
                    showClose: true,
                    message: this.error,
                    type: 'warning'
                });
            });
        },
        // 点击地名导航第一层数据[首字母下面的数据]根据国家分类获取所有地区
        nameClick(item) {
            if (item != "暂时还没有数据") {
                this.titFormsName1 = item;
                this.ifShow = "nosee";
                this.$http.get("/api/newspaper/area/" + item).then(res => {
                    if (res.data.code == 0) {
                        if (res.data.data.length == 0) {
                            this.newArray = [["暂时还没有数据"]];
                        } else {
                            this.NameList = res.data.data;
                            let index = 0;
                            var arr = [];
                            while (index < this.NameList.length) {
                                 arr.push(this.NameList.slice(index, (index += 5)));
                            }
                            this.newArray = arr;
                            arr = [];
                        }
                    } else {
                       throw this.error = '数据查询失败'
                    }
                }).catch(error => {
                    this.$message({
                        showClose: true,
                        message: this.error,
                        type: 'warning' 
                    })
                });
            } else {
                this.$message({
                    showClose: true,
                    message: '抱歉，暂无数据请重新点击',
                    type: 'warning'
                });
            }
        },
        // 点击地名导航第二层数据
        clickPlace(item) {
            console.log(item, '张三')
            this.curKeyword = item;
            this.ifShow = "none";
            // if (sessionStorage.getItem("hxj") == null) {
            this.$http
                .post("/api/newspaper/search", {
                  provinces: this.curKeyword,
                  params: {
                    pageNum: this.placePageInfo.currentPage,
                    pageSize: this.placePageInfo.pagesize,
                    orderBy: ""
                  }
                })
                .then(res => {
                    console.log(res, '地名导航数据表格')
                   if (res.data.data != null ) {
                     this.placeData = res.data.data.list;
                     this.placeTotal = res.data.data.total;
                   }
                  this.titFormsNames = item;
                })
                .catch (eroor => {
                    this.$message({
                        showClose: true,
                        message: '抱歉，请求数据失败',
                        type: 'error'
                    });
                });
        },
        placeSizeChange (size) {
          this.placePageInfo.pagesize = size;
          this.clickPlace(this.curKeyword)
        },
        placeCurrentChange (currentPage) {
          this.placePageInfo.currentPage = currentPage;
          this.clickPlace(this.curKeyword) 
        },
        // 点击地名导航table每一行
        PClick: function (item) {
            window.location.href = 'readingPage.html?paperId=' + item.paperId + '&issueNo=' + item.issueNo + '&pageNo=' + item.pageNo
        },
        // -------------------------- 人名导航事件 -------------------------
        // 获取人名导航数据
        getName:function () {
            this.$http.get('/api/newspaper/author/' + this.peopleItem).then(res => {
                console.log(res.data.data, '!----- 获取人名导航数据 ----!')
                this.fileName(res.data.data)
            })
        },
        // 处理人名导航数据
        fileName: function (data) {
           if (data.length == 0) {
                this.peopleArray = [
                    ['暂时还没有数据']
                ]
            } else {
                this.NameList = data
                let index = 0;
                var arr = []
                while (index < this.NameList.length) {
                    arr.push(this.NameList.slice(index, index += 4));
                }
                this.peopleArray = arr
                arr = []
            }
        },
        //  点击人名导航上面的首字母
        listClic: function (i,item) {
            this.peopleActive = i
            this.$http.get('/api/newspaper/author/' + item).then(res => {
                    if (res.data.data.length == 0) {
                        this.peopleArray = [
                            ['暂时还没有数据']
                        ]
                    } else {
                        this.NameList = res.data.data
                        let index = 0;
                        var arr = []
                        while (index < this.NameList.length) {
                            arr.push(this.NameList.slice(index, index += 4));
                        }
                        this.peopleArray = arr
                        arr = []
                    }
                })
        },
        // 点击人名导航第二层数据
        peopleClick: function (item) {
            if (item != '暂时还没有数据'){
                this.curAuthor = item;
                this.ifShow = 'none'
                this.$http.get(`/api/newspaper/getByName/${this.curAuthor}?pageNum=${this.peoplePageInfo.currentPage}&pageSize=${this.peoplePageInfo.pagesize}` 
                ).then(res => {
                    console.log(res.data.data, '人名导航数据 表格的')
                    if (res.data.data == null) {
                        this.titFormsName = '暂时还没有数据'
                    } else {
                        this.peopleData = res.data.data.list;
                        this.peopleTotal = res.data.data.total;
                        this.titFormsName = item
                    }
                })
            } else {
                this.$message({
                    message: '抱歉，暂无数据请重新点击',
                    type: 'warning'
                });  
            }
            
        },
        // 人名导航分页
        peopleSizeChange:function (size) {
          this.peoplePageInfo.pagesize = size;
          this.peopleClick(this.curAuthor)
        },
        peopleCurrentChange: function (currentPage) {
          this.peoplePageInfo.currentPage = currentPage;
          this.peopleClick(this.curAuthor)
        },
        // 返回人名导航
        returnNameNavigation: function () {
            this.ifShow = 'block';
             // 让表格数据、分页总数、每页显示多少条、当前页清空
             this.peopleData = [];
             this.peopleTotal = 0;
             this.peoplePageInfo.currentPage = 1;
             this.peoplePageInfo.pagesize = 10;
        },
        // 点击人名导航table中每一行数据
        RClick: function (item) {
            console.log(item)
            window.location.href = 'readingPage.html?paperId=' + item.paperId + '&issueNo=' + item.issueNo + '&pageNo=' + item.pageNo
        },
        // --------------- 高级检索部分 -----------
        // 获取报纸种类
        getNewspaperType: function () {
          return new Promise ((resolve, reject) => {
            this.$http.get('/api/newspaper/papers').then (res => {
               if (res.data.code == 0 && res.data.data.length != 0) {
                console.log(res.data.data, '报纸种类')
                this.newspaperType = res.data.data;
               } else {
                 throw error = '报纸种类数据为空'
               }
            })
              
          })
        },
        // 点击加号添加数据
        plus: function () {
            this.inputTerm.push({term:'AND',search:'全文',content:''})
            
            this.$nextTick(() => {
                this.minus();
            })
        },
        // 高级检索中的检索id:3375 OR id:3376 AND keyword:中小企业
        advanced: function () {
            let searchTermArr = [];
            let content;
            if(this.newspaperTypeVal){
                searchTermArr.push(`paperId:${this.newspaperTypeVal} AND `)
            }
            this.inputTerm.forEach(term => {
                this.Spinner.forEach(spinner => {
                    if(term.search == spinner.title){
                        term.EnglishName = spinner.val
                    }
                });
                content = !term.content?"''":term.content
               
                if(!term.term){
                    searchTermArr.push(`${term.EnglishName}:${content}`)
                }else{
                    searchTermArr.push(` ${term.term} ${term.EnglishName}:${content}`)
                }
               
            });  
           
            if(this.inTime && this.singleElect ==3){
                searchTermArr.push(` AND publishedDate:%5B${ this.inTime[0]} TO ${ this.inTime[1]}%5D`)
            }
            if(this.brforeTime && this.singleElect ==4){
                searchTermArr.push(` AND publishedDate:%5B0000-01-01 TO ${ this.brforeTime}%5D`)
            }
            if(this.afterTime && this.singleElect ==5){
                searchTermArr.push(` AND publishedDate:%5B${this.afterTime} TO 9999-12-29%5D`)
            }
            this.$http.get(`/api/newspaper/select?q=${searchTermArr.join('')}&page=1&size=10`).then(res => {
                this.searchVal = searchTermArr.join('')
                this.retrievalClustering = res.data.menus;
                this.classifyData = res.data.itemList;
                this.classifyTotal = res.data.recordCount;
            })
            this.$nextTick(() =>{
                this.returnOrdinary()
            })
        },
        // 点击减号
        minus () {
            var that = this;
            $('.myLi .el-icon-minus').click (function () {
                var findPEli = $(this).parents('.PEli').get(0);
                findPEli.remove()
            })
        },
        

         // 获取地址栏参数
        getUrlParam: function(name){
            var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
            var url = decodeURI(window.location.search) ////如果出现乱码的话，可以用decodeURI()进行解码
            var r = url.substr(1).match(reg);
            if (r!=null) return unescape(r[2]); return null;
        }
    },
    watch: {
      
    }
})