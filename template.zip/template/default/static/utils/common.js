
 /**
 * 防抖函数
 * @param method 事件触发的操作
 * @param delay 多少毫秒内连续触发事件，不会执行
 * @returns {Function}
 */
function debounce(method,delay) {
  let timer = null;
  return function () {
    // 获取函数的作用域和变量
      let self = this,
          args = arguments;
      timer && clearTimeout(timer);
      timer = setTimeout(function () {
          method.apply(self,args);
      },delay);
  }
}
// 封装ajax
function ajax(methods,url,callBack,text) {
  if(window.XMLHttpRequest){
      //  IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
      var xhr = new XMLHttpRequest()
  }else{
     // IE6, IE5 浏览器执行代码
      var xhr = new ActiveXObject("Microsoft.XMLHTTP")
  }
  // 给methods 一个默认值
  var methods = methods|| 'get' ;
  xhr.open(methods,url,true);
  // 如果是get请求，直接调用send方法发送请求
  if (methods== 'get'){
      xhr.send();
  }
  // 如果是post请求，则可配置请求参数
  if (methods=='post'){
      xhr.send(text);
  }
  xhr.onreadystatechange=function(){
      if(xhr.readyState == 4){
          if(xhr.status== 200){
              // 请求成功之后调用回调函数
              callBack(xhr.responseText);
          }else{
              let error = '错误码' + xhr.status
              callBack(error);
          }
      }
  }
}
function detectZoom (){ 
  var ratio = 0,
    screen = window.screen,
    ua = navigator.userAgent.toLowerCase();
 
   if (window.devicePixelRatio !== undefined) {
      ratio = window.devicePixelRatio;
  }
  else if (~ua.indexOf('msie')) {  
    if (screen.deviceXDPI && screen.logicalXDPI) {
      ratio = screen.deviceXDPI / screen.logicalXDPI;
    }
  }
  else if (window.outerWidth !== undefined && window.innerWidth !== undefined) {
    ratio = window.outerWidth / window.innerWidth;
  }
   
   if (ratio){
    ratio = Math.round(ratio * 100);
  }
   
   return ratio;
};
/**
 * 日期格式化
 * @param fmt yyyyMMddHHmmss
 * @returns {*}
 */

Date.prototype.pattern = function (fmt) {
  var o = {
    "M+": this.getMonth() + 1, //月份
    "d+": this.getDate(), //日
    "h+": this.getHours() % 12 == 0 ? 12 : this.getHours() % 12, //小时
    "H+": this.getHours(), //小时
    "m+": this.getMinutes(), //分
    "s+": this.getSeconds(), //秒
    "q+": Math.floor((this.getMonth() + 3) / 3), //季度
    "S": this.getMilliseconds() //毫秒
  };
  var week = {
    "0": "/u65e5",
    "1": "/u4e00",
    "2": "/u4e8c",
    "3": "/u4e09",
    "4": "/u56db",
    "5": "/u4e94",
    "6": "/u516d"
  };
  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
  }
  if (/(E+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, ((RegExp.$1.length > 1) ? (RegExp.$1.length > 2 ? "/u661f/u671f" : "/u5468") : "") + week[this.getDay() + ""]);
  }
  for (var k in o) {
    if (new RegExp("(" + k + ")").test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    }
  }
  return fmt;
};
// 时间的封装
function getTime(dt) {
  dt = new Date(Date.parse(dt.replace(/-/g,"/")));
  var year = dt.getFullYear();
  var month = dt.getMonth() + 1;
  var day = dt.getDate();
  var hour = dt.getHours();
  var min = dt.getMinutes();
  var s = dt.getSeconds();
  // 修改双位数
  month = month < 10 ? "0" + month : month;
  day = day < 10 ? "0" + day : day;
  hour = hour < 10 ? "0" + hour : hour;
  min = min < 10 ? "0" + min : min;
  s = s < 10 ? "0" + s : s;
  return year + "年" + month + "月" + day + "日";
}
//进行检查的工具函数.
 // 校验电话号
function isPhone (value){
    //  var isTel = /^\d{3}-\d{7,8}|\d{4}-\d{7,8}$/;
    // var isTel = /^[1][3,4,5,6,7,8,9][0-9]{9}$/;
    const isPhone = /^([0-9]{3,4}-)?[0-9]{7,8}$/; // 0571-86295197
    const isPhone02 = /^\d{3,4}-\d{3,4}-\d{3,4}$/; // 4001-550-520
    // const isPhone02 = /^[0-9]{3,4}-[0-9]{2,3}-[0-9]{2,3}$/; // 4001-550-520
    // const isPhone02 = /^([0-9]{3,4}-)?([0-9]{3,4}-)?[0-9]{3,4}$/; // 4001-550-520
    const isMob=/^[1][3,4,5,6,7,8,9][0-9]{9}$/;
    // const phone02 = /^0\d{2,3}-?\d{7,8}$/;
    const valuePhone = value.trim();
    if (isMob.test(valuePhone) || isPhone.test(valuePhone) || isPhone02.test(valuePhone)) { // 正则验证
        // callback(); // 校验通过
        return true;
    } else {
        // callback('请输入正确手机号或座机电话'); // 校验不通过
        return false;
    }
}
// 校验姓名格式
function isName (name) {
    var xingming = /^([\u4E00-\u9FA5]|[·])*$/;
    var xingming1 = /^[A-Za-z0-9\(\)、.·-](\s{0,1}[A-Za-z0-9\(\)、.·-])+$/;
    if (xingming.test(name) || xingming1.test(name)) {
    } else {
        return false;
    }
    return true;
}
// 校验姓名长度
function checkNameLength (name) {
  var xingming = /^([\u4E00-\u9FA5]|[·])*$/;
  var xingming1 = /^[A-Za-z0-9\(\)、.·-](\s{0,1}[A-Za-z0-9\(\)、.·-])+$/;
  if (xingming.test(name)) {
      if (name.length < 101) {
      } else {
          return false;
      }
  } else {
      if (xingming1.test(name)) {
          if (name.length > 0 && name.length < 201) {
          } else {
              return false;
          }
      } else {
          return false;
      }
  }
  return true;
}
// 校验错误描述长度
function checkDescriptionLength (val) {
  var  miaoshu= /^([\u4E00-\u9FA5]|[·])*$/;
  var miaoshu1 = /^[A-Za-z0-9\(\)、.·-](\s{0,1}[A-Za-z0-9\(\)、.·-])+$/;
  if (miaoshu.test(val)) {
      if (val.length < 101) {
      } else {
          return false;
      }
  } else {
      if (miaoshu1.test(val)) {
          if (val.length > 0 && val.length < 201) {
          } else {
              return false;
          }
      } else {
          return false;
      }
  }
  return true;
}

