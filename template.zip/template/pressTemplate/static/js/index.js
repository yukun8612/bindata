Vue.prototype.$http = axios;
Newspaper.$http = axios;
// 创建-个vue实力
new Vue({
    el:'#wrap',
    // 定义属性，并设置初始值
    data:function () {
      return {
        pressIntroduction:'', // 报刊介绍
        inpVal:'',
        downMenu:'全部',
        Spinner: [
            {
              title: "全部",
              value:0
            },
            {
                title: "全文",
                value:1
            },
            {
                title: "题名",
                value:2,
            },
            {
                title: "作者",
                value:3
            },
            {
                title: "主题词",
                value:4
            },
            {
                title: "关键词",
                value:5
            }
        ],

        // ----------------------------- 报刊数据 --------------------------,
         // 报刊的状态
        pressStatus: {
          disPlayMore:false,
          disPlayList: false,  //图片列表
        },
        // 图片数据
        pictureData:[],
        moreData:[],
        baseUrl:'',
      }
    },
    // 在模板渲染成html前调用，即通常初始化某些属性值，然后再渲染成视图。
    created () {},
    // 在模板渲染成html后调用，通常是初始化页面完成后，再对html的dom节点进行一些需要的操作
    mounted () {
        this.init ();
    },
    methods:{
        // 初始数据
        init: function () {
          this.getPressIntroduction ();
          this.getPapers ();
        },
        // 获取报刊介绍
        getPressIntroduction: function () {
          Newspaper.getLibraryInfo().then (library => {
             if (library.paperText != null) {
              this.pressIntroduction = library.paperText;
             }
          })
        },
        // 获取报刊的图片数据
        getPapers: function () {
           Newspaper.getPapers().then (press => {
               // 报刊数据
              if(press.length > 12) {
                this.pictureData = press.slice(0, 12);
                this.pressStatus.disPlayMore = true;
              }else {
                this.pictureData = press;
              }
              this.moreData = press;
           })
        },
        /* ---------------------------------------------- 报刊事件处理 -----------------------------------*/
        // 点击检索下拉框
        clickTitle: function (item) {
          this.downMenu = item.title;
        },
        // 点击检索回车事件
        enterFun: function (e) {
          if (e.keyCode == 13) {
            this.pressRetrieval();
          }
        },
        // 报刊检索
        pressRetrieval: function () {
           window.location.href = "newspaperSearch.html?downMenu="+this.downMenu+"&inpVal="+this.inpVal;
        },
        // 点击报刊列表的每一条数据
        goPeriod: function (item) {
          window.open("readingPage.html?paperId=" + item.id, "readingPage");
        },
         // 点击报刊列表上的更多
        clickMore:function () {
          window.location.href = 'detailsPage.html';
        },
        
    }
})