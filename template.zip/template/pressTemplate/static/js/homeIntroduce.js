Vue.prototype.$http = axios;
var Bus = new Vue ();
// 创建-个vue实力
new Vue({
    el:'#wrap',
    // 定义属性，并设置初始值
    data:function () {
      return {
        paperText:'',
        library:{},
      }
    },
    created () {
        sessionStorage.setItem('active',1)
    },
    mounted () {
      this.getPaperText ();
    },
    methods:{
        // 获取报纸介绍数据
        getPaperText: function () {
          Newspaper.getLibraryInfo().then(library => {
            this.paperText = library.paperText;
            this.library = library;
          })
        },
    }
})