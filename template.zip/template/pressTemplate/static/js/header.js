Vue.prototype.$http = axios;
Newspaper.$http = axios;
// 创建-个vue实力
vueObj = new Vue({
    el:'#header',
    // 定义属性，并设置初始值
    data:function () {
      return {
       
        // 用户基本信息
        userInfo:{},
        // 用户权限
        permission:{},
        // ------------------------- 头部信息 -----------------------------
        icon: [
            {
                src: './static/images/icon/home.png',
                tit: "首页",
                name: 'index.html',
                path:'/index',
                isIcon:false

            }, {
                src: "./static/images/icon/jieshao.png",
                tit: "报刊介绍",
                name: 'homeIntroduce.html',
                path:'/homeIntroduce',
                isIcon:false
            }, {
                src: "./static/images/icon/search_1.png",
                tit: "报刊检索",
                name: 'newspaperSearch.html',
                path:'/newspaperSearch',
                isIcon:false
            },
            {
                src: "./static/images/icon/img_xs.png",
                tit: "图库",
                name: 'homePictures.html',
                path:'/homePictures',
                isIcon:false

            }, {
                src: "./static/images/icon/yanjiu.png",
                tit: "报刊研究",
                name: 'homeRetrieval.html',
                path:'/homeRetrieval',
                isIcon:false
            }, {
                src: "./static/images/icon/new_zx.png",
                tit: "动态资讯",
                name: 'homeInformation.html',
                path:'/homeInformation',
                isIcon:false
            }
        ],
        navigationModule:'', // 控制图标是否显示
        active:0,
      }
    },
    // 在模板渲染成html前调用，即通常初始化某些属性值，然后再渲染成视图。
    created () {
        if(sessionStorage.getItem('active') != null) {
           this.active = sessionStorage.getItem('active')
        }
      if (getUrlParam('active') != null) {
         this.active = getUrlParam('active');
      }
      this.initialize ();
      this.getPermission ();
      
    },
    // 在模板渲染成html后调用，通常是初始化页面完成后，再对html的dom节点进行一些需要的操作
    mounted () {
    },
    methods:{
        // 初始获取数据
        initialize: function () {
            //   获取用户信息
            Newspaper.getUserInfo().then (userInfo => {
                this.userInfo = userInfo;
                if (userInfo.userType == 'Visitor') { // 如果是游客跳转登录页
                    window.location.href = 'login.html';   
                }
            })
            Newspaper.getLibraryInfo ().then (library => {
                this.navigationModule = library.navigationModule;
                let navigationModule = this.navigationModule.split(',');
                navigationModule.forEach((el, k) => {
                    switch (el) {
                        case '1':
                            this.icon[0].isIcon = true;
                            break;
                        case '2':
                        this.icon[1].isIcon = true;
                            break;
                        case '3':
                        this.icon[2].isIcon = true;
                            break;
                        case '4':
                            this.icon[3].isIcon = true;
                            break;
                        case '5':
                            
                            this.icon[4].isIcon = true;
                            break;
                        case '6':
                        this.icon[5].isIcon = true;
                            break;
                    }
                });
            })
        },
         //获取用户权限
        getPermission: function () {
           Newspaper.getPermission().then (permission => {
              this.permission = permission;
           })
        },
        // ------------------------ 头部的业务处理 ----------------------------
        handleCommand: function (item) {
            location.href = '/' + item.code + '/'
        },
        // 点击登录按钮
        loginEvent: function () {
            window.location.href = 'login.html';
        },
        clickIcon: function (item, index) {
            sessionStorage.setItem('active', index)
            window.location.href = item.name;
        },
        // 退出
        signOut: function (userType) {
            $.ajax({
                  type: "post",
                  url: "/logout",
                  success: function(res) {
                    location.href = 'login.html';
                  }
            });
        },
        // 个人中心
        personalCenter: function (userType) {
            window.location.href = 'personalCenter.html';  
        },
        // 点击后台管理
        management: function () {
            location.href = '/admin';
        },
        // 关于事件
        goAbout:function (userType) {
          if (userType == 'IPUser') {
            window.location.href = 'about.html?userType='+userType;
          }
          else if (userType == 'SysUser') {
           window.location.href = 'about.html?userType='+userType + '&loginName='+ this.userInfo.userInfo.loginName;
          }
          else if (userType == 'LoginUser') { // 账密
            window.location.href = 'about.html?userType='+userType + '&userName='+ this.userInfo.userName;
          }
        },
        
    }
})