Vue.prototype.$http = axios;
Newspaper.$http = axios;
new Vue({
  el: "#wrap",
  data: function () {
    return {
      retrievalClustering: [],
      isRetrieval: false,
      downMenu: "全部",
      Spinner: [
        { title: '全部', val: 's_content' },
        { title: '全文', val: 'contentShow' },
        { title: '题名', val: 'title' },
        { title: '作者', val: 'author' },
        { title: '主题词', val: 'subjectword' },
        { title: '关键词', val: 'keyword' },
      ],
      EnglishName: '', // 检索时下拉框选中的值得英文名字
      inpSearchVal: '', // 只针对搜索框的内容
      singleElect: 3,
      brforeTime: '',
      inTime: '',
      afterTime: '',
      // 报刊表格数据
      pressTableData: [],
      // 报刊分页信息
      pressPageInfo: {
        currentPage: 1, // 当前页
        pageSize: 10, // 一页显示多少条
      },
      isRetrievalContent: false,  // 控制是否是普通检索中的检索全部和全文
      inpVal: '', // 获取地址栏参数
      searchVal: '',
      // 报刊导航数据
      pressData: [],
      newspaperTypeVal: '',
      // 报刊种类数据
      pressType: [],
      seniorVal: '',
      DownMenu: [
        { title: '全部', val: 's_content' },
        { title: '全文', val: 'contentShow' },
        { title: '题名', val: 'title' },
        { title: '作者', val: 'author' },
        { title: '主题词', val: 'subjectword' },
        { title: '关键词', val: 'keyword' },
      ],
      inputSearchVal: '',
      isQuery: false, // 是否模糊查询 isQuery= true 模糊查询 isQuery = false 精确查询
      sorting: 'desc', // 排序变量 desc降序 asc 升序 默认降序
      percent: 50,
    }
  },
  components: {},
  created() {
    if (getUrlParam('downMenu') && getUrlParam('downMenu') != '') {
      this.downMenu = getUrlParam('downMenu');
    }
    if (getUrlParam('inpVal') && getUrlParam('inpVal') != '' && getUrlParam('inpVal') != null) {
      this.inpVal = getUrlParam('inpVal')
    }
    this.inpSearchVal = getUrlParam('inpVal');
    this.retrieval()

  },
  mounted() {
    //  获取报刊左右两边数据
    this.init();

    this.getUserInfoData()
  },
  methods: {
    getUserInfoData() {
      var self = this
      Newspaper.getUserInfo().then(res => {
        console.log(res, 'Newspaper.getUserInfo')
        self.userVipData = {
          freeArtclies: res.freeArtclies,
          vipLevel: res.userInfo.vipLevel,
        }
      })
    },
    toVip() {
      this.$message({
        showClose: true,
        message: '成为VIP，查看所有检索结果',
        type: 'warning'
      });
    },
    // 初始化数据
    init: function () {
      this.getPapers();
      this.getPressList();
    },
    // 获取左侧的数据
    getPapers: function () {
      Newspaper.getPapers().then(papers => {
        this.pressData = papers;
      })
    },
    // 获取报刊列表数据
    getPressList: function () {
      this.$http.get('/api/newspaper/select?q=' + this.searchVal + '&page=' + this.pressPageInfo.currentPage + '&size=' + this.pressPageInfo.pageSize + '&sort=publishedDate ' + this.sorting).then(res => {
        this.pressTableData = res.data.itemList;
        this.getPage(res.data.recordCount)
      }).catch(error => {
        console.log(error, '检索错误信息');
        this.$message({
          showClose: true,
          message: this.error,
          type: 'warning'
        });
      })
    },
    // 获取表格分页数据
    getPage: function (recordCount) {
      var that = this;
      var num = recordCount / this.pressPageInfo.pageSize;
      if (Number.isInteger(num)) { // 判断num是不是整数
        var pageSize = parseInt(recordCount / this.pressPageInfo.pageSize);
      } else {
        var pageSize = parseInt(recordCount / this.pressPageInfo.pageSize) + 1;
      }
      if (pageSize == undefined) pageSize = 0;
      $("#page").paging({
        pageNum: this.pressPageInfo.currentPage, // 当前页面
        pageSize: pageSize, // 总页码
        totalList: recordCount, // 记录总数量
        callback: function (num) { //回调函数
          that.pressPageInfo.currentPage = num;
          that.getPressList();
        }
      });
    },
    // 检索回车事件
    searchEnterFun: function (e) {
      if (e.keyCode == 13) {
        this.retrieval();
      }
    },
    // 点击检索
    retrieval: function () {
      this.pressPageInfo.currentPage = 1
      switch (this.downMenu) {
        case '全文':
          this.EnglishName = 'contentShow';
          this.isRetrievalContent = true;
          break;
        case '题名':
          this.EnglishName = 'title';
          this.isRetrievalContent = false;
          break;
        case '作者':
          this.EnglishName = 'author';
          this.isRetrievalContent = false;
          break;
        case '主题词':
          this.EnglishName = 'subjectword';
          this.isRetrievalContent = false;
          break;
        case '关键词':
          this.EnglishName = 'keyword';
          this.isRetrievalContent = false;
          break;
        default:
          this.isRetrievalContent = true;
          this.EnglishName = '';
      }
      this.inpVal = this.inpSearchVal
      // 默认精确检索，你拼接检索词时加个双引号。
      if (this.isQuery) { // isQuery = true 模糊检索
        this.inpVal = this.inpVal;
      } else if (!this.isQuery && this.inpVal != '' && this.inpVal != null) { // isQuery = false 精确检索
        this.inpVal = '"' + this.inpVal + '"';
      }
      this.searchVal = this.EnglishName + ((this.EnglishName != '' && this.inpVal != '') ? ':' : '') + this.inpVal;
      if (this.searchVal == "null") {
        this.searchVal = '';
      }

      this.$http.get('/api/newspaper/select?q=' + this.searchVal + '&page=' + this.pressPageInfo.currentPage + '&size=' + this.pressPageInfo.pageSize + '&sort=publishedDate ' + this.sorting).then(res => {
        console.log(res.data.itemList, '------ 获取检索数据 -----')
        this.pressTableData = res.data.itemList;
        this.getPage(res.data.recordCount)
      }).catch(error => {
        console.log(error, '检索错误信息');
        this.$message({
          showClose: true,
          message: this.error,
          type: 'warning'
        });
      })
    },
    // 点击排序
    sortChange: function (param) {
      if (param.order == 'descending') { // 降序
        this.sorting = 'desc';
      } else if (param.order = 'ascending') { // 升序
        this.sorting = 'asc';
      }
      this.getPressList();
    },
    // 进入高级检索部分
    advancedSearch: function () {
      this.isRetrieval = true;
    },
    // 点击分类导航每一行 即在线阅读
    CClick: function (item) {
      window.open('readingPage.html?articleId=' + item.id, 'readingPage');
    },
    // 点击检索的下拉框
    clitit: function (item) {
      this.downMenu = item.title;
    },
    /**
     *  点击模糊搜索
    */
    fuzzySearch: function () {
      this.retrieval();
    },
    // 高级检索部分的事件
    // 点击普通检索
    returnOrdinary: function () {
      this.isRetrieval = false;
    },
    // 高级检索中的检索
    advanced: function () {
      let searchTermArr = [];
      let searchTermMidArr = [];
      let content;
      if (this.newspaperTypeVal != '') {
        searchTermArr.push(`paperId:${this.newspaperTypeVal}  `)
      }
      if (this.inputSearchVal != '') {
        searchTermMidArr.push(`${this.newspaperTypeVal}`)
      }
      if (this.seniorVal != '') {
        searchTermMidArr.push(` ${this.inputSearchVal}:${this.seniorVal}`)
      }
      if (searchTermMidArr.length > 0) {
        searchTermArr.push(searchTermMidArr.join(' '))
      }
      if (this.inTime && this.singleElect == 3) {
        searchTermArr.push(`publishedDate:%5B${this.inTime[0]} TO ${this.inTime[1]}%5D`)
      }
      if (this.brforeTime && this.singleElect == 4) {
        searchTermArr.push(`publishedDate:%5B0000-01-01 TO ${this.brforeTime}%5D`)
      }
      if (this.afterTime && this.singleElect == 5) {
        searchTermArr.push(`publishedDate:%5B${this.afterTime} TO 9999-12-29%5D`)
      }
      this.searchVal = searchTermArr.join(' AND ')

      this.$http.get(`/api/newspaper/select?q=${this.searchVal}&page=1&size=10`).then(res => {
        console.log(searchTermArr);
        this.pressTableData = res.data.itemList;
        this.getPage(res.data.recordCount);
        this.clearData()
      })
      this.$nextTick(() => {
        this.returnOrdinary()
      })
    },
    // 点击左侧的报刊
    goPress: function (item) {
      this.pressPageInfo.currentPage = 1;
      this.$http.get('/api/newspaper/select?q=paperId:' + item.id + '&page=' + this.pressPageInfo.currentPage + '&size=' + this.pressPageInfo.pageSize).then(res => {
        this.pressTableData = res.data.itemList;
        this.getPage(res.data.recordCount)
      }).catch(error => {
        console.log(error, '检索错误信息');
        this.$message({
          showClose: true,
          message: this.error,
          type: 'warning'
        });
      })
    },
    // 清空数据
    clearData: function () {
      this.newspaperTypeVal = '';
      this.inputSearchVal = '';
      this.seniorVal = '';
      this.inTime = '';
      this.brforeTime = '';
      this.afterTime = '';
      this.searchVal = '';
    }
  }
})