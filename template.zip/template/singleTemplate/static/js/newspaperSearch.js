Vue.prototype.$http = axios;
Vue.config.errorHandler = (error, vm) => {
    console.log(error, '错误信息')
    vm.$message({
        showClose: true,
        message: error,
        type: 'warning'
    });
};
Newspaper.$http = axios;
// 使用一个vue实例 作为事件的载体,用于绑定事件和处理发送事件，作为调度中心
let Bus = new Vue();
// 创建-个vue实力
new Vue({
    el:'#wrap',
    // 定义属性，并设置初始值
    data:function () {
      return {
        searchVal:'', 
        inpSearchVal:'',//只针对搜索框的内容
        EnglishName:'', // 检索时下拉框选中的值得英文名字
        inpVal:'', // 获取地址栏的参数
        library:{},
        classifyData:[],
        classifyPageInfo: {
          currentPage:1,
          pageSize:8
        },
        isRetrievalContent:false, // 控制是否是普通检索中的检索全部和全文
        downMenu:"全部",
        Spinner:[
            {title: '全部',val:'s_content'},
            {title:'全文',val:'contentShow'},
            {title:'题名',val:'title'},
            {title:'作者',val:'author'},
            {title:'主题词',val:'subjectword'},
            {title:'关键词',val:'keyword'},
        ],
        sorting: 'desc', // 排序 desc:降序 asc:升序 默认降序
      }
    },
    components:{
    },
    computed : {
    },
    created () {
      if (getUrlParam('inpVal') && getUrlParam('inpVal') != '') {
         this.inpVal = getUrlParam('inpVal');
      }
      this.inpSearchVal = getUrlParam('inpVal');
      this.btnRoute()
    },
    mounted () {
      this.initialize ()
    },
    methods:{
        // 初始化加载数据
        initialize: function () {
          this.getLibrary ();
          this.getNewspaper ();
        },
        // 获取资源信息
        getLibrary: function () {
            Newspaper.getLibraryInfo().then(library => {
                this.library = library;  
             })
        },
        getNewspaper: function () {
            this.$http.get('/api/newspaper/select?q='+this.searchVal+'&page='+this.classifyPageInfo.currentPage+'&size='+this.classifyPageInfo.pageSize+'&sort=publishedDate '+ this.sorting).then(res => {
                this.classifyData = res.data.itemList;
                this.getPage (res.data.recordCount);
               
            }).catch(error => {
                console.log(error, '检索错误信息');
                this.$message({
                    showClose: true,
                    message: this.error,
                    type: 'warning'
                });
            })
        },
        getPage:function (recordCount) {
            var that = this;
            var num = recordCount/this.classifyPageInfo.pageSize;
            if (Number.isInteger(num)) { // 判断num是不是整数
             var pageSize = parseInt(recordCount/this.classifyPageInfo.pageSize);
            } else {
             var pageSize = parseInt(recordCount/this.classifyPageInfo.pageSize) + 1;
            }
            if (pageSize == undefined) pageSize = 0;
             $("#page").paging({
                 pageNum: this.classifyPageInfo.currentPage, // 当前页面
                 pageSize: pageSize, // 总页码
                 totalList: recordCount, // 记录总数量
                 callback: function (num) { //回调函数
                     that.classifyPageInfo.currentPage = num;
                     that.getNewspaper ()
                 }
             });     
        },
        // 检索
        btnRoute: function () {
          this.classifyPageInfo.currentPage =1
          switch (this.downMenu) {
              case '全文':
                  this.EnglishName = 'contentShow';
                  this.isRetrievalContent= true;
                  break;
              case '题名':
                  this.EnglishName = 'title';
                  this.isRetrievalContent= false;
                  break;
              case '作者':
                  this.EnglishName = 'author';
                  this.isRetrievalContent= false;
                  break;
              case '主题词':
                  this.EnglishName = 'subjectword';
                  this.isRetrievalContent= false;
                    break;
              case '关键词':
                  this.EnglishName = 'keyword';
                  this.isRetrievalContent= false;
                  break;
              default:
                  this.isRetrievalContent= true;
                  this.EnglishName = '';   
          }
          this.inpVal = this.inpSearchVal
          this.searchVal =this.EnglishName+((this.EnglishName != '' && this.inpVal != '') ? ':' :'')+this.inpVal
          if(this.searchVal=="null"){
              this.searchVal='';
          }
          this.$http.get('/api/newspaper/select?q='+this.searchVal+'&page='+this.classifyPageInfo.currentPage+'&size='+this.classifyPageInfo.pageSize+'&sort=publishedDate '+ this.sorting).then (res => {
              console.log(res.data.itemList, '------ 获取检索数据 -----')
              this.classifyData = res.data.itemList;
              this.getPage (res.data.recordCount) 
          }).catch(error => {
              console.log(error, '检索错误信息');
              this.$message({
                  showClose: true,
                  message: this.error,
                  type: 'error'
              });
          })
            // this.getNewspaper ()
            // this.isRetrievalContent = true;
        },
        searchEnterFun:function (e) {
          if (e.keyCode == 13) {
            this.btnRoute()
          }
        },
        CClick: function (item) {
            window.open('readingPage.html?articleId='+ item.id, 'readingPage');
        },
        // 点击检索的下拉框
        clitit: function (item) {
          this.downMenu = item.title;  
        },
        // 点击排序
        sortChange: function (param) {
          if (param.order == 'ascending') { // 升序
            this.sorting = 'asc';
          } else if (param.order == 'descending') { // 降序
            this.sorting = 'desc';
          }
          this.getNewspaper ();
        }
    }
        
})