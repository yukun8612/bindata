Vue.prototype.$http = axios;
Vue.config.errorHandler = (error, vm) => {
    console.log(error, '错误信息')
    vm.$message({
        showClose: true,
        message: error,
        type: 'warning'
    });
};
// 使用一个vue实例 作为事件的载体,用于绑定事件和处理发送事件，作为调度中心
let Bus = new Vue();
vueObj = new Vue({
    el: '#readingPage',
    data: function() {
        //定义一个全局的变量，校验手机号
        var checkphone = (rule, value, callback) => {
            if (!value) {
                callback(new Error('请输入联系电话'))
            } else if (!isPhone(value)) {
                callback(new Error('请输入正确的手机号码'))
            } else {
                callback()
            }
        };
        // 校验姓名
        var checkname = (rule, value, callback) => {
                if (!value) {
                    callback(new Error('请输入您的姓名'));
                } else if (!isName(value)) {
                    callback(new Error('姓名格式不正确'))
                } else if (!checkNameLength(value)) {
                    callback(new error('姓名长度不能少于2字符且不能大于50字符（1汉字=2个字符）'))
                } else {
                    callback()
                }
            }
            // 校验错误描述
        var checkwrongDescription = (rule, value, callback) => {
            if (!isName(value)) {
                callback(new Error('错误描述格式不正确'));
            } else if (!checkNameLength(value)) {
                callback(new Error('错误描述长度不能少于2字符且不能大于200字符（1汉字=2个字符）'))
            } else {
                callback()
            }
        };
        return {
            allTitle: '',
            // 左侧控制热区数据
            hotSpan: {
                title: '',
                id: '',
                style: ''
            },
            // 右侧数据
            shHide: 'block',
            deficiencyTitleHeight: '',
            // 右侧子数据
            issueValue: '',
            paper: [], // 右侧期面容器
            issue: {},
            //左侧当前打开的版
            page: {
                // paperId:'',
                issueNo: '', // 期版id
                pageNo: '', // 版面id
            },
            //右侧当前显示的文章
            article: {},
            //用户权限
            permission: {},
            // 右侧报纸期次列表
            // 当前的paperId
            paperId: '',
            articleId: '', // 文章id
            error: '抱歉、数据请求失败',
            // 有奖纠错
            disputeVisible: false,
            disputeForm: {
                userName: '',
                userContact: '', // 用户联系方式
                description: '', // 错误描述
                images: '', // 截图
            },
            // 有奖纠纷校验规则
            disputeRules: {
                userName: [
                    { required: true, message: '请输入您的姓名', trigger: 'blur' },
                    { required: true, validator: checkname, trigger: 'blur' }
                ],
                userContact: [
                    { required: true, message: '请输入您的联系电话', trigger: 'blur' },
                    { required: true, validator: checkphone, trigger: 'blur' }
                ],
                description: [
                    { required: true, message: '请输入您的错误描述', trigger: 'blur' },
                    { required: true, validator: checkwrongDescription, trigger: 'blur' }
                ],
                // screenshot: [
                //     { required: true, message: '请上传您的截图', trigger: 'blur' }
                // ]
            },
            // 打印、复制、下载
            dialogVisible: false,
            jurisdictionTotal: '', // 下载、打印、复制弹框头部的权限信息
            jurisdictionNuit: '', // 单位（年、月、日）
            jurisdictionSurplus: '', // 剩余篇数
            jurisdictionNum: '',

            form: {
                userName: '', // 真实姓名
                workUnit: '', // 单位
                contact: '', // 联系电话
                description: '', //用途描述
            },
            // 下载、打印、复制校验规则
            formRules: {
                userName: [
                    { required: true, message: '请输入您的姓名', trigger: 'blur' },
                    { required: true, validator: checkname, trigger: 'blur' }
                ],
                contact: [
                    { required: true, message: '请输入您的联系电话', trigger: 'blur' },
                    { required: true, validator: checkphone, trigger: 'blur' }
                ],
                description: [
                    { required: true, message: '请输入您的用途描述', trigger: 'blur' },
                    { required: true, validator: checkwrongDescription, trigger: 'blur' }
                ]
            },
            // 是否禁止下载按钮
            isDown: true,
            //购买申请消息
            buyInfo: '',

            // 注释部分
            notesVisible: false,
            notesForm: {
                content: '',
                begin: '',
                end: '',
                selectedText: ''
            },
            notesRules: {
                content: [
                    { required: true, message: '请输入您的注释描述', trigger: 'blur' },
                    // {required:true, validator:checkwrongDescription, trigger:'blur'}
                ]
            },
            // 注释参数
            notesParams: {

            },
            container: { //窗口大小
                width: 1090,
                height: 694
            },
            // 蒙层对象
            lensView: null,
            visible: false,
            // 注释数据
            annoteData: [],
            baseUrl: '',
            copyEvent: {
                status: "none",
                text: "",
                submit() {
                    this.status = "submit";
                },
                cancel() {
                    this.status = "none";
                }
            },
            // 控制日历的变量
           isCanlendar: false,
           message:'',
        }
    },
    // 注册日历组件
    components:{
      'my-component':componentCalendar
    },
    watch: {
        dialogVisible(val, oldVal) {
            if (!val) this.copyEvent.cancel();
        }
    },
    // directives: {clickoutside},
    computed: {},
    created() {
        if (getUrlParam('paperId') != '') {
            this.paperId = getUrlParam("paperId")
        }
        if (getUrlParam("issueNo") != '') {
            this.page.issueNo = getUrlParam('issueNo')
        }
        if (getUrlParam("pageNo") != '') {
            this.page.pageNo = getUrlParam("pageNo")
        }
        if (getUrlParam('articleId') != '') {
            this.articleId = getUrlParam('articleId');
        }
        this.$nextTick(() => {
            Bus.$on('childEvent', ref => {
              this.isCanlendar = ref;
            })
        })
        // this.date = new Date().pattern('yyyy年MM月dd日');
    },
    mounted() {
        this.initialize();
        this.initViewer();
        this.getBaseUrl();
        this.getBuyInfo();
        // 调用屏幕滚动事件 
        //  注意是将事件绑定在window上，监听整个文档的滚动，也可以绑在document或者document.body上
        //  需要在元素加载之后再监听滚动事件 
        // 需要将addEventListener的第三个参数设置为true，即取消冒泡，要不然会绑定不成功
        this.$nextTick(function() {
            $("#content")[0].addEventListener('scroll', this.handleScroll, true);
        });
        window.addEventListener('resize', e => {
            this.resetContainer();
        });
        // 复制
        document.addEventListener('copy', event => {
           if (this.permission.newspaper.copy.enabled) { // 有权限情况下
                event.preventDefault();
                event.clipboardData.clearData();
                if (this.copyEvent.status == "none") {
                    this.copyEvent.text = window.getSelection(0).toString();
                    this.copyEvent.status = "doing"; //状态改为填写信息中
                    this.downloadPrintCopy('copy');
                }
                if (this.copyEvent.status == "submit") {
                    this.setClipboardText(event);
                    this.copyEvent.status = "none";
                }
                console.log(this.copyEvent.status + " " + this.copyEvent.text);
                return false;
           } else {  // 无权限情况下
                this.dialogVisible = true;
                this.message = '抱歉，您无权限';
                // this.jurisdictionTotal = '复制总数' + this.permission.newspaper.copy.total;
                // this.jurisdictionNuit = this.permission.newspaper.copy.cycle;
                // this.jurisdictionSurplus = '复制' + this.permission.newspaper.copy.available;
                // this.jurisdictionNum = this.permission.newspaper.copy.available;
                if (this.permission.newspaper.copy.available == 0) {
                    this.$message({
                        showClose: true,
                        // message: '您的《复制》次数已为0，不可进行此操作，请在下个权限期内再操作',
                        message:   "权限：抱歉，您无权限",
                        type: 'warning'
                    });
                }
           }
           
        })
        this.magnifier()
        this.getChoose();
    },

    destroyed() {},
    methods: {
        // 初始化加载数据
        initialize: function() {
            var articleId = getUrlParam("articleId");
            var paperId = getUrlParam("paperId");
            var pageNo = getUrlParam('pageNo');
            var issueNo = getUrlParam('issueNo');
            var _this = this;
            // 如果没有pageNo, issueNo 只有paperId 择显示列表页
            if ((pageNo == null || issueNo == null) && paperId != null) {
                this.shHide = "none";
            } else {
                this.shHide = "block";
            }
            this.getPermission();
            if (paperId == null && articleId != null) {
                this.getArticle(articleId).then(
                    article => {
                        this.paperId = article.paperId;
                        this.getPaper(article.paperId, article.issueNo).then(
                            paper => {
                                this.getPage(article.paperId, article.issueNo, article.pageNo, articleId).then(
                                    page => {
                                        //   如果控制注释的权限为true,则执行以下
                                        if (this.permission.newspaper.enableAnnotate) {
                                            this.getSelectAnnotate()
                                        }
                                    }
                                );
                            }
                        )
                    }
                )
            } else if (paperId != null) {
                this.getPaper(paperId, issueNo).then(
                    paper => {
                        if (issueNo == null)
                            issueNo = paper[0].issueNo;
                        if (pageNo == null)
                            pageNo = paper[0].pages[0].pageNo;
                        this.getPage(paperId, issueNo, pageNo).then(
                            page => {
                                //   如果控制注释的权限为true,则执行以下
                                if (this.permission.newspaper.enableAnnotate) {
                                    this.articleId = this.article.id;
                                    this.getSelectAnnotate()
                                }
                            }
                        );
                    }
                )
            }
        },
        // 获取某报纸期次列表
        getPaper: function(paperId, issueNo) {
            return new Promise((resolve, reject) => {
                this.$http.get('/api/newspaper/paper/' + paperId).then(res => {
                    if (res.data.code == 0) {
                        if (res.data.data.length == 0) {
                            throw this.error = '抱歉、数据为空'
                        } else {
                            this.paper = res.data.data; //报纸对象
                            Bus.$emit('paper', this.paper);
                            if (issueNo == null)
                                this.issue = this.paper[0]; //期对象
                            else
                                this.paper.forEach((item, index) => {
                                    if (item.issueNo == issueNo)
                                        this.issue = item;
                                })
                            resolve(res.data.data);
                        }
                    } else {
                        //    抛出异常
                        throw this.error = '抱歉、数据查询失败';
                    }
                })
            })
        },
        getPage: function(paperId, issueNo, pageNo, articleId) {
            return new Promise((resolve, reject) => {
                // 先读取权限
                this.getPermission(paperId, issueNo, pageNo).then(
                    permit => {
                        this.$http.get('/api/newspaper/page/' + paperId + '/' + issueNo + '/' + pageNo).then(res => {
                            if (res.data.code == 0) {
                                if (res.data.data.length == 0) {
                                    throw this.error = '抱歉、数据为空'
                                } else {
                                    this.handlePage(res.data.data, articleId)
                                }
                                resolve(res.data.data);

                            } else {
                                throw "null data";
                            }
                        })
                    })
            })
        },
        // 获取文章
        getArticle: function(articleId) {
            return new Promise((resolve, reject) => {
                this.$http.get('/api/newspaper/article/' + articleId).then(res => {
                    if (res.data.code == 0 && res.data.data != null) {
                        resolve(res.data.data);
                    } else {
                        throw error = '文章数据为空'
                    }
                })
            })
        },
        // 处理初始数据
        handlePage: function(data, articleId) {
            // 判断将处理的数据是否为数组，如果是返回true、 否则返回false、

            var articles = new Array();
            data.forEach((item, index) => {
                //此处需要处理多矩形情况
                var hotArray = [];
                item.hotspot.split('/').forEach((hotstr, index) => {
                        var hots = hotstr.split(',');
                        //刊的热区是全文
                        if (hots.length < 4) hots = [0, 0, 412, 586];
                        var hot = {
                            l: hots[0] / 412,
                            t: hots[1] / 586,
                            r: hots[2] / 412,
                            b: hots[3] / 586,
                            toString: function(img) {
                                return this.l * img.offsetWidth + ',' + this.t * img.offsetHeight + ',' +
                                    this.r * img.offsetWidth + ',' + this.b * img.offsetHeight;
                        }
                    }    
                    hotArray.push(hot);
                });
                if (this.issue.paperType == 2)
                    item.relatedPages = item.relatedPages.split(","); //分隔文章跨版
                else
                    item.relatedPages = [];
                //设置已读信息
                var ids = this.permission.newspaper.readedResIds;
                if (ids && ids.indexOf(item.id) > -1) item.readed = true;

                articles.push({
                    hot: hotArray,
                    title: item.title,
                    data: item,
                    id : item.id
                });
            })
            this.page = {
                img: data[0].pageImageSmall,
                pageNo: data[0].pageNo, // 版面
                issueNo: data[0].issueNo, // 期次id
                hasNext: this.issue.pages[this.issue.pages.length - 1].pageNo != data[0].pageNo,
                hasPre: this.issue.pages[0].pageNo != data[0].pageNo,
                articles: articles,
                id: data[0].id
            }
            if (articleId == null)
                this.article = this.page.articles[0].data;
            else
                this.page.articles.forEach((item, index) => {
                    if (item.data.id == articleId)
                        this.article = item.data;
                })
            Bus.$emit('page', this.page);
            document.title = this.article.paperName;
            // 将分页的状态给右边版本状态

        },
        // 获取baseUrl地址
        getBaseUrl: function() {
            this.$http.get('/api/user/info').then(res => {
                if (res.data.code == 0) {
                    this.baseUrl = res.data.data.baseUrl;
                } else {
                    throw error = '获取baseUrl地址失败'
                }
            }).catch(error => {
                this.$message({
                    showClose: true,
                    message: error,
                    type: 'warning'
                });
            })
        },
        //获取用户权限
        getPermission: function(paperId, issueNo, pageNo) {
            return new Promise((resolve, reject) => {
                this.$http.get('/api/user/permission/', {
                    params: {
                        'resType': "newspaper",
                        'paperId': paperId,
                        'issueNo': issueNo,
                        'pageNo': pageNo
                    }
                }).then(res => {
                    if (res.data.code == 0) {
                        this.permission = res.data.data;
                        console.log(this.permission, '初始拿到权限')
                    } else {
                        throw this.error = '抱歉、用户权限数据为空';
                    }
                    if (this.lensView != null)
                        this.lensView.reset(this.permission.newspaper.shadowType, this.permission.newspaper.shadowSize);
                    resolve(res.data.data);
                })
            })
        },
        //获取购买申请
        getBuyInfo: function() {
            this.$http.get('/api/library/libraryBuyApply').then(res => {
                if (res.data.code == 0) {
                    this.buyInfo = res.data.data.buyApplyExplain;
                }
            })
        },
        // 放大图片
        initViewer: function() {
            const ViewerDom = document.getElementById('version_period');
            const viewer = new Viewer(ViewerDom, {
                // 配置
                 url: 'data-original', //设置大图片的 url
                'button': true, // 显示右上角关闭按钮
                'loading': true,
                'navbar':false,
                show: function() { // 动态加载图片后，更新实例
                    viewer.update();
                },
            })
            this.resetContainer();
        },
        // 模糊放大读文章
        magnifier: function() {
            if (this.lensView == null) {
                if (this.permission.newspaper == null) {
                    this.lensView = new View(document.getElementById("myCanvas"), "rect", 200);
                } else if (this.permission.newspaper.shadowType != "none") {
                    this.lensView = new View(document.getElementById("myCanvas"),
                        this.permission.newspaper.shadowType, this.permission.newspaper.shadowSize);
                }
            } else
                this.lensView.reset(this.permission.newspaper.shadowType, this.permission.newspaper.shadowSize);
        },
        // 点击左侧的热点图
        listId(i) {
            // 阅读权限减1 注意 total<0 时权限不受控制
            var read = this.permission.newspaper.read;
            var trialRead = this.permission.newspaper.trialRead;
            if (read.enabled) {
                if (!this.article.readed)
                    read.available--;
                this.article = this.page.articles[i].data;
                if ((this.article.readed) || (read.total < 0 || read.available >= 0)) { // 可以阅读
                    //判断点击路由时触发的哪个id
                    this.shHide = 'block';
                    this.$nextTick(() => {
                        this.magnifier()
                    })
                    this.optLog("read");
                    this.articleId = this.article.id;
                    this.getSelectAnnotate();
                    this.article.readed = true;
                } else {
                    // // 判断有没有试读权限
                    if (trialRead.enabled) { // 有试读权限
                        this.shHide = 'block';
                        this.article = this.page.articles[i].data;
                        this.optLog("read");
                        if (this.article.content != null) { // 取最小值
                            var percent = this.article.content.length * (trialRead.percent) / 100;
                            var num = percent > trialRead.number ? trialRead.number : percent;
                            this.article.content = this.article.content.substr(0, num) + " <span style='color:red;'>您的阅读次数已用完，无权限查看全文</span>";
                        }
                        this.$message({
                            showClose: true,
                            message: '您本月阅读次数已经用完，此为试读内容。无权限查看',
                            type: 'warning'
                        });

                    } else { // 没有阅读权限
                        this.$message({
                            showClose: true,
                            message: '您的阅读次数已经用完，可在用户中心查看阅读历史。或下月再次翻阅',
                            type: 'warning'
                        });
                    }
                }
            } else {
                this.$message({
                    showClose: true,
                    message: '抱歉，您没有权限阅读',
                    type: 'warning'
                });

            }
            this.scrollToTop();
        },
        // 上一版
        pageNoleft() {
            var idx = 0;
            for (idx = 0; idx < this.issue.pages.length; idx++) {
                if (this.issue.pages[idx].pageNo == this.page.pageNo)
                    break;
            }
            idx = idx - 1; //下一版索引
            if (idx >= 0) {

                if (this.paperId == null && this.articleId != null) {
                    this.getArticle(this.articleId).then(
                        article => {
                            this.getPage(article.paperId, this.page.issueNo, this.issue.pages[idx].pageNo);
                        }
                    )

                } else if (this.paperId != null) {
                    this.getPage(this.paperId, this.page.issueNo, this.issue.pages[idx].pageNo);
                }
            } else {
                this.$message({
                    showClose: true,
                    message: '已经是第一版了',
                    type: 'warning'
                });
            }


            if (this.shHide == 'block') {
                this.scrollToTop()
            }
        },
        // 下一版
        pageNoright() {
            var idx = 0;
            for (idx = 0; idx < this.issue.pages.length; idx++) {
                if (this.issue.pages[idx].pageNo == this.page.pageNo)
                    break;
            }
            idx = idx + 1; //下一版索引
            if (idx < this.issue.pages.length) {
                if (this.paperId == null && this.articleId != null) {
                    this.getArticle(this.articleId).then(
                        article => {
                            this.getPage(article.paperId, this.page.issueNo, this.issue.pages[idx].pageNo);
                        }
                    )

                } else if (this.paperId != null) {
                    this.getPage(this.paperId, this.page.issueNo, this.issue.pages[idx].pageNo);
                }
            } else {
                this.$message({
                    showClose: true,
                    message: '已经是最后一版了',
                    type: 'warning'
                });
            }

            if (this.shHide == 'block') {
                this.scrollToTop()
            }
        },
        //判断鼠标滑过area标签的id值，判断触发热区的位置，控制span的位置以及大小
        moveseOver(index, article, event) {
            this.hotSpan.title = article.title;
            //点击期版之后的图片的热区
            var coords = event.target.coords.split(',');
            this.hotSpan.id = index;
            this.hotSpan.style = {
                display: 'block',
                left: coords[0] + 'px',
                top: coords[1] + 'px',
                width: coords[2] - coords[0] + 'px',
                height: coords[3] - coords[1] + 'px'
            }
        },
        // 移出热区
        moveOut() {
            //鼠标离开span标签
            this.hotSpan.style = {
                display: 'none'
            }
        },
        calcHotBorder(hot, img){
            var coord = {
                left : hot.l * img.offsetWidth,
                top : hot.t * img.offsetHeight,
                width: hot.r * img.offsetWidth - hot.l * img.offsetWidth - 4,   //减去border
                height: hot.b * img.offsetHeight - hot.t * img.offsetHeight - 4
            };
            return {
                'pointer-events': 'none',
                left : coord.left + 'px',
                top : coord.top + 'px',
                width : coord.width + 'px',
                height : coord.height + 'px'
            }
        },        
        // --------------- 右侧事件 start -----------
        // 点击有奖纠错
        clickWardDispute: function() {
            this.disputeVisible = true;
            this.clearForm();
            this.setPasteImg();
        },
        //获取粘贴板上的图片
        setPasteImg: function() {
            //粘贴事件
            var that = this;
            document.addEventListener('paste', function(event) {
                if (event.clipboardData || event.originalEvent) {
                    var clipboardData = (event.clipboardData || event.originalEvent.clipboardData);
                    if (clipboardData.items) {
                        var blob;
                        for (var i = 0; i < clipboardData.items.length; i++) {
                            if (clipboardData.items[i].type.indexOf("image") !== -1) {
                                blob = clipboardData.items[i].getAsFile();
                            } else {
                                return false;
                            }
                        }
                        var render = new FileReader();
                        var file = document.getElementById('img');
                        render.onload = function(evt) {
                            //输出base64编码
                            // var base64 = evt.target.result;
                            that.disputeForm.images = evt.target.result;
                            document.getElementById('img').setAttribute('src', that.disputeForm.images);
                            // that.disputeForm.images = '';

                        }
                        render.readAsDataURL(blob);
                    }

                }

            })

        },
        // 有奖纠纷弹框提交
        confirmDispute: function(formName) {
            this.articleId = this.page.id;
            this.$refs[formName].validate((valid) => {
                if (valid) {
                    this.$http.post('/api/newspaper/commitError?paperId=' + this.paperId + '&pageNo=' + this.page.pageNo + '&issueNo=' + this.page.issueNo + '&articleId=' + this.articleId + '&title=' + this.article.title + '&userName=' + this.disputeForm.userName + '&userContact=' + this.disputeForm.userContact + '&description=' + this.disputeForm.description + '&images=' + this.disputeForm.images)
                        .then(res => {
                            if (res.data.code == 0) {
                                this.disputeVisible = false;
                                var attr = document.getElementById('img').getAttribute('src');
                                if (attr != '') {
                                    document.getElementById('img').setAttribute('src', '');
                                }
                                throw this.error = '操作成功';
                            } else {
                                //    抛异常
                                throw this.error = '抱歉、数据查询失败'
                            }

                        }).catch(error => {
                            this.$message({
                                showClose: true,
                                message: this.error,
                                type: 'warning'
                            });
                        })

                } else {
                    console.log('error submit');
                    return false;
                }
            })
        },
        // 有奖纠纷弹框取消
        cancelDispute: function(formName) {
            this.disputeVisible = false;
            this.$refs[formName].resetFields();
            this.clearForm();
            var attr = document.getElementById('img').getAttribute('src');
            if (attr != '') {
                document.getElementById('img').setAttribute('src', '');
            }

        },
        //点击返回目录，控制页面展示的哪个页面 调所有数据接口
        toGo() {
            this.shHide = 'none';
        },
        // 下载、打印、复制事件
        downloadPrintCopy(opt) {
            // 获取用户下载、打印、复制的权限
            this.getPermission();
            this.dialogVisible = true;
            console.log(this.permission, '获取用户下载、打印、复制权限')
            this.clearForm();
            if (opt == 'download') { // 下载
                this.jurisdictionTotal = '下载总数' + this.permission.newspaper.download.total;
                this.jurisdictionNuit = this.permission.newspaper.download.cycle;
                this.jurisdictionSurplus = '下载' + this.permission.newspaper.download.available;
                this.message = "可"  +  this.jurisdictionTotal  +  "篇/"  +  this.jurisdictionNuit  +  "   剩余可"  +  this.jurisdictionSurplus  +  "篇";
                this.jurisdictionNum = this.permission.newspaper.download.available;
                if (this.permission.newspaper.download.available == 0) {
                    this.message = " 抱歉，您无权限";
                    this.$message({
                        showClose: true,
                        // message: '您的《下载》次数已为0，不可进行此操作，请在下个权限之内载操作',
                        message:"抱歉，您无权限",
                        // message:   "权限：  可"  +  this.jurisdictionTotal  +  "篇/"  +  this.jurisdictionNuit  +  "   剩余可"  +  this.jurisdictionSurplus  +  "篇",
                        type: 'warning'
                    });
                }
            } else if (opt == 'print') { // 打印
                this.jurisdictionTotal = '打印总数' + this.permission.newspaper.print.total;
                this.jurisdictionNuit = this.permission.newspaper.print.cycle;
                this.jurisdictionSurplus = '打印' + this.permission.newspaper.print.available;
                this.message = "可"  +  this.jurisdictionTotal  +  "篇/"  +  this.jurisdictionNuit  +  "   剩余可"  +  this.jurisdictionSurplus  +  "篇";
                this.jurisdictionNum = this.permission.newspaper.print.available;
                if (this.permission.newspaper.print.available == 0) {
                    this.message = " 抱歉，您无权限";
                    this.$message({
                        showClose: true,
                        // message: '您的《打印》次数已为0，不可进行此操作，请在下个权限之内载操作',
                        message:"抱歉，您无权限",
                        // message:   "权限：  可"  +  this.jurisdictionTotal  +  "篇/"  +  this.jurisdictionNuit  +  "   剩余可"  +  this.jurisdictionSurplus  +  "篇",
                        type: 'warning'
                    });
                }
            } else { // 复制copy
                this.jurisdictionTotal = '复制总数' + this.permission.newspaper.copy.total;
                this.jurisdictionNuit = this.permission.newspaper.copy.cycle;
                this.jurisdictionSurplus = '复制' + this.permission.newspaper.copy.available;
                this.message = "可"  +  this.jurisdictionTotal  +  "篇/"  +  this.jurisdictionNuit  +  "   剩余可"  +  this.jurisdictionSurplus  +  "篇";
                this.jurisdictionNum = this.permission.newspaper.copy.available;
                if (this.permission.newspaper.copy.available == 0) {
                    this.message = " 抱歉，您无权限";
                    this.$message({
                        showClose: true,
                        // message: '您的《复制》次数已为0，不可进行此操作，请在下个权限期内再操作',
                        message:'抱歉，您无权限',
                        // message:   "权限：  可"  +  this.jurisdictionTotal  +  "篇/"  +  this.jurisdictionNuit  +  "   剩余可"  +  this.jurisdictionSurplus  +  "篇",
                        type: 'warning'
                    });
                }
            }

        },
        // 下载、打印、复制 弹框提交
        confirm: function(formName) {
            this.$refs[formName].validate((valid) => {
                if (valid) {
                    if (this.jurisdictionTotal.indexOf('下载') > -1) {
                        if (this.jurisdictionNum == 0) {
                            alert('测功能暂未开发')
                        } else {
                            this.permission.newspaper.download.available--;
                            $("#tooltip").remove();
                            this.downloadArticle()
                            this.dialogVisible = false;
                        }

                    } else if (this.jurisdictionTotal.indexOf('打印') > -1) {
                        if (this.jurisdictionNum == 0) {
                            alert('测功能暂未开发')
                        } else {
                            this.permission.newspaper.print.available--;
                            $("#tooltip").remove();
                            this.printArticle();
                            this.dialogVisible = false;
                        }

                    } else if (this.jurisdictionTotal.indexOf('复制') > -1) {
                        if (this.jurisdictionNum == 0) {
                            alert('测功能暂未开发')
                        } else {
                            this.permission.newspaper.copy.available--;
                            $("#tooltip").remove();
                            this.copyArticle();
                            this.dialogVisible = false;
                        }

                    }
                } else {
                    console.log('error submit');
                    return false;
                }
            })


        },
        // 取消
        cancel: function(formName) {
            this.dialogVisible = false;
            this.$refs[formName].resetFields();
        },
        // 点击第几期
        clickIssue() {
            let find = false;
            this.paper.forEach((item, i) => {
                var issueValue = parseInt(this.issueValue);
                var issueNo = parseInt(item.issueNo);
                if (issueValue == issueNo) {
                    this.selectPeriod(item, i);
                    var num = i * 30;
                    document.querySelector('.paperContainer').scroll(0, num);
                    find = true;
                }
            });
            if (!find) throw error = "未找到此期次";
        },
        // 第几期回车事件
        searchEnterFun: function (e) {
         console.log(e, '回车事件')
          if (e.keyCode == 13) {
              this.clickIssue();
          }
        },
        //点击期次触发事件
        selectPeriod: function(item, index) {
            Bus.$emit('publishedDate', item.publishedDate)
            if (this.paperId == null && this.articleId != null) {
                this.getArticle(this.articleId).then(
                    article => {
                        this.getPaper(article.paperId, item.issueNo).then(
                            paper => {
                                this.getPage(article.paperId, item.issueNo, item.pages[0].pageNo)
                            }
                        )
                    }
                )
            } else if (this.paperId != null) {
                this.getPaper(this.paperId, item.issueNo).then(
                    paper => {
                        this.getPage(this.paperId, item.issueNo, item.pages[0].pageNo);
                    }
                )
            }
        },
        //点击版次触发
        selectEdition: function(item, index) {
            // 如果没有paperId 有articleId 则走if条件 
            if (this.paperId == null && this.articleId != null) {
                this.getArticle(this.articleId).then(
                    article => {
                        this.getPage(article.paperId, this.page.issueNo, item.pageNo)
                    }
                )
            } else if (this.paperId != null) {
                this.getPage(this.paperId, this.page.issueNo, item.pageNo);

            }
        },
        // 获取鼠标选中的内容
        getChoose: function() {
            var that = this;
            //将该id下的文章，鼠标选中松开后弹窗
            $("#content").mouseup(function(e) {
                var x = 10;
                var y = 10;
                var r = "";
                if (document.selection) {
                    r = document.selection.createRange().text;
                } else if (window.getSelection()) {
                    r = window.getSelection();
                }
                if (r != "") {
                    console.log(that.permission.newspaper.enableAnnotate, '获取注释权限')
                        // that.permission.newspaper.enableAnnotate = true;
                    var tooltip = '';
                    if (that.permission.newspaper.copy.enabled && !that.permission.newspaper.enableAnnotate) { // 复制权限存在、注释不存在
                        tooltip = "<div id='tooltip' class='tooltip'><button id='copy'>复制</button>";
                    } else if (!that.permission.newspaper.copy.enabled && that.permission.newspaper.enableAnnotate) { // 复制权限不存在、注释存在
                        tooltip = "<div id='tooltip' class='tooltip'><button id='notes'>注释</button></div>";
                    } else if (that.permission.newspaper.copy.enabled && that.permission.newspaper.enableAnnotate) { // 复制注释权限都存在
                        tooltip = "<div id='tooltip' class='tooltip'><button id='copy'>复制</button><button id='notes'>注释</button></div>";
                    } else if (!that.permission.newspaper.copy.enabled && !that.permission.newspaper.enableAnnotate) { // 复制注释权限都不存在
                        tooltip = '';
                        // that.$message({
                        //     showClose: true,
                        //     message: '您没有复制和注释的权限',
                        //     type: 'warning'
                        // });
                    }
                    $("body").append(tooltip);
                    $("#tooltip").css({
                        "top": (e.pageY + y) + "px",
                        "left": (e.pageX + x) + "px",
                        "position": "absolute"
                    }).show("fast");

                    // var styles = {"style":"border-bottom:2px solid red"}
                    // that.replaceSelectedStrByEle( styles['style'])
                    that.addEvent(that, r)
                }
            }).mousedown(function() {
                $("#tooltip").remove();
            });
        },
        // 添加复制、注释事件
        addEvent: function(that, r) {
            $('#copy').click(function() {
                document.execCommand('copy');
            })
            $('#notes').click(function() {
                var annote = new Annotate(document.getElementById("container"));
                var pos = annote.getSelectPos();
                that.notesForm.begin = pos.begin;
                that.notesForm.end = pos.end;
                that.notesForm.selectedText = pos.selectedText;
                console.log(that.notesForm.selectedText, '计算出选中的文本')
                that.notesVisible = true;
            })
        },
        // 注释部分表单提交
        notesConfirm: function(formName) {
            this.$refs[formName].validate((valid) => {
                if (valid) {
                    this.$http.get('/api/newspaper/commitAnnotate', {
                        params: {
                            begin: this.notesForm.begin,
                            end: this.notesForm.end,
                            selectedText: this.notesForm.selectedText,
                            content: this.notesForm.content,
                            paperId: this.paperId,
                            pageNo: this.page.pageNo,
                            issueNo: this.page.issueNo,
                            articleId: this.articleId
                        }
                    }).then(res => {
                        if (res.data.code == 0) {
                            this.notesVisible = false;
                            var result = res.data.data;
                            this.annoteData = res.data.data;
                            this.notesForm.content = '';
                            $("#tooltip").remove();
                            var annote = new Annotate(document.getElementById("container"));
                            var newNode = document.createElement("div");
                            newNode.innerHTML = "<img src='./static/images/icon/note.png' id='IMG'/>";
                            var dom = newNode.childNodes[0].cloneNode();
                            dom.setAttribute('item', result.id);
                            annote.markElement(result.end, dom);
                            this.addNoteEvent($(dom));
                            // annote.selectElement(result.begin, result.end);
                        } else {
                            throw this.error = res.data.msg;
                        }
                    }).catch(error => {
                        this.$message({
                            showClose: true,
                            message: '添加注释失败',
                            type: 'warning'
                        });
                    })
                } else {
                    console.log('error submit');
                    return false;
                }
            })
        },
        // 查询文章的注释
        getSelectAnnotate: function() {
            this.$http.get('/api/newspaper/selectAnnotate/' + this.articleId).then(res => {
                if (res.data.code == 0) {
                    console.log(res.data.data, '获取批注信息')
                    this.annoteData = res.data.data;
                    var annote = new Annotate(document.getElementById("container"));
                    var newNode = document.createElement("div");
                    newNode.innerHTML = "<img src='./static/images/icon/note.png' id='IMG'/>"
                    this.annoteData.forEach((item, index) => {
                        var dom = newNode.childNodes[0].cloneNode();
                        dom.setAttribute('item', index);
                        annote.markElement(item.end, dom);
                        //   annote.selectElement(item.begin, item.end);
                        this.addNoteEvent($(dom))
                    })
                } else {
                    throw this.error = res.data.msg;
                }

            }).catch(error => {
                this.$message({
                    showClose: true,
                    message: this.error,
                    type: 'warning'
                });
            })
        },
        // 添加注释框
        addNoteEvent: function($aIMG) {
            var annoteData = this.annoteData;
            $aIMG.on({
                mouseenter: function(e) {
                    var that = this;
                    var item = e.target.getAttribute('item')
                    layui.use('layer', function() {
                        tips = layer.tips(
                            `<span style='color:#70665C;border-radius: 6px;z-index: 50;' id='tips'>${annoteData.constructor === Array ? annoteData[item].content : annoteData.content}</span>`,
                            that, {
                                tips: [1, '#d5c78a'],
                                time: 3000,
                                area: ['auto', 'auto'], //这个属性可以设置宽高  auto 表示自动
                                maxWidth: 100
                            }
                        );
                    })
                },
                mouseleave: function() {
                    layui.use('layer', function() {
                        layer.close(tips);
                    })

                }
            })
        },
        // 注释表单取消
        notesCancel: function(formName) {
            this.notesVisible = false;
            this.$refs[formName].resetFields();
        },
        //点击标题，对id值进行判断 
        clickTitle(item, i) {
            this.listId(i)
        },
        // 文本滚动事件，监控page的位置，出现新的page，切换版面图到新page，page消失时，切换版面到当前显示的版
        handleScroll(ev) {
            var view = $(ev.target)[0]; //view是dom对象
            var pgEle = $(ev.target).find("page");
            // 可视区域
            view.vw = {
                    t: view.scrollTop,
                    b: $(view).height() + view.scrollTop,
                    ptIn: function(pt, range) {
                        return pt > range.t && pt < range.b;
                    },
                    rgIn: function(o) { //判断对象是否可见
                        return this.ptIn(o.t, this) || this.ptIn(o.b, this) ||
                            this.ptIn(this.t, o) || this.ptIn(this.b, o);
                    }
                }
                //构建每个page的可视范围
            var pages = [{ t: 0 }];
            for (var i = 1; i <= pgEle.length; i++) {
                pages.push({});
                pages[i - 1].b = pages[i].t = pgEle[i - 1].offsetTop;
            }
            pages[pages.length - 1].b = view.scrollHeight;

            var pageIdx = 0;
            if (view.scrollOldTop && view.scollOldTop > view.scrollTop) {
                //向上滚动,找到第一个可见对象
                for (pageIdx = 0; pageIdx < pages.length; pageIdx++)
                    if (view.vw.rgIn(pages[pageIdx]))
                        break;
            } else {
                //向下滚动,找到最后一个可见对象
                for (pageIdx = pages.length - 1; pageIdx >= 0; pageIdx--)
                    if (view.vw.rgIn(pages[pageIdx]))
                        break;

            }
            view.scrollOldTop = view.scrollTop;

            if (view.currentPage != pageIdx &&
                this.article.relatedPages.length > pageIdx && this.article.relatedPages[pageIdx] != this.page.pageNo) {
                this.getPage(this.article.paperId, this.article.issueNo, this.article.relatedPages[pageIdx], this.article.id);
            }
            //记录当前显示的page，用于防止getPage过程中重复请求。    
            view.currentPage = pageIdx;

            console.log(pageIdx);
        },
        scrollToTop() {
            let timer = null;
            //动画回滚
            cancelAnimationFrame(timer);
            timer = requestAnimationFrame(function fn() {
                $("#content")[0].scrollTop /= 1.5;
                if ($("#content")[0].scrollTop > 1) {
                    timer = requestAnimationFrame(fn);
                } else {
                    $("#content")[0].scrollTop = 0;
                    cancelAnimationFrame(timer);

                }
            });
            $("#content")[0].scrollOldTop = 0;
            $("#content")[0].currentPage = -1;
        },
        resetContainer() {
            var sh = document.body.clientHeight - 60;
            var sw = document.body.clientWidth - 10;
            if (sw < sh * 1.57)
                sh = sw / 1.57;
            else
                sw = sh * 1.57;
            this.container.width = sw;
            this.container.height = sh + 60;
        },
        // 下载文章
        downloadArticle() {
            var url = "/api/newspaper/writeDoc/" + this.article.id; //此处base地址要用userinfo取
            console.log(this.form, this.baseUrl, 'json数据')
            this.optLog("download", this.form);
            window.open(url);
        },
        // 打印
        printArticle() {
            $("#readingPage_rightTextbox").print({
                // 是否包含父文档样式
                            
                globalStyles: true,
                //是否包含media='print'的链接标签。会被globalStyles选项覆盖，默认为false 
                            mediaPrint: false,
                //外部样式表的URL地址，默认为null
                            stylesheet: null,
                //不想打印的元素的jQuery选择器，默认为".no-print"
                            noPrintSelector: ".no-print",
                //是否使用一个iframe来替代打印表单的弹出窗口，true为在本页面进行打印，false就是说新开一个页面打印，默认为true 
                            iframe: true,
                // 将内容添加到打印内容的后面
                          append: null,
                //将内容添加到打印内容的前面，可以用来作为要打印内容
                prepend: null,
                //回调函数
                deferred: $.Deferred(),
                         
            });
            //使用iframe，重新设置document.body.innerHTML，调用window.print进行打印
            // var printBox = document.getElementById('readingPage_rightTextbox');
            // //拿到打印的区域的html内容
            // var newContent = printBox.innerHTML;
            // //将旧的页面储存起来，当打印完成后返给给页面。
            // var oldContent = document.body.innerHTML;
            // //赋值给body
            // document.body.innerHTML = newContent;
            // //执行window.print打印功能
            // window.print();
            // // 重新加载页面，以刷新数据。以防打印完之后，页面不能操作的问题
            // window.location.reload();
            // document.body.innerHTML = oldContent;
            this.optLog("print", this.form);
        },
        // 复制文章
        copyArticle() {
            this.copyEvent.submit();
            var Url2 = document.getElementById("content").innerText;
            var oInput = document.createElement('input');
            oInput.value = Url2;
            document.body.appendChild(oInput);
            oInput.select(); // 选择对象
            document.execCommand("Copy"); // 执行浏览器复制命令
            oInput.className = 'oInput';
            oInput.style.display = 'none';

            this.optLog("copy", this.form);
        },
        /**
         * 记录操作日志，
         * @param opt，操作类型，read,copy,print,down,search
         * @param optParam
         */
        optLog(opt, optParam) {
            this.$http.get('/api/user/optlog', {
                params: {
                    resType: 'newspaper',
                    paperId: this.article.paperId,
                    resId: this.article.id,
                    opt: opt,
                    optParam: optParam
                }
            }).then(res => {
                if (res.data.code == 0) {
                    console.log('日志纪录成功！！！')
                }
            });
        },
        // 点击日历
        openCalendar: function() {
          document.getElementById('ui-datepicker-div').className = 'datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all animated fadeInUp';
          this.isCanlendar = !this.isCanlendar;
        },
        closeCalendar: function (e) {
            if (e.target.nodeName != 'SELECT' && e.target.className != 'ui-datepicker-other-month ui-datepicker-unselectable' && 
                e.target.className !='day' && e.target.className != 'ui-datepicker-title' && e.target.nodeName != 'A' && e.target.nodeName != 'UL') {
                document.getElementById('ui-datepicker-div').className = "datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all animated fadeInDown";
                this.isCanlendar = false;
            } 
        },

        // -------------- 右侧事件 end ---------------

        // -------------- 公共事件 start ---------------
        // 添加版权说明
        setClipboardText: function(event) {
            // event.preventDefault();
            var node = document.createElement('div');
            node.innerHTML = this.copyEvent.text;
            var htmlData = '<div><br />' +
                node.innerHTML + '<br />' +
                '著作权：归延安大学所有<br />' +
                '商业转载: 请联系延安大学获得授权，非商业转载请注明出处<br />' +
                // '作者：0zero<br />链接：https://segmentfault.com/u/codedemon<br />' +
                // '来源：segmentfault<br /><br />' +
                '</div>';
            var textData = this.copyEvent.text +
                '\n\n著作权：归延安大学所有\n' +
                '商业转载：请联系延安大学获得授权，非商业转载请注明出处\n'
                // '作者：0zero\n链接：https://segmentfault.com/u/codedemon\n' +
                // '来源：segmentfault\n\n'
            if (event.clipboardData) {
                event.clipboardData.setData("text/html", htmlData);
                event.clipboardData.setData('text/plain', textData);
            } else if (window.clipboardData) {
                return window.clipboardData.setData("text", textData);
            }
        },
        // 清空form表单
        clearForm: function() {
            this.form.userName = '';
            this.form.workUnit = '';
            this.form.contact = '';
            this.form.description = '';

            this.disputeForm.userName = '';
            this.disputeForm.userContact = '';
            this.disputeForm.description = '';
            this.disputeForm.images = '';
        },
        /**
         * 用元素替换被选中的文本
         */
        replaceSelectedStrByEle: function(className) {
            var getRange = () => {
                var me = window;
                var range = new Range(me.document);

                var sel = window.getSelection();
                if (sel && sel.rangeCount) {
                    var firstRange = sel.getRangeAt(0);
                    var lastRange = sel.getRangeAt(sel.rangeCount - 1);
                    range.setStart(firstRange.startContainer, firstRange.startOffset)
                        .setEnd(lastRange.endContainer, lastRange.endOffset);
                }
                return range
            }
            var range = getRange();
            range.applyInlineStyle('i', {
                class: className
                    // "style":"font-size:12px"
            });
            range.select();
        }
        // -------------- 公共事件 end ---------------
    }
})