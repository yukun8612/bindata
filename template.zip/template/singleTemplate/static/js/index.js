Vue.prototype.$http = axios;
Vue.config.errorHandler = (error, vm) => {
    console.log(error, '错误信息')
    vm.$message({
        showClose: true,
        message: error,
        type: 'warning'
    });
};
Newspaper.$http = axios;
// 创建-个vue实力
vueObj = new Vue({
    el:'#wrap',
    // 定义属性，并设置初始值
    data:function () {
      return {
        searchVal:'',
        // 页面展示信息
        library:{},
        userInfo:{},
      }
    },
    // 在模板渲染成html前调用，即通常初始化某些属性值，然后再渲染成视图。
    created () {

    },
    // 在模板渲染成html后调用，通常是初始化页面完成后，再对html的dom节点进行一些需要的操作
    mounted () {
      this.initialize()
    },
    methods:{
      // 初始化加载数据
      initialize: function () {
        Newspaper.getUserInfo().then(userInfo => {
            console.log(userInfo, '用户信息')
            this.userInfo = userInfo;
            if (this.userInfo.userType == "Visitor") { // 游客
                window.location.href = "login.html";
            } 
            // if (this.userInfo.userType == "IPUser") {
            //    window.location.href = "login.html";
            // }
        });
        Newspaper.getLibraryInfo().then(library => {
          console.log(library, '资源库信息')
          this.library = library;
        })
      },
        /* ------------------ 业务操作事件 -------------------------- */
        // 检索
        btnRoute:function () {
            window.location.href = 'newspaperSearch.html?inpVal='+this.searchVal;
        },
        // 搜索回车事件
        searchEnterFun: function (e) {
          console.log(e, '回车事件')
          if (e.keyCode == 13) {
            this.btnRoute()  // 回车键触发、搜索事件  
          }
        },
        signIn () {
          window.location.href = 'login.html';
        },
         // 退出
        signOut: (userType) =>{
          $.ajax({
                type: "post",
                url: "/logout",
                success: function(res) {
                  location.href = 'login.html';
                }
          });
        },
        // 点击切换资源库
        handleCommand (item) {
          window.location.href = '/' + item.code;
        }
        
    }
})